# Image to QBASIC POKE — 1-bit to 32-bit saver + loader

Upload any image → pick a bit depth → get a working QBASIC/QB64 `.BAS` file
with packed `DATA`, a `POKE`/`PSET` **loader** and a `PEEK`/`POINT` **saver**.

## Layout
- `main.pjs` — title + `$meta` only.
- `index.html` — full UI (controls, preview, BAS output, docs).
- `src/qb-converter.js` — engine: median-cut/EGA/gray palettes, Floyd–Steinberg +
  ordered-Bayer dither, bit packing, per-depth BAS codegen. Global `QBConv`.

## Packing (what the DATA means)
- 1-bit: 8 px/byte MSB first, each row padded to a whole byte.
- 2-bit: 4 px/byte, high bits first, rows padded.
- 3/5/6/7-bit: continuous MSB-first bit-stream, no row padding; loader keeps
  a `BUF&`/`HAVE%` bit-buffer (`WHILE HAVE% < bits: READ…`).
- 4-bit: 2 px/byte, high nibble first.
- 8-bit: 1 byte/px = palette index (native SCREEN 13).
- 16-bit: 2 bytes/px little-endian LO,HI; RGB565 (default) or RGB555.
- 24-bit: R,G,B per pixel. 32-bit: R,G,B,A per pixel.
- ≤8-bit draws with `DEF SEG=&HA000: POKE y*320+x, attr` on `SCREEN 13`
  with a `PALETTE`-restoring preamble; 16/24/32-bit uses QB64
  `SCREEN _NEWIMAGE(w,h,32)` + `PSET (x,y), _RGB32/_RGBA32`.

## Testing
- `window._qbTest.makeSample('sunset'|'dither'|'portrait')`, `.convert()`, `.bits`.
- ALL mode namespaces every section (`LoadImage1…32`, `ImgData1…`) so all
  11 samples concatenate into one `.BAS` library.
