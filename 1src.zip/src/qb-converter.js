/* Image to QBASIC POKE converter — core engine (classic script, global QBConv) */
(function () {
  "use strict";

  var EGA16 = [
    [0, 0, 0], [0, 0, 170], [0, 170, 0], [0, 170, 170],
    [170, 0, 0], [170, 0, 170], [170, 85, 0], [170, 170, 170],
    [85, 85, 85], [85, 85, 255], [85, 255, 85], [85, 255, 255],
    [255, 85, 85], [255, 85, 255], [255, 255, 85], [255, 255, 255]
  ];

  var BAYER4 = [
    [0, 8, 2, 10],
    [12, 4, 14, 6],
    [3, 11, 1, 9],
    [15, 7, 13, 5]
  ];

  function clamp255(v) { return v < 0 ? 0 : v > 255 ? 255 : v; }
  function lum(r, g, b) { return 0.299 * r + 0.587 * g + 0.114 * b; }

  function nearestIndex(r, g, b, pal) {
    var best = 0, bd = Infinity;
    for (var i = 0; i < pal.length; i++) {
      var dr = r - pal[i][0], dg = g - pal[i][1], db = b - pal[i][2];
      var d = dr * dr + dg * dg + db * db;
      if (d < bd) { bd = d; best = i; }
    }
    return best;
  }

  // Median-cut palette from pixel array [[r,g,b],...] -> N colors
  function medianCut(px, n) {
    if (n <= 1) {
      var s0 = [0, 0, 0];
      for (var i = 0; i < px.length; i++) { s0[0] += px[i][0]; s0[1] += px[i][1]; s0[2] += px[i][2]; }
      var c = px.length || 1;
      return [[Math.round(s0[0] / c), Math.round(s0[1] / c), Math.round(s0[2] / c)]];
    }
    var boxes = [px];
    while (boxes.length < n) {
      var bi = -1, bv = -1;
      for (var b = 0; b < boxes.length; b++) {
        if (boxes[b].length < 2) continue;
        var rmin = 255, rmax = 0, gmin = 255, gmax = 0, bmin = 255, bmax = 0;
        for (var k = 0; k < boxes[b].length; k++) {
          var p = boxes[b][k];
          if (p[0] < rmin) rmin = p[0]; if (p[0] > rmax) rmax = p[0];
          if (p[1] < gmin) gmin = p[1]; if (p[1] > gmax) gmax = p[1];
          if (p[2] < bmin) bmin = p[2]; if (p[2] > bmax) bmax = p[2];
        }
        var rng = Math.max(rmax - rmin, gmax - gmin, bmax - bmin);
        var score = rng * Math.log(boxes[b].length + 1);
        if (score > bv) { bv = score; bi = b; }
      }
      if (bi < 0) break;
      var box = boxes.splice(bi, 1)[0];
      var r1 = 255, r2 = 0, g1 = 255, g2 = 0, b1 = 255, b2 = 0, j;
      for (j = 0; j < box.length; j++) {
        var q = box[j];
        if (q[0] < r1) r1 = q[0]; if (q[0] > r2) r2 = q[0];
        if (q[1] < g1) g1 = q[1]; if (q[1] > g2) g2 = q[1];
        if (q[2] < b1) b1 = q[2]; if (q[2] > b2) b2 = q[2];
      }
      var ch = 0;
      if (g2 - g1 >= r2 - r1 && g2 - g1 >= b2 - b1) ch = 1;
      else if (b2 - b1 >= r2 - r1 && b2 - b1 >= g2 - g1) ch = 2;
      box.sort(function (a, b) { return a[ch] - b[ch]; });
      var mid = box.length >> 1;
      boxes.push(box.slice(0, mid), box.slice(mid));
    }
    return boxes.map(function (box) {
      if (!box.length) return [0, 0, 0];
      var sr = 0, sg = 0, sb = 0;
      for (var i = 0; i < box.length; i++) { sr += box[i][0]; sg += box[i][1]; sb += box[i][2]; }
      return [Math.round(sr / box.length), Math.round(sg / box.length), Math.round(sb / box.length)];
    });
  }

  function grayRamp(n) {
    var p = [];
    for (var i = 0; i < n; i++) {
      var v = n === 1 ? 0 : Math.round(i * 255 / (n - 1));
      p.push([v, v, v]);
    }
    return p;
  }

  // Build palette for <=8 bit
  function buildPalette(pxSample, bits, mode) {
    var n = 1 << bits;
    if (mode === "gray") return grayRamp(n);
    if (mode === "ega") {
      // most-used EGA colors in this image -> top N, keep EGA index mapping
      var counts = new Array(16).fill(0);
      for (var i = 0; i < pxSample.length; i++) {
        counts[nearestIndex(pxSample[i][0], pxSample[i][1], pxSample[i][2], EGA16)]++;
      }
      var order = counts.map(function (c, idx) { return [c, idx]; })
        .sort(function (a, b) { return b[0] - a[0]; })
        .slice(0, n).map(function (e) { return e[1]; })
        .sort(function (a, b) { return a - b; });
      // store as {rgb, ega} pairs; palette rgb in EGA order subset
      var pal = order.map(function (idx) { return EGA16[idx].slice(); });
      pal._egaIndex = order;
      return pal;
    }
    return medianCut(pxSample, n);
  }

  // Quantize W*H rgb arrays -> indices + preview rgb
  function quantize(rgb, W, H, pal, dither) {
    var n = W * H;
    var idx = new Uint8Array(n);
    var prev = new Uint8ClampedArray(n * 4);
    if (dither === "fs") {
      var buf = new Float32Array(n * 3);
      for (var i = 0; i < n; i++) { buf[i * 3] = rgb[i * 3]; buf[i * 3 + 1] = rgb[i * 3 + 1]; buf[i * 3 + 2] = rgb[i * 3 + 2]; }
      for (var y = 0; y < H; y++) {
        for (var x = 0; x < W; x++) {
          var o = y * W + x;
          var r = clamp255(buf[o * 3]), g = clamp255(buf[o * 3 + 1]), b = clamp255(buf[o * 3 + 2]);
          var ci = nearestIndex(r, g, b, pal);
          idx[o] = ci;
          var er = r - pal[ci][0], eg = g - pal[ci][1], eb = b - pal[ci][2];
          prev[o * 4] = pal[ci][0]; prev[o * 4 + 1] = pal[ci][1]; prev[o * 4 + 2] = pal[ci][2]; prev[o * 4 + 3] = 255;
          var right = x + 1 < W, down = y + 1 < H, left = x > 0;
          if (right) { buf[(o + 1) * 3] += er * 7 / 16; buf[(o + 1) * 3 + 1] += eg * 7 / 16; buf[(o + 1) * 3 + 2] += eb * 7 / 16; }
          if (down) {
            if (left) { buf[(o + W - 1) * 3] += er * 3 / 16; buf[(o + W - 1) * 3 + 1] += eg * 3 / 16; buf[(o + W - 1) * 3 + 2] += eb * 3 / 16; }
            buf[(o + W) * 3] += er * 5 / 16; buf[(o + W) * 3 + 1] += eg * 5 / 16; buf[(o + W) * 3 + 2] += eb * 5 / 16;
            if (right) { buf[(o + W + 1) * 3] += er * 1 / 16; buf[(o + W + 1) * 3 + 1] += eg * 1 / 16; buf[(o + W + 1) * 3 + 2] += eb * 1 / 16; }
          }
        }
      }
    } else if (dither === "ordered") {
      for (var yy = 0; yy < H; yy++) {
        for (var xx = 0; xx < W; xx++) {
          var oo = yy * W + xx;
          var spread = (BAYER4[yy % 4][xx % 4] / 16 - 0.5) * 96;
          var ci2 = nearestIndex(
            clamp255(rgb[oo * 3] + spread),
            clamp255(rgb[oo * 3 + 1] + spread),
            clamp255(rgb[oo * 3 + 2] + spread), pal);
          idx[oo] = ci2;
          prev[oo * 4] = pal[ci2][0]; prev[oo * 4 + 1] = pal[ci2][1]; prev[oo * 4 + 2] = pal[ci2][2]; prev[oo * 4 + 3] = 255;
        }
      }
    } else {
      for (var k = 0; k < n; k++) {
        var c3 = nearestIndex(rgb[k * 3], rgb[k * 3 + 1], rgb[k * 3 + 2], pal);
        idx[k] = c3;
        prev[k * 4] = pal[c3][0]; prev[k * 4 + 1] = pal[c3][1]; prev[k * 4 + 2] = pal[c3][2]; prev[k * 4 + 3] = 255;
      }
    }
    return { indices: idx, preview: prev };
  }

  // 16-bit helpers
  function rgbTo565(r, g, b) {
    var R = (r * 31 / 255) | 0, G = (g * 63 / 255) | 0, B = (b * 31 / 255) | 0;
    return { v: (R << 11) | (G << 5) | B, R: R, G: G, B: B };
  }
  function rgbTo555(r, g, b) {
    var R = (r * 31 / 255) | 0, G = (g * 31 / 255) | 0, B = (b * 31 / 255) | 0;
    return { v: (R << 10) | (G << 5) | B, R: R, G: G, B: B };
  }
  function v565toRgb(v) {
    var R = (v >> 11) & 31, G = (v >> 5) & 63, B = v & 31;
    return [Math.round(R * 255 / 31), Math.round(G * 255 / 63), Math.round(B * 255 / 31)];
  }
  function v555toRgb(v) {
    var R = (v >> 10) & 31, G = (v >> 5) & 31, B = v & 31;
    return [Math.round(R * 255 / 31), Math.round(G * 255 / 31), Math.round(B * 255 / 31)];
  }

  function process16(rgb, W, H, fmt, dither) {
    var n = W * H;
    var words = new Uint16Array(n);
    var prev = new Uint8ClampedArray(n * 4);
    var toV = fmt === "555" ? rgbTo555 : rgbTo565;
    var back = fmt === "555" ? v555toRgb : v565toRgb;
    if (dither === "fs") {
      var buf = new Float32Array(n * 3);
      for (var i = 0; i < n; i++) { buf[i * 3] = rgb[i * 3]; buf[i * 3 + 1] = rgb[i * 3 + 1]; buf[i * 3 + 2] = rgb[i * 3 + 2]; }
      for (var y = 0; y < H; y++) for (var x = 0; x < W; x++) {
        var o = y * W + x;
        var r = clamp255(buf[o * 3]), g = clamp255(buf[o * 3 + 1]), b = clamp255(buf[o * 3 + 2]);
        var q = toV(r, g, b);
        words[o] = q.v;
        var pr = back(q.v);
        prev[o * 4] = pr[0]; prev[o * 4 + 1] = pr[1]; prev[o * 4 + 2] = pr[2]; prev[o * 4 + 3] = 255;
        var er = r - pr[0], eg = g - pr[1], eb = b - pr[2];
        if (x + 1 < W) { buf[(o + 1) * 3] += er * 7 / 16; buf[(o + 1) * 3 + 1] += eg * 7 / 16; buf[(o + 1) * 3 + 2] += eb * 7 / 16; }
        if (y + 1 < H) {
          if (x > 0) { buf[(o + W - 1) * 3] += er * 3 / 16; buf[(o + W - 1) * 3 + 1] += eg * 3 / 16; buf[(o + W - 1) * 3 + 2] += eb * 3 / 16; }
          buf[(o + W) * 3] += er * 5 / 16; buf[(o + W) * 3 + 1] += eg * 5 / 16; buf[(o + W) * 3 + 2] += eb * 5 / 16;
          if (x + 1 < W) { buf[(o + W + 1) * 3] += er * 1 / 16; buf[(o + W + 1) * 3 + 1] += eg * 1 / 16; buf[(o + W + 1) * 3 + 2] += eb * 1 / 16; }
        }
      }
    } else if (dither === "ordered") {
      for (var yy = 0; yy < H; yy++) for (var xx = 0; xx < W; xx++) {
        var oo = yy * W + xx;
        var sp = (BAYER4[yy % 4][xx % 4] / 16 - 0.5) * 48;
        var q2 = toV(clamp255(rgb[oo * 3] + sp), clamp255(rgb[oo * 3 + 1] + sp), clamp255(rgb[oo * 3 + 2] + sp));
        words[oo] = q2.v;
        var pr2 = back(q2.v);
        prev[oo * 4] = pr2[0]; prev[oo * 4 + 1] = pr2[1]; prev[oo * 4 + 2] = pr2[2]; prev[oo * 4 + 3] = 255;
      }
    } else {
      for (var k = 0; k < n; k++) {
        var q3 = toV(rgb[k * 3], rgb[k * 3 + 1], rgb[k * 3 + 2]);
        words[k] = q3.v;
        var pr3 = back(q3.v);
        prev[k * 4] = pr3[0]; prev[k * 4 + 1] = pr3[1]; prev[k * 4 + 2] = pr3[2]; prev[k * 4 + 3] = 255;
      }
    }
    var packed = new Uint8Array(n * 2);
    for (var w = 0; w < n; w++) { packed[w * 2] = words[w] & 255; packed[w * 2 + 1] = (words[w] >> 8) & 255; }
    return { words: words, preview: prev, packed: packed };
  }

  // ---- Packing ----
  // 1/2/4-bit: row-padded bitstream. 3/5/6/7-bit: continuous bitstream. 8-bit: raw.
  function packIndices(indices, W, H, bits) {
    var n = W * H;
    if (bits === 8) return { packed: Uint8Array.from(indices), rowBytes: W, total: n, mode: "raw8" };
    if (bits === 1 || bits === 2 || bits === 4) {
      var rowBytes = Math.ceil(W * bits / 8);
      var out = new Uint8Array(rowBytes * H);
      for (var y = 0; y < H; y++) {
        var acc = 0, fill = 0, pos = y * rowBytes;
        for (var x = 0; x < W; x++) {
          acc = (acc << bits) | (indices[y * W + x] & ((1 << bits) - 1));
          fill += bits;
          while (fill >= 8) {
            fill -= 8;
            out[pos++] = (acc >> fill) & 255;
            acc &= (1 << fill) - 1;
          }
        }
        if (fill > 0) out[pos++] = (acc << (8 - fill)) & 255;
      }
      return { packed: out, rowBytes: rowBytes, total: out.length, mode: "rowpad" };
    }
    // continuous stream for 3/5/6/7
    var total = Math.ceil(n * bits / 8);
    var o2 = new Uint8Array(total);
    var a = 0, f = 0, p = 0;
    for (var i = 0; i < n; i++) {
      a = (a << bits) | (indices[i] & ((1 << bits) - 1));
      f += bits;
      while (f >= 8) { f -= 8; o2[p++] = (a >> f) & 255; a &= (1 << f) - 1; }
    }
    if (f > 0) o2[p++] = (a << (8 - f)) & 255;
    return { packed: o2, rowBytes: -1, total: total, mode: "stream" };
  }

  // ---- BAS codegen ----
  function palQbExpr(rgb) {
    var r6 = Math.round(rgb[0] * 63 / 255), g6 = Math.round(rgb[1] * 63 / 255), b6 = Math.round(rgb[2] * 63 / 255);
    return r6 + " + " + g6 + " * 256& + " + b6 + " * 65536";
  }

  function fmtNum(v, hex) {
    if (!hex) return String(v);
    var h = v.toString(16).toUpperCase();
    return "&H" + h;
  }

  function dataLines(bytes, perLine, hex, lineNo, startNo) {
    var lines = [];
    var no = startNo || 10000;
    for (var i = 0; i < bytes.length; i += perLine) {
      var chunk = [];
      for (var j = i; j < Math.min(i + perLine, bytes.length); j++) chunk.push(fmtNum(bytes[j], hex));
      var body = "DATA " + chunk.join(",");
      lines.push(lineNo ? (no + " " + body) : body);
      no += 10;
    }
    return { text: lines.join("\n"), nextNo: no };
  }

  function palDataLines(pal, hex, perLine, lineNo, startNo) {
    // palette as R,G,B triples (0-255), wrapped to perLine like pixel DATA
    // (QBASIC READs sequentially across DATA lines, so splitting is safe)
    var flat = [];
    for (var i = 0; i < pal.length; i++) { flat.push(pal[i][0], pal[i][1], pal[i][2]); }
    var dl = dataLines(flat, perLine || 12, hex, lineNo, startNo || 9000);
    return dl;
  }

  var DEPTH_INFO = {
    1: { name: "1-bit", colors: 2, layout: "8 pixels / byte, MSB first. Each row padded to a whole byte.", screen: "SCREEN 13 (attr 0-1)" },
    2: { name: "2-bit", colors: 4, layout: "4 pixels / byte (2 bits each), high bits first. Rows padded to whole bytes.", screen: "SCREEN 13 (attr 0-3)" },
    3: { name: "3-bit", colors: 8, layout: "Continuous bit-stream, MSB first, no row padding (8 px = 3 bytes). Loader uses bit-buffer.", screen: "SCREEN 13 (attr 0-7)" },
    4: { name: "4-bit", colors: 16, layout: "2 pixels / byte (high nibble first). Odd widths pad last nibble.", screen: "SCREEN 12/13 (attr 0-15)" },
    5: { name: "5-bit", colors: 32, layout: "Continuous bit-stream, MSB first (8 px = 5 bytes). Loader uses bit-buffer.", screen: "SCREEN 13 (attr 0-31)" },
    6: { name: "6-bit", colors: 64, layout: "Continuous bit-stream, MSB first (4 px = 3 bytes). Loader uses bit-buffer.", screen: "SCREEN 13 (attr 0-63)" },
    7: { name: "7-bit", colors: 128, layout: "Continuous bit-stream, MSB first (8 px = 7 bytes). Loader uses bit-buffer.", screen: "SCREEN 13 (attr 0-127)" },
    8: { name: "8-bit", colors: 256, layout: "1 byte / pixel = palette index 0-255. Native SCREEN 13 format.", screen: "SCREEN 13 (attr 0-255)" },
    16: { name: "16-bit", colors: 65536, layout: "2 bytes / pixel, little-endian (LO,HI). RGB565 (or RGB555).", screen: "QB64 _NEWIMAGE 32-bit" },
    24: { name: "24-bit", colors: 16777216, layout: "3 bytes / pixel: R,G,B. True color.", screen: "QB64 _NEWIMAGE 32-bit" },
    32: { name: "32-bit", colors: 16777216, layout: "4 bytes / pixel: R,G,B,A (A=255 opaque). True color + alpha.", screen: "QB64 _NEWIMAGE 32-bit" }
  };

  function buildBAS(o) {
    // o: {bits,W,H,palette,packedBytes,rowBytes,totalBytes,fmt16,perLine,hex,lineNo,withLoader,withSaver,imgName,maskNote}
    var bits = o.bits, W = o.W, H = o.H, pal = o.palette || [];
    var B = o.packedBytes, total = B.length;
    var info = DEPTH_INFO[bits];
    var L = [];
    function ln(s) { L.push(s); }
    var no = 10;
    function numbered(s) { return o.lineNo ? ((no += 10) - 10 + " " + s) : s; }

    ln("' ============================================================");
    ln("'  " + o.imgName + " - " + info.name + " QBASIC POKE saver + loader");
    ln("'  Size: " + W + " x " + H + "   Packed: " + total + " bytes");
    ln("'  Layout: " + info.layout);
    ln("'  Target: " + info.screen);
    ln("'  Generated by Image-to-QBASIC-POKE converter (perchance)");
    ln("'  HOW TO RUN: QB64 (recommended) or DOSBox + QBASIC 4.5/7.1.");
    ln("'  F5 to run. Loader draws with POKE/PSET, saver writes .BIN.");
    ln("' ============================================================");
    ln("");
    ln(numbered("DEFINT A-Z"));
    ln(numbered("CONST IMG_W = " + W));
    ln(numbered("CONST IMG_H = " + H));
    ln(numbered("CONST IMG_BITS = " + bits));
    ln(numbered("CONST IMG_BYTES = " + total));
    if (bits === 1 || bits === 2 || bits === 4) ln(numbered("CONST IMG_ROWBYTES = " + o.rowBytes));
    if (bits <= 8) ln(numbered("CONST IMG_COLORS = " + (1 << bits)));
    if (bits === 16) ln(numbered("' Pixel format: " + (o.fmt16 === "555" ? "RGB555 (bit15=0, R5/G5/B5)" : "RGB565 (R5/G6/B5)") + ", little-endian LO,HI bytes"));
    if (o.withSaver) ln(numbered("DIM SHARED OB AS STRING * 1  ' 1-byte buffer so PUT writes 1 byte, not 2"));
    ln("");

    // ---- main demo ----
    ln("' ---- demo ----");
    if (bits <= 8) {
      ln(numbered("SCREEN 13"));
      ln(numbered("CLS"));
      if (o.withLoader) ln(numbered("GOSUB LoadImage"));
      if (o.withSaver) {
        ln(numbered("' press any key, then image is saved back as packed .BIN"));
        ln(numbered('WHILE INKEY$ = "": WEND'));
        ln(numbered("GOSUB SaveImage"));
        ln(numbered('PRINT "saved."'));
      }
      ln(numbered('WHILE INKEY$ = "": WEND'));
      ln(numbered("END"));
    } else {
      ln(numbered("' QB64 32-bit screen for true color"));
      ln(numbered("SCREEN _NEWIMAGE(IMG_W, IMG_H, 32)"));
      if (o.withLoader) ln(numbered("GOSUB LoadImage"));
      if (o.withSaver) {
        ln(numbered('WHILE INKEY$ = "": WEND'));
        ln(numbered("GOSUB SaveImage"));
        ln(numbered('PRINT "saved."'));
      }
      ln(numbered('WHILE INKEY$ = "": WEND'));
      ln(numbered("END"));
    }
    ln("");

    // ---- palette setup lives INSIDE the loader (after END nothing runs) ----
    // (emitted by each <=8-bit loader via palPreamble)

    // ---- loader ----
    if (o.withLoader) {
      ln("' ================= LOADER (POKE) ================= ");
      o.palCount = pal.length;
      if (bits === 1) loader1(L, numbered, W, H, o);
      else if (bits === 2) loader2(L, numbered, W, H, o);
      else if (bits === 4) loader4(L, numbered, W, H, o);
      else if (bits === 8) loader8(L, numbered, W, H, o);
      else if (bits === 3 || bits === 5 || bits === 6 || bits === 7) loaderStream(L, numbered, W, H, o);
      else if (bits === 16) loader16(L, numbered, W, H, o);
      else if (bits === 24) loader24(L, numbered, W, H, o);
      else if (bits === 32) loader32(L, numbered, W, H, o);
      ln("");
    }

    // ---- saver ----
    if (o.withSaver) {
      ln("' ================= SAVER (PEEK / POINT) ================= ");
      if (bits === 1) saver1(L, numbered, W, H, o);
      else if (bits === 2) saver2(L, numbered, W, H, o);
      else if (bits === 4) saver4(L, numbered, W, H, o);
      else if (bits === 8) saver8(L, numbered, W, H, o);
      else if (bits === 3 || bits === 5 || bits === 6 || bits === 7) saverStream(L, numbered, W, H, o);
      else if (bits === 16) saver16(L, numbered, W, H, o);
      else if (bits === 24) saver24(L, numbered, W, H, o);
      else if (bits === 32) saver32(L, numbered, W, H, o);
      ln("");
    }

    // ---- data ----
    if (bits <= 8 && pal.length) {
      ln("ImgPalette:");
      ln("' " + pal.length + " colors as R,G,B triples (0-255)");
      ln(palDataLines(pal, o.hex, o.perLine, o.lineNo, 9000).text);
      ln("");
    }
    ln("ImgData:");
    ln("' " + total + " packed bytes, " + o.perLine + " per DATA line" + (o.hex ? " (hex &H..)" : " (decimal 0-255)"));
    var dl = dataLines(B, o.perLine, o.hex, o.lineNo, 10000);
    ln(dl.text);
    ln("");
    ln("' --- end of file ---");
    return L.join("\n");
  }

  // ===== loaders =====
  function palPreamble(L, numbered, n) {
    L.push(numbered("  ' set the " + n + " palette colors first"));
    L.push(numbered("  RESTORE ImgPalette"));
    L.push(numbered("  FOR P% = 0 TO " + (n - 1)));
    L.push(numbered("    READ R%, G%, B%"));
    L.push(numbered("    PALETTE P%, (R% \\ 4) + (G% \\ 4) * 256& + (B% \\ 4) * 65536"));
    L.push(numbered("  NEXT P%"));
  }
  function loader1(L, numbered, W, H, o) {
    L.push(numbered("LoadImage:"));
    palPreamble(L, numbered, o.palCount);
    L.push(numbered("  DEF SEG = &HA000"));
    L.push(numbered("  RESTORE ImgData"));
    L.push(numbered("  FOR Y% = 0 TO IMG_H - 1"));
    L.push(numbered("    FOR XB% = 0 TO IMG_ROWBYTES - 1"));
    L.push(numbered("      READ B%"));
    L.push(numbered("      FOR K% = 0 TO 7"));
    L.push(numbered("        X% = XB% * 8 + K%"));
    L.push(numbered("        IF X% < IMG_W THEN"));
    L.push(numbered("          IF (B% AND 2 ^ (7 - K%)) <> 0 THEN C% = 1 ELSE C% = 0"));
    L.push(numbered("          POKE Y% * 320& + X%, C%"));
    L.push(numbered("        END IF"));
    L.push(numbered("      NEXT K%"));
    L.push(numbered("    NEXT XB%"));
    L.push(numbered("  NEXT Y%"));
    L.push(numbered("  DEF SEG"));
    L.push(numbered("RETURN"));
  }
  function loader2(L, numbered, W, H, o) {
    L.push(numbered("LoadImage:"));
    palPreamble(L, numbered, o.palCount);
    L.push(numbered("  DEF SEG = &HA000"));
    L.push(numbered("  RESTORE ImgData"));
    L.push(numbered("  FOR Y% = 0 TO IMG_H - 1"));
    L.push(numbered("    FOR XB% = 0 TO IMG_ROWBYTES - 1"));
    L.push(numbered("      READ B%"));
    L.push(numbered("      FOR K% = 0 TO 3"));
    L.push(numbered("        X% = XB% * 4 + K%"));
    L.push(numbered("        IF X% < IMG_W THEN"));
    L.push(numbered("          C% = (B% \\ 2 ^ (6 - 2 * K%)) AND 3"));
    L.push(numbered("          POKE Y% * 320& + X%, C%"));
    L.push(numbered("        END IF"));
    L.push(numbered("      NEXT K%"));
    L.push(numbered("    NEXT XB%"));
    L.push(numbered("  NEXT Y%"));
    L.push(numbered("  DEF SEG"));
    L.push(numbered("RETURN"));
  }
  function loader4(L, numbered, W, H, o) {
    L.push(numbered("LoadImage:"));
    palPreamble(L, numbered, o.palCount);
    L.push(numbered("  DEF SEG = &HA000"));
    L.push(numbered("  RESTORE ImgData"));
    L.push(numbered("  FOR Y% = 0 TO IMG_H - 1"));
    L.push(numbered("    FOR XB% = 0 TO IMG_ROWBYTES - 1"));
    L.push(numbered("      READ B%"));
    L.push(numbered("      X0% = XB% * 2"));
    L.push(numbered("      POKE Y% * 320& + X0%, B% \\ 16"));
    L.push(numbered("      IF X0% + 1 < IMG_W THEN POKE Y% * 320& + X0% + 1, B% AND 15"));
    L.push(numbered("    NEXT XB%"));
    L.push(numbered("  NEXT Y%"));
    L.push(numbered("  DEF SEG"));
    L.push(numbered("RETURN"));
  }
  function loader8(L, numbered, W, H, o) {
    L.push(numbered("LoadImage:"));
    palPreamble(L, numbered, o.palCount);
    L.push(numbered("  DEF SEG = &HA000"));
    L.push(numbered("  RESTORE ImgData"));
    L.push(numbered("  FOR Y% = 0 TO IMG_H - 1"));
    L.push(numbered("    OFF& = Y% * 320&"));
    L.push(numbered("    FOR X% = 0 TO IMG_W - 1"));
    L.push(numbered("      READ C%"));
    L.push(numbered("      POKE OFF& + X%, C%"));
    L.push(numbered("    NEXT X%"));
    L.push(numbered("  NEXT Y%"));
    L.push(numbered("  DEF SEG"));
    L.push(numbered("RETURN"));
  }
  function loaderStream(L, numbered, W, H, o) {
    var bits = o.bits, mask = (1 << bits) - 1;
    L.push(numbered("LoadImage:"));
    palPreamble(L, numbered, o.palCount);
    L.push(numbered("  ' " + bits + "-bit continuous bit-stream, MSB first"));
    L.push(numbered("  DEF SEG = &HA000"));
    L.push(numbered("  RESTORE ImgData"));
    L.push(numbered("  READ B%"));
    L.push(numbered("  BUF& = B%: HAVE% = 8"));
    L.push(numbered("  MASK% = " + mask));
    L.push(numbered("  FOR Y% = 0 TO IMG_H - 1"));
    L.push(numbered("    OFF& = Y% * 320&"));
    L.push(numbered("    FOR X% = 0 TO IMG_W - 1"));
    L.push(numbered("      WHILE HAVE% < " + bits));
    L.push(numbered("        READ B%: BUF& = BUF& * 256& + B%: HAVE% = HAVE% + 8"));
    L.push(numbered("      WEND"));
    L.push(numbered("      HAVE% = HAVE% - " + bits));
    L.push(numbered("      C% = (BUF& \\ 2 ^ HAVE%) AND MASK%"));
    L.push(numbered("      BUF& = BUF& MOD 2 ^ HAVE%"));
    L.push(numbered("      POKE OFF& + X%, C%"));
    L.push(numbered("    NEXT X%"));
    L.push(numbered("  NEXT Y%"));
    L.push(numbered("  DEF SEG"));
    L.push(numbered("RETURN"));
  }
  function loader16(L, numbered, W, H, o) {
    var is555 = o.fmt16 === "555";
    L.push(numbered("LoadImage:"));
    L.push(numbered("  ' 16-bit " + (is555 ? "RGB555" : "RGB565") + " LO,HI byte pairs -> _RGB32"));
    L.push(numbered("  RESTORE ImgData"));
    L.push(numbered("  FOR Y% = 0 TO IMG_H - 1"));
    L.push(numbered("    FOR X% = 0 TO IMG_W - 1"));
    L.push(numbered("      READ LO%, HI%"));
    L.push(numbered("      V& = LO% + HI% * 256&"));
    if (!is555) {
      L.push(numbered("      R% = (V& \\ 2048) AND 31: G% = (V& \\ 32) AND 63: B% = V& AND 31"));
      L.push(numbered("      PSET (X%, Y%), _RGB32(R% * 255 \\ 31, G% * 255 \\ 63, B% * 255 \\ 31)"));
    } else {
      L.push(numbered("      R% = (V& \\ 1024) AND 31: G% = (V& \\ 32) AND 31: B% = V& AND 31"));
      L.push(numbered("      PSET (X%, Y%), _RGB32(R% * 255 \\ 31, G% * 255 \\ 31, B% * 255 \\ 31)"));
    }
    L.push(numbered("    NEXT X%"));
    L.push(numbered("  NEXT Y%"));
    L.push(numbered("RETURN"));
  }
  function loader24(L, numbered, W, H) {
    L.push(numbered("LoadImage:"));
    L.push(numbered("  RESTORE ImgData"));
    L.push(numbered("  FOR Y% = 0 TO IMG_H - 1"));
    L.push(numbered("    FOR X% = 0 TO IMG_W - 1"));
    L.push(numbered("      READ R%, G%, B%"));
    L.push(numbered("      PSET (X%, Y%), _RGB32(R%, G%, B%)"));
    L.push(numbered("    NEXT X%"));
    L.push(numbered("  NEXT Y%"));
    L.push(numbered("RETURN"));
  }
  function loader32(L, numbered, W, H) {
    L.push(numbered("LoadImage:"));
    L.push(numbered("  RESTORE ImgData"));
    L.push(numbered("  FOR Y% = 0 TO IMG_H - 1"));
    L.push(numbered("    FOR X% = 0 TO IMG_W - 1"));
    L.push(numbered("      READ R%, G%, B%, A%"));
    L.push(numbered("      PSET (X%, Y%), _RGBA32(R%, G%, B%, A%)"));
    L.push(numbered("    NEXT X%"));
    L.push(numbered("  NEXT Y%"));
    L.push(numbered("RETURN"));
  }

  // ===== savers =====
  function saver1(L, numbered, W, H) {
    L.push(numbered("SaveImage:"));
    L.push(numbered("  ' re-packs the screen (non-black = 1) and writes 1 byte per PUT"));
    L.push(numbered('  OPEN "IMG1BIT.BIN" FOR BINARY AS #1'));
    L.push(numbered("  DEF SEG = &HA000"));
    L.push(numbered("  FOR Y% = 0 TO IMG_H - 1"));
    L.push(numbered("    FOR XB% = 0 TO IMG_ROWBYTES - 1"));
    L.push(numbered("      B% = 0"));
    L.push(numbered("      FOR K% = 0 TO 7"));
    L.push(numbered("        X% = XB% * 8 + K%"));
    L.push(numbered("        B% = B% * 2"));
    L.push(numbered("        IF X% < IMG_W THEN"));
    L.push(numbered("          IF PEEK(Y% * 320& + X%) <> 0 THEN B% = B% + 1"));
    L.push(numbered("        END IF"));
    L.push(numbered("      NEXT K%"));
    L.push(numbered("      OB = CHR$(B%): PUT #1, , OB"));
    L.push(numbered("    NEXT XB%"));
    L.push(numbered("  NEXT Y%"));
    L.push(numbered("  DEF SEG: CLOSE #1"));
    L.push(numbered("RETURN"));
  }
  function saver2(L, numbered, W, H) {
    L.push(numbered("SaveImage:"));
    L.push(numbered('  OPEN "IMG2BIT.BIN" FOR BINARY AS #1'));
    L.push(numbered("  DEF SEG = &HA000"));
    L.push(numbered("  FOR Y% = 0 TO IMG_H - 1"));
    L.push(numbered("    FOR XB% = 0 TO IMG_ROWBYTES - 1"));
    L.push(numbered("      B% = 0"));
    L.push(numbered("      FOR K% = 0 TO 3"));
    L.push(numbered("        X% = XB% * 4 + K%: B% = B% * 4"));
    L.push(numbered("        IF X% < IMG_W THEN B% = B% + (PEEK(Y% * 320& + X%) AND 3)"));
    L.push(numbered("      NEXT K%"));
    L.push(numbered("      OB = CHR$(B%): PUT #1, , OB"));
    L.push(numbered("    NEXT XB%"));
    L.push(numbered("  NEXT Y%"));
    L.push(numbered("  DEF SEG: CLOSE #1"));
    L.push(numbered("RETURN"));
  }
  function saver4(L, numbered, W, H) {
    L.push(numbered("SaveImage:"));
    L.push(numbered('  OPEN "IMG4BIT.BIN" FOR BINARY AS #1'));
    L.push(numbered("  DEF SEG = &HA000"));
    L.push(numbered("  FOR Y% = 0 TO IMG_H - 1"));
    L.push(numbered("    FOR XB% = 0 TO IMG_ROWBYTES - 1"));
    L.push(numbered("      X0% = XB% * 2"));
    L.push(numbered("      HI% = PEEK(Y% * 320& + X0%) AND 15"));
    L.push(numbered("      IF X0% + 1 < IMG_W THEN LO% = PEEK(Y% * 320& + X0% + 1) AND 15 ELSE LO% = 0"));
    L.push(numbered("      OB = CHR$(HI% * 16 + LO%): PUT #1, , OB"));
    L.push(numbered("    NEXT XB%"));
    L.push(numbered("  NEXT Y%"));
    L.push(numbered("  DEF SEG: CLOSE #1"));
    L.push(numbered("RETURN"));
  }
  function saver8(L, numbered, W, H) {
    L.push(numbered("SaveImage:"));
    L.push(numbered('  OPEN "IMG8BIT.BIN" FOR BINARY AS #1'));
    L.push(numbered("  DEF SEG = &HA000"));
    L.push(numbered("  FOR Y% = 0 TO IMG_H - 1"));
    L.push(numbered("    FOR X% = 0 TO IMG_W - 1"));
    L.push(numbered("      OB = CHR$(PEEK(Y% * 320& + X%)): PUT #1, , OB"));
    L.push(numbered("    NEXT X%"));
    L.push(numbered("  NEXT Y%"));
    L.push(numbered("  DEF SEG: CLOSE #1"));
    L.push(numbered("RETURN"));
  }
  function saverStream(L, numbered, W, H, o) {
    var bits = o.bits;
    L.push(numbered("SaveImage:"));
    L.push(numbered("  ' packs POINT colors into continuous " + bits + "-bit stream"));
    L.push(numbered('  OPEN "IMG' + bits + 'BIT.BIN" FOR BINARY AS #1'));
    L.push(numbered("  DEF SEG = &HA000"));
    L.push(numbered("  BUF& = 0: HAVE% = 0"));
    L.push(numbered("  FOR Y% = 0 TO IMG_H - 1"));
    L.push(numbered("    FOR X% = 0 TO IMG_W - 1"));
    L.push(numbered("      C% = PEEK(Y% * 320& + X%) AND " + ((1 << bits) - 1)));
    L.push(numbered("      BUF& = BUF& * 2 ^ " + bits + " + C%: HAVE% = HAVE% + " + bits));
    L.push(numbered("      WHILE HAVE% >= 8"));
    L.push(numbered("        HAVE% = HAVE% - 8"));
    L.push(numbered("        B% = BUF& \\ 2 ^ HAVE%: BUF& = BUF& MOD 2 ^ HAVE%"));
    L.push(numbered("        OB = CHR$(B%): PUT #1, , OB"));
    L.push(numbered("      WEND"));
    L.push(numbered("    NEXT X%"));
    L.push(numbered("  NEXT Y%"));
    L.push(numbered('  IF HAVE% > 0 THEN OB = CHR$(BUF& * 2 ^ (8 - HAVE%)): PUT #1, , OB'));
    L.push(numbered("  DEF SEG: CLOSE #1"));
    L.push(numbered("RETURN"));
  }
  function saver16(L, numbered, W, H, o) {
    var is555 = o.fmt16 === "555";
    L.push(numbered("SaveImage:"));
    L.push(numbered("  ' reads 32-bit screen back to " + (is555 ? "RGB555" : "RGB565") + " LO,HI bytes"));
    L.push(numbered('  OPEN "IMG16BIT.BIN" FOR BINARY AS #1'));
    L.push(numbered("  FOR Y% = 0 TO IMG_H - 1"));
    L.push(numbered("    FOR X% = 0 TO IMG_W - 1"));
    L.push(numbered("      C& = POINT(X%, Y%)"));
    L.push(numbered("      R% = _RED32(C&) * " + (is555 ? "31" : "31") + " \\ 255: G% = _GREEN32(C&) * " + (is555 ? "31" : "63") + " \\ 255: B% = _BLUE32(C&) * 31 \\ 255"));
    if (!is555) L.push(numbered("      V& = R% * 2048& + G% * 32& + B%"));
    else L.push(numbered("      V& = R% * 1024& + G% * 32& + B%"));
    L.push(numbered("      OB = CHR$(V& AND 255): PUT #1, , OB"));
    L.push(numbered("      OB = CHR$(V& \\ 256): PUT #1, , OB"));
    L.push(numbered("    NEXT X%"));
    L.push(numbered("  NEXT Y%"));
    L.push(numbered("  CLOSE #1"));
    L.push(numbered("RETURN"));
  }
  function saver24(L, numbered) {
    L.push(numbered("SaveImage:"));
    L.push(numbered('  OPEN "IMG24BIT.BIN" FOR BINARY AS #1'));
    L.push(numbered("  FOR Y% = 0 TO IMG_H - 1"));
    L.push(numbered("    FOR X% = 0 TO IMG_W - 1"));
    L.push(numbered("      C& = POINT(X%, Y%)"));
    L.push(numbered("      R% = _RED32(C&): G% = _GREEN32(C&): B% = _BLUE32(C&)"));
    L.push(numbered("      OB = CHR$(R%): PUT #1, , OB"));
    L.push(numbered("      OB = CHR$(G%): PUT #1, , OB"));
    L.push(numbered("      OB = CHR$(B%): PUT #1, , OB"));
    L.push(numbered("    NEXT X%"));
    L.push(numbered("  NEXT Y%"));
    L.push(numbered("  CLOSE #1"));
    L.push(numbered("RETURN"));
  }
  function saver32(L, numbered) {
    L.push(numbered("SaveImage:"));
    L.push(numbered('  OPEN "IMG32BIT.BIN" FOR BINARY AS #1'));
    L.push(numbered("  FOR Y% = 0 TO IMG_H - 1"));
    L.push(numbered("    FOR X% = 0 TO IMG_W - 1"));
    L.push(numbered("      C& = POINT(X%, Y%)"));
    L.push(numbered("      R% = _RED32(C&): G% = _GREEN32(C&): B% = _BLUE32(C&): A% = _ALPHA32(C&)"));
    L.push(numbered("      OB = CHR$(R%): PUT #1, , OB"));
    L.push(numbered("      OB = CHR$(G%): PUT #1, , OB"));
    L.push(numbered("      OB = CHR$(B%): PUT #1, , OB"));
    L.push(numbered("      OB = CHR$(A%): PUT #1, , OB"));
    L.push(numbered("    NEXT X%"));
    L.push(numbered("  NEXT Y%"));
    L.push(numbered("  CLOSE #1"));
    L.push(numbered("RETURN"));
  }

  window.QBConv = {
    EGA16: EGA16,
    DEPTH_INFO: DEPTH_INFO,
    buildPalette: buildPalette,
    quantize: quantize,
    process16: process16,
    packIndices: packIndices,
    buildBAS: buildBAS,
    grayRamp: grayRamp,
    v565toRgb: v565toRgb,
    v555toRgb: v555toRgb
  };
})();
