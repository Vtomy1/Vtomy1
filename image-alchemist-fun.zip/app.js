const { useState, useEffect, useRef, useCallback } = React;
const h = React.createElement;

const MODELS = [
  { id: "nanobanana", label: "Nanobanana 2", tag: "Best Quality", engine: "nano" },
  { id: "gemini", label: "Gemini Flash", tag: "Fast", engine: "nano" },
  { id: "gpt", label: "GPT Image", tag: "Free ∞", engine: "poll" },
  { id: "mistral", label: "Mistral Vision", tag: "Free ∞", engine: "poll" },
  { id: "flux", label: "Flux", tag: "Free ∞", engine: "poll" },
];

const PRESETS = [
  { label: "Anime", prompt: "reimagine as vibrant anime illustration, cel shaded, expressive" },
  { label: "Oil Painting", prompt: "transform into a classical oil painting with thick brush strokes" },
  { label: "Pixel Art", prompt: "convert to retro 16-bit pixel art game sprite style" },
  { label: "Cyberpunk", prompt: "restyle as neon cyberpunk city scene, rain, glowing signs" },
  { label: "Vintage Photo", prompt: "make it a faded vintage 1970s film photograph with grain" },
  { label: "Claymation", prompt: "turn into cute claymation stop-motion figures" },
  { label: "Surprise Me 🎲", prompt: "__RANDOM__" },
];

const RANDOM_PROMPTS = [
  "turn everyone into majestic wizards casting spells",
  "make it underwater with glowing jellyfish everywhere",
  "add a giant friendly dragon photobombing the scene",
  "restyle as a Studio Ghibli watercolor dreamscape",
  "make it look like a vaporwave album cover from 1985",
  "transform into a cozy autumn forest with fireflies",
  "everything is now made of stained glass and light",
];

const LOADING_MSGS = [
  "Consulting the pixel spirits...",
  "Bribing the AI with cookies...",
  "Mixing colors in the cauldron...",
  "Convincing electrons to cooperate...",
  "Summoning your masterpiece...",
  "Teaching the model good taste...",
];

const load = (k, f) => { try { return JSON.parse(localStorage.getItem(k)) || f; } catch { return f; } };
const save = (k, v) => localStorage.setItem(k, JSON.stringify(v));

function fileToDataURL(file) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result);
    r.onerror = rej;
    r.readAsDataURL(file);
  });
}

const App = () => {
  const [image, setImage] = useState(null); // data URL or remote URL
  const [prompt, setPrompt] = useState(load("alchemist-settings", {}).lastPrompt || "");
  const [model, setModel] = useState(load("alchemist-settings", {}).model || "nanobanana");
  const [loading, setLoading] = useState(false);
  const [loadMsg, setLoadMsg] = useState(LOADING_MSGS[0]);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [history, setHistory] = useState([]);
  const [gallery, setGallery] = useState(load("alchemist-gallery", []));
  const [dragOver, setDragOver] = useState(false);
  const [showBefore, setShowBefore] = useState(false);
  const [modal, setModal] = useState(null);
  const fileRef = useRef();

  useEffect(() => { save("alchemist-settings", { lastPrompt: prompt, model }); }, [prompt, model]);
  useEffect(() => { save("alchemist-gallery", gallery); }, [gallery]);

  useEffect(() => {
    if (!loading) return;
    let i = 0;
    const t = setInterval(() => { i++; setLoadMsg(LOADING_MSGS[i % LOADING_MSGS.length]); }, 1800);
    return () => clearInterval(t);
  }, [loading]);

  // paste image
  useEffect(() => {
    const onPaste = async (e) => {
      for (const item of e.clipboardData.items) {
        if (item.type.startsWith("image/")) {
          const url = await fileToDataURL(item.getAsFile());
          setImage(url); setResult(null);
        }
      }
    };
    window.addEventListener("paste", onPaste);
    return () => window.removeEventListener("paste", onPaste);
  }, []);

  const handleFile = async (file) => {
    if (!file || !file.type.startsWith("image/")) return;
    const url = await fileToDataURL(file);
    setImage(url); setResult(null); setError(null);
  };

  const onDrop = (e) => {
    e.preventDefault(); setDragOver(false);
    if (e.dataTransfer.files[0]) handleFile(e.dataTransfer.files[0]);
  };

  const feelingLucky = async () => {
    setError(null);
    try {
      // random dog as a fun seed image
      const r = await fetch("https://dog.ceo/api/breeds/image/random");
      const d = await r.json();
      setImage(d.message); setResult(null);
    } catch {
      setError("The random image gremlins are on break. Try uploading one!");
    }
  };

  const applyPreset = (p) => {
    let txt = p.prompt;
    if (txt === "__RANDOM__") txt = RANDOM_PROMPTS[Math.floor(Math.random() * RANDOM_PROMPTS.length)];
    setPrompt(prev => prev ? prev.trim() + ", " + txt : txt);
  };

  const transform = useCallback(async () => {
    if (!image || !prompt.trim()) return;
    setLoading(true); setError(null); setResult(null); setShowBefore(false);
    const chosen = MODELS.find(m => m.id === model);
    try {
      let out;
      if (chosen.engine === "nano") {
        // true image-to-image via Nanobanana POST
        let base64 = image;
        if (image.startsWith("http")) {
          // fetch remote and convert
          const blob = await (await fetch(image)).blob();
          base64 = await new Promise(res => { const r = new FileReader(); r.onload = () => res(r.result); r.readAsDataURL(blob); });
        }
        const resp = await fetch("/api/nanobanana/image", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ prompt: prompt.trim(), base_image_base64: base64, strength: 0.75, width: 1024, height: 1024 }),
        });
        if (!resp.ok) throw new Error("nano fail");
        // endpoint redirects to cached image; use response URL
        out = resp.url;
      } else {
        // Pollinations text->image (uses prompt describing edit)
        const seed = Math.floor(Math.random() * 99999);
        const modelMap = { gpt: "gptimage", mistral: "flux", flux: "flux" };
        const pm = modelMap[chosen.id] || "flux";
        out = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt.trim() + ", high quality, detailed")}?model=${pm}&width=1024&height=1024&nologo=true&seed=${seed}`;
      }
      // preload to catch errors
      await new Promise((res, rej) => {
        const im = new Image();
        im.onload = res; im.onerror = () => rej(new Error("load fail"));
        im.src = out;
      });
      setResult(out);
      setHistory(hprev => [...hprev, image]);
    } catch (e) {
      setError("That model got performance anxiety 😅 Try another one or hit Regenerate.");
    } finally {
      setLoading(false);
    }
  }, [image, prompt, model]);

  const useAsInput = () => {
    if (!result) return;
    setImage(result); setResult(null); setShowBefore(false);
  };

  const undo = () => {
    if (!history.length) return;
    const prev = history[history.length - 1];
    setHistory(history.slice(0, -1));
    setImage(prev); setResult(null);
  };

  const saveToGallery = () => {
    if (!result) return;
    const item = { id: Date.now() + "-" + Math.random().toString(36).slice(2, 5), src: result, prompt, model: MODELS.find(m => m.id === model).label, createdAt: Date.now() };
    setGallery(g => [item, ...g].slice(0, 30));
  };

  const download = async (src, name) => {
    try {
      const blob = await (await fetch(src)).blob();
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = name || "alchemist.png";
      a.click();
      URL.revokeObjectURL(a.href);
    } catch {
      window.open(src, "_blank");
    }
  };

  const canGo = image && prompt.trim() && !loading;

  // ---------- UI ----------
  return h("div", { className: "min-h-screen text-slate-100" },
    // Header
    h("header", { className: "relative overflow-hidden pt-10 pb-8 px-4 text-center" },
      h("div", { className: "spark text-5xl md:text-6xl mb-2" }, "🎨"),
      h("h1", { className: "title text-4xl md:text-6xl font-extrabold leading-none" },
        h("span", { className: "grad-text" }, "AI Image Alchemist")),
      h("p", { className: "mt-3 text-slate-400 max-w-xl mx-auto text-sm md:text-base" },
        "Turn any picture into something new. Free. Unlimited. Zero judgment on your weird prompts.")
    ),

    // Main
    h("main", { className: "max-w-6xl mx-auto px-4 grid md:grid-cols-2 gap-6 pb-10" },

      // LEFT
      h("section", { className: "panel p-5 space-y-5" },
        h("h2", { className: "sec-title" }, "The Cauldron 🧪"),

        // dropzone
        image
          ? h("div", { className: "relative rounded-2xl overflow-hidden border border-fuchsia-500/30 bg-black/30" },
              h("img", { src: image, className: "w-full max-h-72 object-contain" }),
              h("button", { onClick: () => { setImage(null); setResult(null); }, className: "absolute top-2 right-2 bg-black/70 hover:bg-red-600 text-white text-xs px-3 py-1 rounded-full transition" }, "✕ Remove"))
          : h("div", {
              onClick: () => fileRef.current.click(),
              onDragOver: e => { e.preventDefault(); setDragOver(true); },
              onDragLeave: () => setDragOver(false),
              onDrop,
              className: `drop cursor-pointer rounded-2xl border-2 border-dashed p-8 text-center transition ${dragOver ? "border-fuchsia-400 bg-fuchsia-500/10" : "border-slate-600 hover:border-fuchsia-500/60"}`
            },
            h("div", { className: "text-4xl mb-2" }, "📤"),
            h("p", { className: "text-slate-300 font-semibold" }, "Drop an image, click to upload, or paste"),
            h("p", { className: "text-slate-500 text-xs mt-1" }, "PNG / JPG / WebP")
          ),
        h("input", { ref: fileRef, type: "file", accept: "image/*", className: "hidden", onChange: e => handleFile(e.target.files[0]) }),
        !image && h("button", { onClick: feelingLucky, className: "text-xs text-fuchsia-400 hover:text-fuchsia-300 underline underline-offset-2" }, "🎲 Feeling lucky? Grab a random image"),

        // prompt
        h("div", null,
          h("label", { className: "label" }, "Describe your transformation"),
          h("textarea", {
            value: prompt,
            onChange: e => setPrompt(e.target.value),
            rows: 3,
            placeholder: "Make it a watercolor painting... turn this into a cyberpunk city... add a golden retriever wearing sunglasses...",
            className: "w-full mt-1 rounded-xl bg-black/40 border border-slate-700 focus:border-fuchsia-500 focus:outline-none p-3 text-sm resize-none"
          })
        ),

        // presets
        h("div", { className: "flex flex-wrap gap-2" },
          PRESETS.map(p => h("button", {
            key: p.label, onClick: () => applyPreset(p),
            className: "chip text-xs px-3 py-1.5 rounded-full border border-slate-600 hover:border-fuchsia-400 hover:bg-fuchsia-500/10 transition"
          }, p.label))
        ),

        // model
        h("div", null,
          h("label", { className: "label" }, "Choose your model"),
          h("div", { className: "grid grid-cols-2 sm:grid-cols-3 gap-2 mt-1" },
            MODELS.map(m => h("button", {
              key: m.id, onClick: () => setModel(m.id),
              className: `text-left rounded-xl border p-2.5 transition ${model === m.id ? "border-fuchsia-400 bg-fuchsia-500/15" : "border-slate-700 hover:border-slate-500"}`
            },
              h("div", { className: "text-sm font-bold" }, m.label),
              h("span", { className: "inline-block mt-1 text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono" }, m.tag)
            ))
          )
        ),

        h("button", {
          onClick: transform, disabled: !canGo,
          className: `w-full py-3.5 rounded-xl font-extrabold text-lg transition ${canGo ? "cta-glow bg-gradient-to-r from-fuchsia-600 via-pink-600 to-orange-500 hover:brightness-110" : "bg-slate-700 text-slate-400 cursor-not-allowed"}`
        }, loading ? "✨ Brewing... ✨" : "✨ Transform It ✨")
      ),

      // RIGHT
      h("section", { className: "panel p-5 space-y-4 flex flex-col" },
        h("h2", { className: "sec-title" }, "The Result 🖼️"),
        h("div", { className: "flex-1 flex items-center justify-center rounded-2xl bg-black/30 border border-slate-700 min-h-[280px] overflow-hidden relative" },
          loading
            ? h("div", { className: "text-center p-6" },
                h("div", { className: "spinner mx-auto mb-4" }),
                h("p", { className: "text-slate-300 font-mono text-sm animate-pulse" }, loadMsg))
            : result
              ? h("img", { src: (showBefore && image) ? image : result, className: "w-full h-full object-contain" })
              : error
                ? h("p", { className: "text-red-400 text-center px-6 text-sm" }, error)
                : h("p", { className: "text-slate-600 text-center px-6" }, "Your transformed masterpiece will appear here.")
        ),
        result && !loading && h("div", { className: "space-y-2" },
          image && h("button", { onMouseDown: () => setShowBefore(true), onMouseUp: () => setShowBefore(false), onMouseLeave: () => setShowBefore(false), onTouchStart: () => setShowBefore(true), onTouchEnd: () => setShowBefore(false), className: "w-full text-xs py-2 rounded-lg border border-slate-600 hover:bg-slate-700/50" }, "👁 Hold to see Before"),
          h("div", { className: "grid grid-cols-2 gap-2" },
            h("button", { onClick: () => download(result, "alchemist-" + Date.now() + ".png"), className: "act" }, "⬇ Download"),
            h("button", { onClick: useAsInput, className: "act" }, "🔁 Use as Input"),
            h("button", { onClick: saveToGallery, className: "act" }, "💾 Save"),
            h("button", { onClick: transform, className: "act" }, "🔄 Regenerate")
          )
        ),
        history.length > 0 && h("button", { onClick: undo, className: "text-xs text-slate-400 hover:text-slate-200 underline underline-offset-2 self-start" }, `↩ Undo (${history.length} step${history.length>1?"s":""})`)
      )
    ),

    // Gallery
    gallery.length > 0 && h("section", { className: "max-w-6xl mx-auto px-4 pb-14" },
      h("h2", { className: "sec-title mb-3" }, "Your Creations"),
      h("div", { className: "grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3" },
        gallery.map(g => h("button", {
          key: g.id, onClick: () => setModal(g),
          className: "group relative rounded-xl overflow-hidden border border-slate-700 hover:border-fuchsia-400 transition aspect-square"
        },
          h("img", { src: g.src, className: "w-full h-full object-cover group-hover:scale-105 transition" }),
          h("div", { className: "absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 to-transparent p-2 text-left" },
            h("p", { className: "text-[10px] text-slate-300 line-clamp-2" }, g.prompt))
        ))
      )
    ),

    // Modal
    modal && h("div", { className: "fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4", onClick: () => setModal(null) },
      h("div", { className: "panel p-4 max-w-lg w-full space-y-3", onClick: e => e.stopPropagation() },
        h("img", { src: modal.src, className: "w-full rounded-xl max-h-[60vh] object-contain bg-black/40" }),
        h("p", { className: "text-sm text-slate-300" }, h("span", { className: "text-fuchsia-400 font-bold" }, "Prompt: "), modal.prompt),
        h("p", { className: "text-xs text-slate-500 font-mono" }, modal.model + " · " + new Date(modal.createdAt).toLocaleString()),
        h("div", { className: "flex gap-2" },
          h("button", { onClick: () => download(modal.src, "alchemist.png"), className: "act flex-1" }, "⬇ Download"),
          h("button", { onClick: () => { setImage(modal.src); setResult(null); setModal(null); window.scrollTo({top:0,behavior:"smooth"}); }, className: "act flex-1" }, "🔁 Remix"),
          h("button", { onClick: () => { setGallery(gl => gl.filter(x => x.id !== modal.id)); setModal(null); }, className: "act flex-1 hover:!bg-red-600/40" }, "🗑 Delete"),
          h("button", { onClick: () => setModal(null), className: "act flex-1" }, "Close")
        )
      )
    ),

    // Footer
    h("footer", { className: "text-center text-xs text-slate-500 pb-8 px-4 space-y-1" },
      h("p", null, "© 2026 AI Image Alchemist · \"Unlimited\" subject to the AI's mood and rate limits 😅"),
      h("p", null, h("a", { href: "/remix", className: "text-fuchsia-400 hover:text-fuchsia-300 underline underline-offset-2" }, "Remix on Berrry"))
    )
  );
};

ReactDOM.createRoot(document.getElementById("root")).render(h(App));