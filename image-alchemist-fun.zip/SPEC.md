# AI Image Alchemist 🎨✨

Create a fun, powerful **image-to-image transformation studio** that lets users upload any image and reimagine it with AI. The app leverages the Nanobanana 2 (Gemini image editing) and Pollinations APIs to transform, remix, and restyle images based on text prompts. The playful branding leans into the "free unlimited" promise with a wink — because who doesn't love unlimited creativity?

This is best built as a **React Web App** — it needs file uploads, prompt inputs, model selection, image display, loading states, and a gallery of past creations. Lots of interactive state management.

## UI Elements

### Header

A bold, gradient header (purple → pink → orange) with the app name **"AI Image Alchemist"** and a floating 🎨 emoji. Below it, a cheeky tagline: *"Turn any picture into something new. Free. Unlimited. Zero judgment on your weird prompts."* Include a small animated "sparkle" effect on the emoji.

### Main Content Area — Two-Panel Layout

Split into a **left "Input" panel** and a **right "Output" panel** on desktop; stacked vertically on mobile.

#### Left Panel — The Cauldron 🧪

1. **Image Upload Dropzone**
   - Large dashed-border drop area with a "Drop an image here or click to upload" message and an upload icon.
   - Support drag-and-drop and click-to-browse (accept PNG/JPG/WebP, up to 10MB).
   - Once uploaded, show a thumbnail preview with a small "✕ Remove" button.

2. **Transformation Prompt**
   - A multi-line textarea labeled "Describe your transformation" with placeholder examples like *"Make it a watercolor painting"*, *"Turn this into a cyberpunk city"*, *"Add a golden retriever wearing sunglasses"*.
   - A row of **quick-preset chips** below it: `Anime`, `Oil Painting`, `Pixel Art`, `Cyberpunk`, `Vintage Photo`, `Claymation`, `Surprise Me 🎲`. Clicking a chip fills/appends the prompt.

3. **Model Selector**
   - A styled dropdown or segmented control labeled "Choose your model" listing available models: `Nanobanana 2 (Best Quality)`, `GPT Image`, `Gemini Flash`, `Mistral Vision`, `Flux`. All badged with a green **"FREE ∞"** pill to reinforce the theme.

4. **Big Transform Button**
   - A prominent gradient CTA button: **"✨ Transform It ✨"** with a subtle glow/pulse animation. Disabled until an image + prompt are present.

#### Right Panel — The Result 🖼️

- Shows a **loading state** while generating: an animated shimmer/spinner with rotating fun status messages (*"Consulting the pixel spirits..."*, *"Bribing the AI with cookies..."*, *"Mixing colors..."*).
- Displays the generated image large and centered once ready.
- Below it, action buttons: **Download**, **Use as New Input** (feeds output back for iterative editing), **Save to Gallery**, and **Regenerate 🔄**.
- A "before/after" toggle or side-by-side slider comparing original vs. transformed.

### Gallery Section

Below the main panels, a **"Your Creations"** grid gallery of saved transformations (persisted via backend data storage / localStorage). Each thumbnail opens a modal showing the image, the prompt used, the model, and download/delete options. Optionally include a **"Community Wall"** tab showing publicly shared creations from other users (via public data sharing).

### Footer

A light footer with a copyright notice, an honest little disclaimer (*"'Unlimited' subject to the AI's mood and rate limits 😅"*), and the required link: `<a href="/remix">Remix on Berrry</a>`.

## Styling Preferences

- Modern, vibrant, playful aesthetic using **Tailwind CSS**.
- Gradient accents (purple/pink/orange), rounded corners (`rounded-2xl`), soft shadows, and generous spacing.
- Dark-mode-friendly with a deep slate background and glowing accent elements for a "creative studio" vibe.
- Smooth transitions on hover, button presses, and image loads.
- Fully responsive: two-column on desktop, single-column stacked on mobile with appropriately scaled fonts and touch-friendly buttons.

## Functionality

- **Image-to-image transformation**: Send the uploaded image + prompt to the Nanobanana 2 / Pollinations image APIs and display the returned result.
- **Iterative editing**: "Use as New Input" replaces the source image with the latest output so users can chain transformations.
- **Preset prompts** for one-tap styling; "Surprise Me" injects a random creative prompt.
- **Persistence**: Save creations to the gallery using backend data storage; support public sharing to a community wall.
- **Download** generated images as files.
- **Graceful error handling**: If a model fails or rate-limits, show a friendly message and offer to retry with a different model.
- **Loading feedback**: Rotating whimsical status messages keep users entertained during generation.

## Additional Features

- **History/undo** for iterative edits so users can step back to a previous version.
- **Random image seed**: A "Feeling lucky?" button that fetches a random image (from the random images API) to transform when the user has nothing to upload.
- **Share button** that copies a link to a publicly shared creation.
- Keep the tone light and fun throughout — the microcopy should make people smile while they create.