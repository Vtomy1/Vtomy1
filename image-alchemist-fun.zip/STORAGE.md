# Storage Design - AI Image Alchemist

## Data Requirements
- **Local Storage**: Gallery of saved creations (image URLs + prompts + model + timestamp), UI settings (selected model, last prompt)
- **Backend Storage**: Optional — none required for core functionality; images are served from Nanobanana/Pollinations cached URLs

## Storage Strategy
### Offline-First
- All creations saved to localStorage under `alchemist-gallery`
- Settings saved under `alchemist-settings`
- No auth required; fully client-side

### Data Structures
```json
// localStorage: alchemist-gallery
[
  {
    "id": "1699999999-abc",
    "src": "/api/nanobanana/image/1024/1024?prompt=...",
    "prompt": "watercolor painting",
    "model": "Nanobanana 2",
    "createdAt": 1699999999
  }
]

// localStorage: alchemist-settings
{ "model": "nanobanana", "lastPrompt": "" }
```

## Implementation Notes
- Image transforms use Nanobanana POST (`base_image_base64`) for true image-to-image
- Pollinations fallback for text-driven image gen with image reference
- Gallery capped at 30 items to avoid localStorage bloat