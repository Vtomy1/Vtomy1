# Current task — GPT Image Studio (image-to-image)

## User ask (repeated)
"image to image gpt image all models free unlimited without api keys"

## Reality (verified with tests, Nov 2026)
- Truly keyless GPT-image-class img2img does not exist: Pollinations Classic
  ignores `?image=` (falls back to sana — confirmed via EXIF `actualModel`
  + pixel-identical outputs); `gen.pollinations.ai` needs a key (401);
  HF Spaces ZeroGPU needs login ("exceeded ZeroGPU runs").
- Delivered instead: 3-mode studio, honest about what needs the free key.

## Done
- [x] True Edit (keyed POST /v1/images/edits, multi-ref, all-model catalog)
- [x] No-Key Remix (vision caption + free-tier draw) — verified e2e
- [x] Generate (keyless Classic w/ 402 auto-retry, or keyed exact-model) — verified e2e
- [x] Honest KEY gating (no fake fallback images), sk_ vs pk_ guidance
- [x] History, compare view, download/copy/reuse-as-input
- [x] Desktop + phone snapshot checks
- [x] src/README.md

## Left / notes
- Full keyed-edit pass needs a real user `sk_…` (agent has no account).
- If user insists on zero-key true edits, only remaining avenue is in-browser
  WebGPU diffusion (heavy, SD-level quality) — ask before building.
