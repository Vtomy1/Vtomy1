# Mascot Maker

Image → mascot generator. Upload a photo (or type a description) → AI vision extracts a
**Subject Token** → mascot image via `text-to-image-plugin`, plus a universal prompt
that works in Midjourney / SDXL / Flux / DALL·E / Firefly.

Canonical mascot: `src/images/mascot-logo.jpg` (orange fox, cream belly, white-tipped
tail, tiny blue hoodie). It is the header logo, `$meta.image`/`icon`, and the default
Subject Token so all 8 styles keep the same character.

- `main.pjs` — imports (`generateImage`, `generateText`), `$meta`, style/expression lists
- `index.html` — full app (upload, styles, result, copy-paste prompts, gallery)
