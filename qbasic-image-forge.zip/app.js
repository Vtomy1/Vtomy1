const h = React.createElement;
const { useState, useEffect, useRef, useMemo } = React;

// ---------- Palettes ----------
const EGA = [[0,0,0],[0,0,170],[0,170,0],[0,170,170],[170,0,0],[170,0,170],[170,85,0],[170,170,170],[85,85,85],[85,85,255],[85,255,85],[85,255,255],[255,85,85],[255,85,255],[255,255,85],[255,255,255]];
function vgaPal(){const p=EGA.slice();for(let i=0;i<16;i++){const v=Math.round(i*255/15);p.push([v,v,v]);}
  const lv=[0,51,102,153,204,255];for(const r of lv)for(const g of lv)for(const b of lv){if(p.length<256)p.push([r,g,b]);}
  while(p.length<256)p.push([0,0,0]);return p;}
const VGA = vgaPal();
function defaultPal(bpp){return bpp===1?[[0,0,0],[255,255,255]]:bpp===4?EGA:VGA;}
function medianCut(data,n){
  const px=[];const step=Math.max(1,Math.floor(data.length/4/20000));
  for(let i=0;i<data.length;i+=4*step)px.push([data[i],data[i+1],data[i+2]]);
  let boxes=[px];
  while(boxes.length<n){boxes.sort((a,b)=>b.length-a.length);const bx=boxes.shift();if(bx.length<2){boxes.push(bx);break;}
    let ch=0,best=-1;for(let c=0;c<3;c++){let mn=255,mx=0;for(const p of bx){if(p[c]<mn)mn=p[c];if(p[c]>mx)mx=p[c];}if(mx-mn>best){best=mx-mn;ch=c;}}
    bx.sort((a,b)=>a[ch]-b[ch]);const m=bx.length>>1;boxes.push(bx.slice(0,m),bx.slice(m));}
  const pal=boxes.map(b=>{const s=[0,0,0];for(const p of b){s[0]+=p[0];s[1]+=p[1];s[2]+=p[2];}return s.map(v=>Math.round(v/Math.max(1,b.length)));});
  while(pal.length<n)pal.push([0,0,0]);return pal;}

// ---------- Dithering ----------
const KERNELS={
  fs:[[1,0,7],[-1,1,3],[0,1,5],[1,1,1],16],
  atkinson:[[1,0,1],[2,0,1],[-1,1,1],[0,1,1],[1,1,1],[0,2,1],8],
  jjn:[[1,0,7],[2,0,5],[-2,1,3],[-1,1,5],[0,1,7],[1,1,5],[2,1,3],[-2,2,1],[-1,2,3],[0,2,5],[1,2,3],[2,2,1],48],
  sierra:[[1,0,2],[-1,1,1],[0,1,1],4]};
function bayer(n){if(n===1)return[[0]];const m=bayer(n/2),r=[];for(let y=0;y<n;y++){r.push([]);for(let x=0;x<n;x++){const q=m[y%(n/2)][x%(n/2)]*4;r[y].push(q+[[0,2],[3,1]][Math.floor(y/(n/2))][Math.floor(x/(n/2))]);}}return r;}
const DITHERS=[["none","None (posterize)"],["fs","Floyd-Steinberg"],["atkinson","Atkinson"],["b2","Bayer 2x2"],["b4","Bayer 4x4"],["b8","Bayer 8x8"],["jjn","Jarvis-Judice-Ninke"],["sierra","Sierra Lite"],["noise","Random Noise"]];

function nearestFn(pal){const cache=new Map();return(r,g,b)=>{r=r<0?0:r>255?255:r;g=g<0?0:g>255?255:g;b=b<0?0:b>255?255:b;
  const k=((r>>2)<<12)|((g>>2)<<6)|(b>>2);let v=cache.get(k);if(v!==undefined)return v;let bd=1e9;v=0;
  for(let i=0;i<pal.length;i++){const p=pal[i],dr=r-p[0],dg=g-p[1],db=b-p[2],d=dr*dr*.3+dg*dg*.59+db*db*.11;if(d<bd){bd=d;v=i;}}cache.set(k,v);return v;};}

function convert(src,s){
  const w=s.w,hh=s.h;const c=document.createElement('canvas');c.width=w;c.height=hh;const x=c.getContext('2d');
  x.fillStyle='#000';x.fillRect(0,0,w,hh);x.imageSmoothingQuality='high';x.drawImage(src,0,0,w,hh);
  const d=x.getImageData(0,0,w,hh).data;const f=new Float32Array(w*hh*3);
  const ct=s.contrast,br=s.brightness,gm=s.gamma,th=s.bpp===1?(128-s.threshold):0;
  for(let i=0,j=0;i<d.length;i+=4,j+=3){let r=d[i],g=d[i+1],b=d[i+2];
    if(s.bpp===1){const l=r*.299+g*.587+b*.114;r=g=b=l;}
    for(let k=0;k<3;k++){let v=[r,g,b][k];v=Math.pow(v/255,1/gm)*255;v=(v-128)*ct+128+br+th;if(s.invert)v=255-v;f[j+k]=v;}}
  let pal=s.palette==='opt'&&s.bpp>1?medianCut(d,s.bpp===4?16:256):defaultPal(s.bpp);
  const near=nearestFn(pal);const idx=new Uint8Array(w*hh);const spread=s.bpp===1?255:s.bpp===4?90:40;
  const kern=KERNELS[s.dither];const bm=s.dither[0]==='b'?bayer(+s.dither[1]):null;
  for(let y=0;y<hh;y++){const rev=kern&&s.serp&&(y&1);
    for(let xi=0;xi<w;xi++){const xx=rev?w-1-xi:xi;const p=(y*w+xx)*3;let r=f[p],g=f[p+1],b=f[p+2];
      if(bm){const n=bm.length;const t=((bm[y%n][xx%n]+.5)/(n*n)-.5)*spread;r+=t;g+=t;b+=t;}
      else if(s.dither==='noise'){const t=(Math.random()-.5)*spread;r+=t;g+=t;b+=t;}
      const ci=near(r,g,b);idx[y*w+xx]=ci;
      if(kern){const q=pal[ci],er=r-q[0],eg=g-q[1],eb=b-q[2],dv=kern[kern.length-1];
        for(let k=0;k<kern.length-1;k++){let[dx,dy,wt]=kern[k];if(rev)dx=-dx;const nx=xx+dx,ny=y+dy;if(nx<0||nx>=w||ny>=hh)continue;
          const o=(ny*w+nx)*3,m=wt/dv;f[o]+=er*m;f[o+1]+=eg*m;f[o+2]+=eb*m;}}}}
  return{idx,pal,w,h:hh,bpp:s.bpp};}

// ---------- File format ----------
function packRows(r){const rb=Math.ceil(r.w*r.bpp/8),out=new Uint8Array(rb*r.h);
  for(let y=0;y<r.h;y++)for(let x=0;x<r.w;x++){const v=r.idx[y*r.w+x],o=y*rb;
    if(r.bpp===8)out[o+x]=v;else if(r.bpp===4)out[o+(x>>1)]|=(x&1)?v&15:(v&15)<<4;else if(v)out[o+(x>>3)]|=0x80>>(x&7);}
  return out;}
function buildQBI(r){const px=packRows(r),n=r.pal.length,hd=12+n*3,b=new Uint8Array(hd+px.length);
  b.set([81,66,73,77],0);b[4]=1;b[5]=r.bpp;b[6]=r.w&255;b[7]=r.w>>8;b[8]=r.h&255;b[9]=r.h>>8;b[10]=n&255;b[11]=n>>8;
  r.pal.forEach((p,i)=>{b[12+i*3]=p[0]>>2;b[13+i*3]=p[1]>>2;b[14+i*3]=p[2]>>2;});b.set(px,hd);return b;}
function parseQBI(b){if(String.fromCharCode(b[0],b[1],b[2],b[3])!=='QBIM')throw Error('Bad magic - this is not a QBIM file (or it is, and I am wrong. unlikely.)');
  const bpp=b[5],w=b[6]|b[7]<<8,hh=b[8]|b[9]<<8,n=b[10]|b[11]<<8,pal=[];
  for(let i=0;i<n;i++)pal.push([b[12+i*3]<<2,b[13+i*3]<<2,b[14+i*3]<<2]);
  const rb=Math.ceil(w*bpp/8),o=12+n*3,idx=new Uint8Array(w*hh);
  for(let y=0;y<hh;y++)for(let x=0;x<w;x++){const q=o+y*rb;idx[y*w+x]=bpp===8?b[q+x]:bpp===4?((x&1)?b[q+(x>>1)]&15:b[q+(x>>1)]>>4):(b[q+(x>>3)]>>(7-(x&7)))&1;}
  return{idx,pal,w,h:hh,bpp};}
function buildBSV(r){const L=64000,b=new Uint8Array(7+L);b[0]=0xFD;b[1]=0x00;b[2]=0xA0;b[3]=0;b[4]=0;b[5]=L&255;b[6]=L>>8;
  for(let y=0;y<Math.min(200,r.h);y++)for(let x=0;x<Math.min(320,r.w);x++)b[7+y*320+x]=r.idx[y*r.w+x];return b;}
function render(r,cv){if(!cv||!r)return;cv.width=r.w;cv.height=r.h;const x=cv.getContext('2d'),im=x.createImageData(r.w,r.h);
  for(let i=0;i<r.idx.length;i++){const p=r.pal[r.idx[i]]||[0,0,0];im.data[i*4]=p[0];im.data[i*4+1]=p[1];im.data[i*4+2]=p[2];im.data[i*4+3]=255;}x.putImageData(im,0,0);}

// ---------- QBasic code gen ----------
const SCREENS={7:[320,200,4],9:[640,350,4],11:[640,480,1],12:[640,480,4],13:[320,200,8]};
function genCode(r,scr,name){if(!r)return{};const F=name.toUpperCase();
const palSet=r.bpp===1?"' 1-bit: SCREEN 11 is black & white already. Palette? We don't need no stinkin' palette.\n":
`FOR i = 0 TO nc - 1
  c$ = SPACE$(3): GET #1, , c$
  ' 6-bit VGA DAC values (0-63). Yes, 63. Welcome to 1987.
  PALETTE i, ASC(MID$(c$, 1, 1)) + 256& * ASC(MID$(c$, 2, 1)) + 65536 * ASC(MID$(c$, 3, 1))
NEXT i
`;
const loader=`' LOADER.BAS - QBIM image loader
' Congratulations, you're programming like it's 1991
DEFINT A-Z
SCREEN ${scr}
OPEN "${F}.QBI" FOR BINARY AS #1
magic$ = SPACE$(4): GET #1, , magic$
IF magic$ <> "QBIM" THEN SCREEN 0: PRINT "Not a QBIM file! Did you feed me a JPEG?": END
b$ = " "
GET #1, , b$: ver = ASC(b$)
GET #1, , b$: bpp = ASC(b$)
GET #1, , w: GET #1, , h: GET #1, , nc   ' INTEGERs are 2 bytes, little-endian. Handy!
${r.bpp===1?`c$ = SPACE$(3)\nFOR i = 1 TO nc: GET #1, , c$: NEXT i   ' skip palette\n`:palSet}
rowBytes = (w * bpp + 7) \\ 8
row$ = SPACE$(rowBytes)
FOR y = 0 TO h - 1
  GET #1, , row$
  FOR x = 0 TO w - 1
    SELECT CASE bpp
      CASE 1
        v = ASC(MID$(row$, x \\ 8 + 1, 1))
        c = (v \\ (2 ^ (7 - (x MOD 8)))) AND 1
      CASE 4
        v = ASC(MID$(row$, x \\ 2 + 1, 1))
        IF x MOD 2 = 0 THEN c = v \\ 16 ELSE c = v AND 15
      CASE 8
        c = ASC(MID$(row$, x + 1, 1))
    END SELECT
    PSET (x, y), c
  NEXT x
NEXT y
CLOSE #1
DO: LOOP WHILE INKEY$ = ""   ' Press any key to continue
`;
const pc=r.bpp===1?2:r.bpp===4?16:256;
const saver=`' SAVER.BAS - capture the screen into a QBIM file
' Uses POINT, which is roughly as fast as a sleepy turtle.
DEFINT A-Z
SCREEN ${scr}
' ... draw something glorious here ...
w = ${r.w}: h = ${r.h}: bpp = ${r.bpp}: nc = ${pc}
OPEN "${F}.QBI" FOR BINARY AS #1
magic$ = "QBIM": PUT #1, , magic$
b$ = CHR$(1): PUT #1, , b$
b$ = CHR$(bpp): PUT #1, , b$
PUT #1, , w: PUT #1, , h: PUT #1, , nc
FOR i = 0 TO nc - 1
${r.bpp===1?`  c$ = CHR$(63 * i) + CHR$(63 * i) + CHR$(63 * i)`:`  OUT &H3C7, i   ' read DAC register
  c$ = CHR$(INP(&H3C9)) + CHR$(INP(&H3C9)) + CHR$(INP(&H3C9))`}
  PUT #1, , c$
NEXT i
rowBytes = (w * bpp + 7) \\ 8
FOR y = 0 TO h - 1
  row$ = STRING$(rowBytes, 0)
  FOR x = 0 TO w - 1
    c = POINT(x, y)
    SELECT CASE bpp
      CASE 1
        IF c THEN p = x \\ 8 + 1: MID$(row$, p, 1) = CHR$(ASC(MID$(row$, p, 1)) OR (2 ^ (7 - (x MOD 8))))
      CASE 4
        p = x \\ 2 + 1
        IF x MOD 2 = 0 THEN MID$(row$, p, 1) = CHR$(c * 16) ELSE MID$(row$, p, 1) = CHR$(ASC(MID$(row$, p, 1)) OR c)
      CASE 8
        MID$(row$, x + 1, 1) = CHR$(c)
    END SELECT
  NEXT x
  PUT #1, , row$
NEXT y
CLOSE #1
PRINT "Saved! Now put it on a floppy and mail it to a friend."
`;
const px=packRows(r);const maxB=16000;const lim=Math.min(px.length,maxB);let dl="";
for(let i=0;i<lim;i+=20){dl+="DATA "+Array.from(px.slice(i,Math.min(lim,i+20))).map(v=>v.toString(16).toUpperCase().padStart(2,'0')).join(",")+"\n";}
let pd="";if(r.bpp>1){for(let i=0;i<r.pal.length;i+=8)pd+="DATA "+r.pal.slice(i,i+8).map(p=>p.map(v=>v>>2).join(",")).join(",")+"\n";}
const data=`' DATA.BAS - self-contained image, no files needed
' ${px.length} bytes of pure hexadecimal poetry${px.length>maxB?`\n' WARNING: truncated to ${maxB} bytes - QBasic's 64K code segment has feelings too`:''}
DEFINT A-Z
SCREEN ${scr}
w = ${r.w}: h = ${Math.min(r.h,Math.floor(lim/Math.ceil(r.w*r.bpp/8)))}: bpp = ${r.bpp}
${r.bpp>1?`FOR i = 0 TO ${r.pal.length-1}
  READ cr, cg, cb
  PALETTE i, cr + 256& * cg + 65536 * cb
NEXT i`:"' 1-bit: no palette needed"}
rowBytes = (w * bpp + 7) \\ 8
FOR y = 0 TO h - 1
  FOR bx = 0 TO rowBytes - 1
    READ v$: v = VAL("&H" + v$)
    SELECT CASE bpp
      CASE 1
        FOR k = 0 TO 7
          IF bx * 8 + k < w THEN PSET (bx * 8 + k, y), (v \\ (2 ^ (7 - k))) AND 1
        NEXT k
      CASE 4
        PSET (bx * 2, y), v \\ 16
        IF bx * 2 + 1 < w THEN PSET (bx * 2 + 1, y), v AND 15
      CASE 8
        PSET (bx, y), v
    END SELECT
  NEXT bx
NEXT y
DO: LOOP WHILE INKEY$ = ""
END
${r.bpp>1?"' --- palette (6-bit RGB) ---\n"+pd:""}' --- pixels ---
${dl}`;
const bload=`' BLOAD.BAS - the fast path. SCREEN 13 only, 8-bit only.
' Pixels go straight into video memory at &HA000. Zoom zoom.
DEFINT A-Z
SCREEN 13
${r.bpp===8?`OPEN "${F}.QBI" FOR BINARY AS #1
magic$ = SPACE$(4): GET #1, , magic$
b$ = SPACE$(2): GET #1, , b$
GET #1, , w: GET #1, , h: GET #1, , nc
OUT &H3C8, 0   ' start at DAC register 0, auto-increments
FOR i = 1 TO nc * 3
  b$ = " ": GET #1, , b$: OUT &H3C9, ASC(b$)
NEXT i
CLOSE #1`:"' (Your image is not 8-bit - switch to 8-bit for proper colors!)"}
DEF SEG = &HA000
BLOAD "${F}.BSV", 0
DEF SEG
DO: LOOP WHILE INKEY$ = ""
' To make your own: DEF SEG = &HA000: BSAVE "SCREEN.BSV", 0, 64000
`;
return{"LOADER.BAS":loader,"SAVER.BAS":saver,"DATA.BAS":data,"BLOAD.BAS":bload};}

const KW=/\b(DEFINT|SCREEN|OPEN|FOR|BINARY|AS|GET|PUT|IF|THEN|ELSE|PRINT|END|NEXT|TO|SELECT|CASE|PSET|CLOSE|DO|LOOP|WHILE|INKEY\$|PALETTE|OUT|INP|SPACE\$|STRING\$|ASC|MID\$|CHR\$|AND|OR|MOD|POINT|DATA|READ|VAL|DEF|SEG|BLOAD|BSAVE)\b/g;
function hl(code){const esc=s=>s.replace(/&/g,'&amp;').replace(/</g,'&lt;');
  return code.split("\n").map(l=>{const ci=l.search(/'(?=(?:[^"]*"[^"]*")*[^"]*$)/);let a=ci>=0?l.slice(0,ci):l,c=ci>=0?l.slice(ci):"";
    a=a.split(/("[^"]*")/).map(p=>p[0]==='"'?`<span class="st">${esc(p)}</span>`:esc(p).replace(/\b(\d+)\b/g,'<span class="nm">$1</span>').replace(KW,'<span class="kw">$1</span>')).join("");
    return a+(c?`<span class="cm">${esc(c)}</span>`:"");}).join("\n");}

function dl(name,data,type){const b=data instanceof Blob?data:new Blob([data],{type:type||'application/octet-stream'});const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);}

function samplePattern(){const c=document.createElement('canvas');c.width=320;c.height=200;const x=c.getContext('2d');
  const g=x.createLinearGradient(0,0,320,0);['#f00','#ff0','#0f0','#0ff','#00f','#f0f'].forEach((col,i)=>g.addColorStop(i/5,col));x.fillStyle=g;x.fillRect(0,0,320,100);
  const g2=x.createLinearGradient(0,0,320,0);g2.addColorStop(0,'#000');g2.addColorStop(1,'#fff');x.fillStyle=g2;x.fillRect(0,100,320,40);
  const rg=x.createRadialGradient(80,170,2,80,170,60);rg.addColorStop(0,'#fff');rg.addColorStop(.5,'#e83');rg.addColorStop(1,'#203');x.fillStyle=rg;x.fillRect(0,140,160,60);
  x.fillStyle='#113';x.fillRect(160,140,160,60);x.fillStyle='#fe5';x.font='bold 22px monospace';x.fillText('QBASIC',180,170);x.fillStyle='#5ff';x.fillText('4EVER',190,192);
  x.fillStyle='#fff';x.beginPath();x.arc(290,40,14,0,7);x.fill();return c;}

const DEF={bpp:4,scr:12,w:160,h:100,lock:true,dither:'fs',brightness:0,contrast:1,gamma:1,threshold:128,serp:true,invert:false,palette:'default',zoom:2,name:'IMAGE',crt:true};
const load=()=>{try{return{...DEF,...JSON.parse(localStorage.getItem('qbforge')||'{}')};}catch{return DEF;}};

function Win(p){return h('div',{className:'win '+(p.className||''),style:{animationDelay:(p.d||0)+'s'}},h('div',{className:'ttl'},p.title),p.children);}
function Btn(p){return h('button',{className:'btn '+(p.on?'on':''),onClick:p.onClick,title:p.title},'< '+p.children+' >');}

function App(){
  const[s,setS]=useState(load);const[src,setSrc]=useState(null);const[res,setRes]=useState(null);const[tab,setTab]=useState('LOADER.BAS');
  const[hover,setHover]=useState(null);const[over,setOver]=useState(false);const[msg,setMsg]=useState('');const[verify,setVerify]=useState(null);const[run,setRun]=useState(false);const[help,setHelp]=useState(false);const[fmt,setFmt]=useState('qbi');
  const origRef=useRef(),outRef=useRef(),verRef=useRef(),runRef=useRef(),fileRef=useRef(),verFileRef=useRef();
  const set=(k,v)=>setS(o=>{const n={...o,[k]:v};if(k==='w'&&o.lock&&src)n.h=Math.max(1,Math.round(v*src.height/src.width));if(k==='h'&&o.lock&&src)n.w=Math.max(1,Math.round(v*src.width/src.height));return n;});
  useEffect(()=>{localStorage.setItem('qbforge',JSON.stringify(s));},[s]);
  useEffect(()=>{setSrc(samplePattern());},[]);
  const loadFile=f=>{if(!f||!f.type.startsWith('image/')){setMsg('That is not an image. I may be old, but I am not stupid.');return;}
    const im=new Image();im.onload=()=>{setSrc(im);setMsg('Loaded '+f.name);setS(o=>({...o,h:Math.max(1,Math.round(o.w*im.height/im.width))}));};im.src=URL.createObjectURL(f);};
  useEffect(()=>{const p=e=>{for(const it of e.clipboardData.items)if(it.type.startsWith('image/'))loadFile(it.getAsFile());};
    const k=e=>{if(e.key==='F5'){e.preventDefault();setRun(true);}if(e.key==='Escape'){setRun(false);setHelp(false);}};
    document.addEventListener('paste',p);document.addEventListener('keydown',k);return()=>{document.removeEventListener('paste',p);document.removeEventListener('keydown',k);};},[]);
  useEffect(()=>{if(!src)return;const t=setTimeout(()=>{const w=Math.min(1024,Math.max(1,s.w|0)),hh=Math.min(1024,Math.max(1,s.h|0));const r=convert(src,{...s,w,h:hh});setRes(r);},150);return()=>clearTimeout(t);},[src,s.bpp,s.w,s.h,s.dither,s.brightness,s.contrast,s.gamma,s.threshold,s.serp,s.invert,s.palette]);
  useEffect(()=>{render(res,outRef.current);if(src&&origRef.current){const c=origRef.current;c.width=res?res.w:s.w;c.height=res?res.h:s.h;c.getContext('2d').drawImage(src,0,0,c.width,c.height);}},[res,src]);
  useEffect(()=>{render(verify&&verify.r,verRef.current);},[verify]);
  const bytes=useMemo(()=>res?buildQBI(res):null,[res]);
  const code=useMemo(()=>genCode(res,s.scr,s.name||'IMAGE'),[res,s.scr,s.name]);
  const used=useMemo(()=>res?new Set(res.idx).size:0,[res]);
  useEffect(()=>{if(!run||!res)return;const c=runRef.current;c.width=res.w;c.height=res.h;const x=c.getContext('2d');x.fillStyle='#000';x.fillRect(0,0,res.w,res.h);let y=0,id;
    const step=()=>{for(let k=0;k<Math.max(1,res.h/60)&&y<res.h;k++,y++)for(let xx=0;xx<res.w;xx++){const p=res.pal[res.idx[y*res.w+xx]];x.fillStyle=`rgb(${p})`;x.fillRect(xx,y,1,1);}if(y<res.h)id=requestAnimationFrame(step);};step();return()=>cancelAnimationFrame(id);},[run,res]);
  const setBpp=b=>setS(o=>({...o,bpp:b,scr:b===1?11:b===4?12:13}));
  const onHover=e=>{if(!res)return;const r=e.target.getBoundingClientRect();const x=Math.floor((e.clientX-r.left)/r.width*res.w),y=Math.floor((e.clientY-r.top)/r.height*res.h);if(x>=0&&y>=0&&x<res.w&&y<res.h)setHover({x,y,c:res.idx[y*res.w+x]});};
  const N=(s.name||'IMAGE').toUpperCase().replace(/[^A-Z0-9_]/g,'').slice(0,8)||'IMAGE';
  const dlAll=async()=>{if(!window.JSZip||!res)return;const z=new JSZip();z.file(N+'.QBI',bytes);z.file(N+'.BSV',buildBSV(res));Object.entries(code).forEach(([k,v])=>z.file(k,v.replace(/\n/g,'\r\n')));
    z.file('README.TXT',`QBasic Image Forge output\r\n\r\n${N}.QBI  - ${res.w}x${res.h} ${res.bpp}-bit QBIM image\r\n${N}.BSV  - SCREEN 13 BSAVE dump\r\nRun LOADER.BAS in QBasic 1.1 or QB64.\r\nMade with 640K of love.\r\n`);
    const pn=await new Promise(r=>outRef.current.toBlob(r));z.file(N+'.PNG',pn);dl(N+'.ZIP',await z.generateAsync({type:'blob'}));};
  const doVerify=f=>{if(!f)return;f.arrayBuffer().then(ab=>{try{const r=parseQBI(new Uint8Array(ab));setVerify({r,ok:true,info:`${r.w}x${r.h} ${r.bpp}-bit, ${r.pal.length} colors - round-trip OK!`});}catch(e){setVerify({ok:false,info:e.message});}});};

  const hex=useMemo(()=>{if(!bytes)return null;const n=res.pal.length,hd=12+n*3;const col=i=>i<4?'#FF5555':i<5?'#FFFF55':i<6?'#55FF55':i<10?'#55FFFF':i<12?'#FF55FF':i<hd?'#FFAA00':'#AAAAAA';
    const rows=[];for(let i=0;i<Math.min(256,bytes.length);i+=16){rows.push(h('div',{key:i},h('span',{style:{color:'#5555FF'}},i.toString(16).padStart(4,'0')+': '),
      Array.from(bytes.slice(i,i+16)).map((b,j)=>h('span',{key:j,style:{color:col(i+j)}},b.toString(16).padStart(2,'0').toUpperCase()))));}return rows;},[bytes]);
  const bsvSize=7+64000;
  const scrInfo=SCREENS[s.scr];

  const opt=(label,el)=>h('label',{className:'flex items-center justify-between gap-2 my-1'},h('span',null,label),el);
  const slider=(label,k,min,max,step)=>h('div',{className:'my-1'},h('div',{className:'flex justify-between'},h('span',null,label),h('span',{className:'text-yellow-300'},s[k])),h('input',{type:'range',min,max,step,value:s[k],onInput:e=>set(k,+e.target.value),onChange:()=>{}}));

  return h('div',{className:s.crt?'crt min-h-screen flex flex-col':'min-h-screen flex flex-col'},
    h('div',{className:'menubar'},['File','Edit','View','Convert','Help'].map(m=>h('span',{key:m,className:'cursor-pointer',onClick:()=>{if(m==='Help')setHelp(true);if(m==='Convert')setRun(true);if(m==='File')fileRef.current.click();if(m==='View')set('crt',!s.crt);}},h('b',null,m[0]),m.slice(1))),
      h('span',{className:'ml-auto hidden sm:inline'},'QBasic Image Forge')),
    h('div',{className:'flex-1 p-3 max-w-7xl mx-auto w-full'},
      h('div',{className:'text-center my-2'},h('div',{className:'text-4xl sm:text-5xl text-white tracking-widest'},'QBASIC IMAGE FORGE'),h('div',null,'C:\\> convert image.png /1bit /4bit /8bit /dither ',h('span',{className:'cursor'}))),
      h('div',{className:'grid lg:grid-cols-3 gap-4'},
        h('div',null,
          h(Win,{title:'OPEN IMAGE',d:0},
            h('div',{className:'drop '+(over?'over':''),onClick:()=>fileRef.current.click(),onDragOver:e=>{e.preventDefault();setOver(true);},onDragLeave:()=>setOver(false),onDrop:e=>{e.preventDefault();setOver(false);loadFile(e.dataTransfer.files[0]);}},
              'Drop an image here, or click to browse C:\\',h('br'),h('span',{className:'text-sm'},'(Ctrl+V pastes too)')),
            h('input',{type:'file',accept:'image/*',ref:fileRef,className:'hidden',onChange:e=>loadFile(e.target.files[0])}),
            h('div',{className:'mt-2 flex justify-between flex-wrap'},h(Btn,{onClick:()=>{setSrc(samplePattern());setMsg('Test pattern loaded. Very 1990.');}},'Test Pattern'),h(Btn,{onClick:()=>setHelp(true)},'Help')),
            msg&&h('div',{className:'text-yellow-300 mt-1'},msg)),
          h(Win,{title:'OPTIONS',d:.1},
            h('div',null,'Bit depth:'),h('div',{className:'flex flex-wrap'},[1,4,8].map(b=>h(Btn,{key:b,on:s.bpp===b,onClick:()=>setBpp(b)},b+'-bit'))),
            opt('SCREEN mode',h('select',{value:s.scr,onChange:e=>set('scr',+e.target.value)},Object.entries(SCREENS).map(([k,v])=>h('option',{key:k,value:k},`SCREEN ${k} (${v[0]}x${v[1]}, ${v[2]}bpp)`)))),
            scrInfo&&scrInfo[2]<s.bpp&&h('div',{className:'warn'},'! SCREEN '+s.scr+' cannot show '+(1<<s.bpp)+' colors'),
            opt('Width x Height',h('span',null,h('input',{type:'number',value:s.w,min:1,max:1024,className:'w-16',onChange:e=>set('w',+e.target.value)}),' x ',h('input',{type:'number',value:s.h,min:1,max:1024,className:'w-16',onChange:e=>set('h',+e.target.value)}))),
            opt('Lock aspect',h('input',{type:'checkbox',checked:s.lock,onChange:e=>set('lock',e.target.checked)})),
            h('div',{className:'flex flex-wrap text-base'},[[32,32],[64,64],[160,100],[320,200],[640,480]].map(([w,hh])=>h(Btn,{key:w,onClick:()=>setS(o=>({...o,w,h:hh}))},w+'x'+hh))),
            opt('Dithering',h('select',{value:s.dither,onChange:e=>set('dither',e.target.value)},DITHERS.map(([k,l])=>h('option',{key:k,value:k},l)))),
            opt('Palette',h('select',{value:s.palette,onChange:e=>set('palette',e.target.value)},h('option',{value:'default'},'Standard QB'),h('option',{value:'opt'},'Optimized (median cut)'))),
            slider('Brightness','brightness',-100,100,1),slider('Contrast','contrast',.2,3,.05),slider('Gamma','gamma',.3,3,.05),
            s.bpp===1&&slider('1-bit threshold','threshold',0,255,1),
            opt('Serpentine scan',h('input',{type:'checkbox',checked:s.serp,onChange:e=>set('serp',e.target.checked)})),
            opt('Invert',h('input',{type:'checkbox',checked:s.invert,onChange:e=>set('invert',e.target.checked)})),
            opt('Filename (8.3!)',h('input',{value:s.name,maxLength:8,className:'w-24 bg-black text-yellow-300 px-1 border border-gray-400',onChange:e=>set('name',e.target.value.toUpperCase())})),
            h('div',{className:'flex justify-end mt-2'},h(Btn,{onClick:()=>setS({...DEF})},'Reset')))),
        h('div',{className:'lg:col-span-2 min-w-0'},
          h(Win,{title:'PREVIEW',d:.2},
            h('div',{className:'flex flex-wrap items-center gap-1 mb-2'},'Zoom:',[1,2,4,8].map(z=>h(Btn,{key:z,on:s.zoom===z,onClick:()=>set('zoom',z)},z+'x')),h('span',{className:'ml-auto'},h(Btn,{onClick:()=>setRun(true)},'F5 Run'))),
            h('div',{className:'grid sm:grid-cols-2 gap-3'},
              h('div',{className:'min-w-0'},h('div',null,'ORIGINAL'),h('div',{className:'scroll max-h-96'},h('canvas',{ref:origRef,className:'px',style:{width:(res?res.w:s.w)*s.zoom,maxWidth:'none'}}))),
              h('div',{className:'min-w-0'},h('div',null,'CONVERTED ',hover&&h('span',{className:'text-yellow-300'},`(${hover.x},${hover.y}) = color ${hover.c}`)),
                h('div',{className:'scroll max-h-96'},h('canvas',{ref:outRef,className:'px',style:{width:(res?res.w:s.w)*s.zoom,maxWidth:'none'},onMouseMove:onHover,onMouseLeave:()=>setHover(null)})))),
            res&&h('div',{className:'mt-2 flex flex-wrap gap-x-6'},h('span',null,'File: ',h('b',{className:'text-white'},bytes.length),' bytes'),h('span',null,'Colors used: ',h('b',{className:'text-white'},used),'/',res.pal.length),
              bytes.length>65535&&h('span',{className:'warn'},'! >64KB - too big for one DIM array. QBasic weeps.')),
            res&&h('div',{className:'flex flex-wrap mt-1'},res.pal.slice(0,256).map((p,i)=>h('div',{key:i,title:i+': '+p.map(v=>v>>2).join(','),style:{width:res.pal.length>16?8:18,height:res.pal.length>16?8:18,background:`rgb(${p})`}})))),
          h('div',{className:'grid md:grid-cols-2 gap-4'},
            h(Win,{title:'IMG HEADER',d:.3},
              h('div',{className:'flex mb-1'},h(Btn,{on:fmt==='qbi',onClick:()=>setFmt('qbi')},'QBIM'),h(Btn,{on:fmt==='bsv',onClick:()=>setFmt('bsv')},'BSAVE')),
              fmt==='qbi'?h('table',{className:'mono w-full'},h('tbody',null,[['#FF5555','0','4','Magic "QBIM"'],['#FFFF55','4','1','Version = 1'],['#55FF55','5','1','Bits/pixel = '+s.bpp],['#55FFFF','6','4','Width, Height (LE16)'],['#FF55FF','10','2','Palette count'],['#FFAA00','12','n*3','Palette RGB (0-63)'],['#AAAAAA','...','...',`Pixels: ${s.bpp===1?8:s.bpp===4?2:1} px/byte, rows padded`]].map((r,i)=>h('tr',{key:i},h('td',{style:{color:r[0]}},'■'),h('td',null,r[1]),h('td',null,r[2]),h('td',null,r[3])))))
              :h('table',{className:'mono w-full'},h('tbody',null,[['0','1','&HFD magic'],['1','2','Segment &HA000'],['3','2','Offset 0'],['5','2','Length 64000'],['7','64000','Raw 320x200 GET-ready VRAM']].map((r,i)=>h('tr',{key:i},r.map((c,j)=>h('td',{key:j},c)))))),
              fmt==='qbi'&&h('div',{className:'mono hex mt-2 scroll',style:{fontSize:11}},hex)),
            h(Win,{title:'EXPORT',d:.35},
              h('div',{className:'flex flex-col items-start'},
                h(Btn,{onClick:()=>bytes&&dl(N+'.QBI',bytes)},`Download ${N}.QBI`),
                h(Btn,{onClick:()=>res&&dl(N+'.BSV',buildBSV(res))},`Download ${N}.BSV (${bsvSize} B)`),
                h(Btn,{onClick:()=>outRef.current.toBlob(b=>dl(N+'.PNG',b))},'Download PNG preview'),
                h(Btn,{onClick:dlAll},'Download ALL (.ZIP)')),
              h('div',{className:'mt-3 border-t border-gray-500 pt-2'},'VERIFY LOADER: re-open a .QBI',
                h('div',null,h(Btn,{onClick:()=>verFileRef.current.click()},'Open .QBI')),
                h('input',{type:'file',accept:'.qbi,.QBI',ref:verFileRef,className:'hidden',onChange:e=>doVerify(e.target.files[0])}),
                verify&&h('div',{className:verify.ok?'text-green-300':'warn'},verify.info),
                verify&&verify.ok&&h('canvas',{ref:verRef,className:'px',style:{width:Math.min(300,verify.r.w*2)}})))),
          h(Win,{title:'QBASIC CODE',d:.4},
            h('div',{className:'flex flex-wrap items-center'},Object.keys(code).map(k=>h(Btn,{key:k,on:tab===k,onClick:()=>setTab(k)},k)),
              h('span',{className:'ml-auto'},h(Btn,{onClick:()=>{navigator.clipboard.writeText(code[tab]||'');setMsg('Copied '+tab+' to clipboard');}},'Copy'),h(Btn,{onClick:()=>dl(tab,(code[tab]||'').replace(/\n/g,'\r\n'),'text/plain')},'Save'))),
            h('div',{className:'code mono mt-1',dangerouslySetInnerHTML:{__html:hl(code[tab]||"' Load an image first, friend.")}}))))),
    h('footer',{className:'text-center py-3'},'Made with 640K of love · ',h('a',{href:'/remix'},'Remix on Berrry')),
    h('div',{className:'statusbar'},h('span',null,'F5=Run'),h('span',null,'Dithering: '+DITHERS.find(d=>d[0]===s.dither)[1]),h('span',null,`Pixels: ${res?res.w:s.w}x${res?res.h:s.h}`),h('span',null,s.bpp+'-bit'),h('span',{className:'ml-auto'},'CRT:',h('input',{type:'checkbox',checked:s.crt,onChange:e=>set('crt',e.target.checked)}))),
    run&&h('div',{className:'modal',onClick:()=>setRun(false)},h('canvas',{ref:runRef,className:'px',style:{width:'min(90vw,640px)'}}),h('div',{className:'mt-4'},'Press any key to continue',h('span',{className:'cursor'}))),
    help&&h('div',{className:'modal',style:{background:'rgba(0,0,0,.85)'},onClick:()=>setHelp(false)},
      h('div',{style:{background:'var(--blue)',maxWidth:560},className:'win m-4'},h('div',{className:'ttl'},'HELP: DITHERING'),
        h('p',null,'Your image has millions of colors. SCREEN 13 has 256. SCREEN 11 has TWO. Dithering fakes the missing ones with patterns of pixels.'),
        h('p',null,'■ Error diffusion (Floyd-Steinberg, Atkinson, JJN, Sierra): pushes each pixel\'s rounding error onto its neighbors. Organic, grainy. Atkinson = classic Mac look.'),
        h('p',null,'■ Bayer: ordered threshold grid. Crosshatch patterns, compresses well, very "demo scene".'),
        h('p',null,'■ Noise: random jitter. Like TV static but with ambition.'),
        h('p',null,'Put LOADER.BAS and the .QBI file in the same folder, then run in QBasic 1.1 or QB64. Press F5 here for a preview of the thrill.'),
        h('div',{className:'text-center'},h(Btn,null,'OK')))));
}

ReactDOM.createRoot(document.getElementById('root')).render(h(App));