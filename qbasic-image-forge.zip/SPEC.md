# QBasic Image Forge 🖼️➡️💾

A retro converter that turns any image into QBasic-ready graphics data. It supports 1-bit, 4-bit and 8-bit color depths, several dithering algorithms, a custom binary header format, and generates matching QBasic SAVE/LOAD source code. **App type: React Web App**, with HTML5 Canvas used for image processing and previews.

## Theme & Styling
- Styled like the MS-DOS QBasic IDE: deep blue background (#0000AA), light gray text (#AAAAAA), bright white highlights, and cyan menu bars.
- Monospace font throughout ("Px437 IBM VGA" style via a web font like "VT323" or "IBM Plex Mono").
- Windows have double-line box-drawing borders (╔═╗) made with CSS borders. Buttons look like `< OK >` and invert colors on hover.
- A top menu bar reads "File  Edit  View  Convert  Help", and a bottom status bar shows hints like "F5=Run  Dithering: Floyd-Steinberg  Pixels: 320x200".
- Blinking block cursor accents, plus an optional CRT scanline overlay that can be switched off.

## Layout

### 1. Input Panel ("OPEN IMAGE")
- Drag-and-drop zone, reading "Drop an image here, or press ENTER to browse C:\".
- A file picker and a paste-from-clipboard option.
- "Random Sample" button that loads a random image (via the random images API) for quick testing.

### 2. Settings Panel ("OPTIONS")
- **Bit depth selector:** 1-bit (2 colors, SCREEN 11-style), 4-bit (16-color EGA/VGA palette, SCREEN 12/13), or 8-bit (256-color VGA default palette, SCREEN 13).
- **Target SCREEN mode dropdown:** SCREEN 7, 9, 11, 12 or 13, which also suggests a resolution.
- **Resize:** width/height inputs, a lock-aspect toggle, and presets (32x32 sprite, 64x64, 160x100, 320x200, 640x480).
- **Dithering:** None, Floyd–Steinberg, Atkinson, Bayer 2x2/4x4/8x8, Jarvis-Judice-Ninke, Sierra Lite, and Random Noise.
- **Adjustments:** brightness, contrast, gamma and 1-bit threshold sliders, plus serpentine scanning and invert toggles.
- **Palette:** standard QBasic default palette, or an optimized custom palette (median cut) that also produces `PALETTE` statements in the code.

### 3. Preview Panel
- Original and converted images shown side by side, rendered with `image-rendering: pixelated`.
- Zoom options: 1x, 2x, 4x and 8x.
- Hovering shows the pixel coordinates and color index.
- Live stats: output file size in bytes, number of colors used, and a warning if the result exceeds the 64KB `DIM` array limit.

### 4. Header Format Panel ("IMG HEADER")
- Shows the binary header structure in a table:
  - Magic "QBIM" (4 bytes)
  - Version (1 byte)
  - Bits per pixel (1 byte)
  - Width and height (2 bytes each, little-endian)
  - Palette count (2 bytes)
  - Palette entries (RGB triplets using 6-bit VGA values, 0–63)
  - Pixel data (packed rows: 8 pixels per byte at 1-bit, 2 at 4-bit, 1 at 8-bit)
- A hex dump viewer of the first 256 bytes, with header fields color-coded.
- Alternative format toggle: raw QBasic `BSAVE` format (7-byte BSAVE header, `GET` array layout).

### 5. Code Output Panel ("QBASIC CODE")
- Tabs:
  - **LOADER.BAS:** reads the .QBI file with `OPEN ... FOR BINARY`, parses the header, sets the palette via `OUT &H3C8/&H3C9`, and draws with `PSET`.
  - **SAVER.BAS:** captures the screen using `POINT` and writes the same format back out.
  - **DATA.BAS:** embeds the image as `DATA` statements, for single-file programs.
  - **BLOAD.BAS:** the `DEF SEG = &HA000` fast-path version for SCREEN 13.
- Code is syntax-highlighted in QBasic IDE colors, and each tab has a copy button.
- Code comments include cheeky remarks like `' Congratulations, you're programming like it's 1991`.

### 6. Export Buttons
- Download the .QBI binary, the .BAS files, and a PNG preview.
- "Download All" produces a ZIP (JSZip) containing the files plus a README.TXT.

## Functionality
- All processing runs client-side on canvas, and the preview updates live when settings change (debounced).
- A **loader verification** feature lets you re-upload a .QBI file and decode it in the browser to confirm the round-trip works.
- Recent settings are saved to localStorage.
- An optional "Share preset" feature uses the backend to save public dithering/palette presets.
- Easter egg: pressing F5 runs a fake "QBasic runtime" animation that draws the image line by line with `PSET` speed, then shows "Press any key to continue".
- A Help dialog explains dithering with small illustrations.
- Responsive layout: panels stack vertically on mobile, and the menu bar collapses to "≡ File".

## Footer
- Reads "Made with 640K of love" and includes a <a href="/remix">Remix on Berrry</a> link.