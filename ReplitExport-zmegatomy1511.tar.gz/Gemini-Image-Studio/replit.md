# Gemini Image Studio

Gemini Image Studio lets creators upload a reference image, describe a visual edit, choose an image-capable Gemini model, and download the generated variation.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server
- `pnpm --filter @workspace/gemini-image-studio run dev` — run the web app
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- Required secret for generation: `GEMINI_API_KEY`

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/gemini-image-studio/src/App.tsx` — image studio UI and session state
- `artifacts/gemini-image-studio/src/index.css` — studio theme and canvas styling
- `artifacts/api-server/src/routes/gemini.ts` — server-side Gemini image editing route
- `lib/api-spec/openapi.yaml` — source of truth for the image generation contract
- `lib/api-client-react/src/generated/` and `lib/api-zod/src/generated/` — generated API helpers and validation

## Architecture decisions

- Image bytes are sent to the server as base64 only for the active generation request; generated results remain in the browser session.
- Gemini requests stay server-side so the API key is never exposed to the browser.
- The app limits model choices to the image-capable Gemini models supported by the API contract.

## Product

- Upload PNG, JPG, WEBP, HEIC, or HEIF references up to 10MB.
- Write an edit direction, choose Gemini 2.5 Flash Image or Gemini 3 Pro Image, and generate an image variation.
- Compare source and result, download the result, and revisit recent edits during the current browser session.

## User preferences

- The user asked for Google Gemini image-to-image generation.

## Gotchas

- Google does not guarantee unlimited free Gemini API usage; quota and billing rules depend on the account and model.
- If the Replit-managed Gemini integration is unavailable, add `GEMINI_API_KEY` through Secrets; do not put the key in client code.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
