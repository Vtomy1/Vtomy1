---
name: Gemini API access
description: How this project handles Gemini image generation when managed AI access is unavailable.
---

The app keeps Gemini image generation behind the API server and supports a project secret named `GEMINI_API_KEY` as the fallback when managed Gemini access cannot be provisioned.

**Why:** Managed Gemini access may require an account upgrade, and Google does not guarantee unlimited free usage. Keeping the fallback server-side preserves the UI without exposing credentials.

**How to apply:** Do not request or print the key in chat. Use the secure secrets flow, and keep image-capable model IDs aligned with the API contract.