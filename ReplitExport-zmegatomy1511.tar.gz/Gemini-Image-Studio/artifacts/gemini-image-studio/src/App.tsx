import { useRef, useState, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import {
  getHealthCheckQueryKey,
  type GeminiImageInput,
  type GeminiImageOutput,
  useGenerateGeminiImage,
  useHealthCheck,
} from '@workspace/api-client-react';
import {
  ArrowDownToLine,
  Check,
  ChevronDown,
  CircleAlert,
  CircleCheck,
  Clock3,
  Copy,
  ImagePlus,
  Layers3,
  LoaderCircle,
  Maximize2,
  Minus,
  RefreshCw,
  ScanLine,
  Sparkles,
  Upload,
  WandSparkles,
  X,
} from 'lucide-react';
import { useLocation, Route, Router as WouterRouter, Switch } from 'wouter';
import NotFound from '@/pages/not-found';

const queryClient = new QueryClient();

type RecentEdit = GeminiImageOutput & {
  id: string;
  sourceUrl: string;
  prompt: string;
  createdAt: number;
};

const MODELS: Array<{
  value: GeminiImageInput['model'];
  name: string;
  description: string;
  tag: string;
}> = [
  {
    value: 'gemini-2.5-flash-image',
    name: 'Gemini 2.5 Flash',
    description: 'Fast, expressive iterations',
    tag: 'FAST',
  },
  {
    value: 'gemini-3-pro-image',
    name: 'Gemini 3 Pro',
    description: 'Sharper detail and control',
    tag: 'PRO',
  },
];

function imageSource(base64: string, mimeType: string) {
  return base64.startsWith('data:') ? base64 : `data:${mimeType};base64,${base64}`;
}

function getErrorText(error: unknown) {
  if (!error) return '';
  if (typeof error === 'string') return error;
  if (error instanceof Error) return error.message;
  if (typeof error === 'object' && error !== null) {
    const payload = error as { message?: string; error?: string; detail?: string };
    return payload.message || payload.error || payload.detail || 'The image could not be generated.';
  }
  return 'The image could not be generated.';
}

function StudioLogo() {
  return (
    <div className="flex items-center gap-3" data-testid="brand-gemini-image-studio">
      <div className="relative flex h-9 w-9 items-center justify-center rounded-[11px] bg-primary text-primary-foreground shadow-[0_8px_22px_hsl(var(--primary)/.22)]">
        <Sparkles className="h-[18px] w-[18px]" strokeWidth={2.4} />
        <span className="absolute -right-1 -top-1 h-2 w-2 rounded-full bg-accent" />
      </div>
      <div>
        <p className="font-semibold leading-none tracking-[-.02em] text-foreground">Gemini</p>
        <p className="mt-1 font-mono text-[10px] uppercase tracking-[.18em] text-muted-foreground">Image Studio</p>
      </div>
    </div>
  );
}

function UploadEmptyState({ onSelect }: { onSelect: () => void }) {
  return (
    <div className="flex min-h-[420px] flex-1 flex-col items-center justify-center px-6 text-center sm:min-h-[530px]" data-testid="empty-upload-state">
      <div className="mb-6 flex h-20 w-20 items-center justify-center rounded-[25px] border border-primary/30 bg-primary/10 text-primary">
        <ImagePlus className="h-8 w-8" strokeWidth={1.5} />
      </div>
      <h2 className="font-serif text-3xl italic tracking-[-.025em] text-foreground">Bring a visual to life.</h2>
      <p className="mt-3 max-w-[280px] text-sm leading-6 text-muted-foreground">
        Start with a reference image, then describe the direction you want to explore.
      </p>
      <button
        type="button"
        onClick={onSelect}
        className="mt-7 inline-flex items-center gap-2 rounded-full bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground transition-transform duration-200 hover:-translate-y-0.5 hover:brightness-105 active:translate-y-0"
        data-testid="button-upload-reference-empty"
      >
        <Upload className="h-4 w-4" />
        Add reference image
      </button>
      <p className="mt-4 font-mono text-[10px] uppercase tracking-[.14em] text-muted-foreground/75">PNG / JPG / WEBP · 10MB MAX</p>
    </div>
  );
}

function LoadingCanvas() {
  return (
    <div className="flex min-h-[420px] flex-1 items-center justify-center p-5 sm:min-h-[530px]" data-testid="loading-canvas">
      <div className="relative aspect-[4/3] w-full max-w-[620px] overflow-hidden rounded-2xl border border-border/60 skeleton">
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-background/10">
          <div className="flex h-12 w-12 items-center justify-center rounded-full border border-primary/30 bg-background/45 text-primary backdrop-blur">
            <LoaderCircle className="h-5 w-5 animate-spin" />
          </div>
          <p className="mt-4 font-mono text-[10px] uppercase tracking-[.18em] text-foreground/70">Rendering your direction</p>
        </div>
      </div>
    </div>
  );
}

function ImageCanvas({
  sourceUrl,
  result,
  compare,
  onToggleCompare,
}: {
  sourceUrl: string;
  result: GeminiImageOutput | null;
  compare: boolean;
  onToggleCompare: () => void;
}) {
  const resultUrl = result ? imageSource(result.imageBase64, result.mimeType) : null;
  return (
    <div className="flex min-h-[420px] flex-1 flex-col p-3 sm:min-h-[530px] sm:p-5" data-testid="image-canvas">
      <div className={`relative flex flex-1 gap-2 overflow-hidden rounded-2xl ${compare && resultUrl ? 'bg-secondary p-2' : ''}`}>
        {compare && resultUrl ? (
          <>
            <div className="relative min-w-0 flex-1 overflow-hidden rounded-xl border border-border/60 bg-background">
              <img src={sourceUrl} alt="Reference image" className="h-full w-full object-contain" data-testid="img-reference-compare" />
              <span className="absolute left-3 top-3 rounded-full border border-border/70 bg-background/80 px-2.5 py-1 font-mono text-[9px] uppercase tracking-[.14em] text-muted-foreground backdrop-blur">Source</span>
            </div>
            <div className="relative min-w-0 flex-1 overflow-hidden rounded-xl border border-primary/35 bg-background">
              <img src={resultUrl} alt="Generated result" className="h-full w-full object-contain" data-testid="img-generated-compare" />
              <span className="absolute left-3 top-3 rounded-full bg-primary px-2.5 py-1 font-mono text-[9px] uppercase tracking-[.14em] text-primary-foreground">Result</span>
            </div>
          </>
        ) : (
          <div className="relative flex w-full items-center justify-center overflow-hidden rounded-xl border border-border/60 bg-[#18192c]">
            <img src={resultUrl || sourceUrl} alt={resultUrl ? 'Generated result' : 'Reference image'} className="h-full w-full object-contain" data-testid={resultUrl ? 'img-generated-result' : 'img-reference-source'} />
            <span className={`absolute left-4 top-4 rounded-full border px-2.5 py-1 font-mono text-[9px] uppercase tracking-[.14em] backdrop-blur ${resultUrl ? 'border-primary/30 bg-primary text-primary-foreground' : 'border-border/70 bg-background/75 text-muted-foreground'}`}>
              {resultUrl ? 'Generated result' : 'Reference'}
            </span>
            <button type="button" onClick={onToggleCompare} className="absolute right-4 top-4 flex h-9 w-9 items-center justify-center rounded-full border border-border/70 bg-background/75 text-foreground backdrop-blur transition-colors hover:bg-secondary" data-testid="button-expand-canvas" aria-label="Focus canvas">
              <Maximize2 className="h-4 w-4" />
            </button>
          </div>
        )}
        {resultUrl && (
          <button
            type="button"
            onClick={onToggleCompare}
            className="absolute bottom-4 left-1/2 flex -translate-x-1/2 items-center gap-2 rounded-full border border-border/70 bg-background/90 px-3.5 py-2 text-xs font-medium text-foreground shadow-lg backdrop-blur transition-colors hover:bg-secondary"
            data-testid="button-toggle-compare"
          >
            {compare ? <Minus className="h-3.5 w-3.5 text-primary" /> : <Layers3 className="h-3.5 w-3.5 text-primary" />}
            {compare ? 'Single view' : 'Compare source'}
          </button>
        )}
      </div>
    </div>
  );
}

function ControlPanel({
  sourceUrl,
  sourceBase64,
  mimeType,
  prompt,
  setPrompt,
  model,
  setModel,
  onSelectFile,
  onGenerate,
  onClear,
  isGenerating,
  error,
  result,
}: {
  sourceUrl: string;
  sourceBase64: string;
  mimeType: GeminiImageInput['mimeType'] | '';
  prompt: string;
  setPrompt: (value: string) => void;
  model: GeminiImageInput['model'];
  setModel: (value: GeminiImageInput['model']) => void;
  onSelectFile: () => void;
  onGenerate: () => void;
  onClear: () => void;
  isGenerating: boolean;
  error: string;
  result: GeminiImageOutput | null;
}) {
  const [modelOpen, setModelOpen] = useState(false);
  const selectedModel = MODELS.find((item) => item.value === model) || MODELS[0];
  const canGenerate = Boolean(sourceBase64 && prompt.trim() && !isGenerating);
  return (
    <aside className="w-full shrink-0 border-t border-border/70 bg-card/55 p-5 lg:w-[360px] lg:border-l lg:border-t-0 lg:p-6" data-testid="control-panel">
      <div className="flex items-center justify-between">
        <div>
          <p className="font-mono text-[10px] uppercase tracking-[.18em] text-primary">01 / Direction</p>
          <h2 className="mt-2 text-lg font-semibold tracking-[-.02em] text-foreground">Make an edit</h2>
        </div>
        {sourceUrl && (
          <button type="button" onClick={onClear} className="flex h-8 w-8 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground" data-testid="button-clear-reference" aria-label="Remove reference image">
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      <div className="mt-6">
        <label className="mb-2.5 block text-xs font-medium text-muted-foreground" htmlFor="edit-direction">Edit direction</label>
        <textarea
          id="edit-direction"
          value={prompt}
          onChange={(event) => setPrompt(event.target.value)}
          placeholder="Turn this into a moody editorial cover…"
          maxLength={4000}
          rows={5}
          className="w-full resize-none rounded-xl border border-input bg-background/70 px-3.5 py-3 text-sm leading-6 text-foreground outline-none transition-colors placeholder:text-muted-foreground/55 focus:border-primary focus:ring-2 focus:ring-primary/15"
          data-testid="input-edit-direction"
        />
        <div className="mt-1.5 flex justify-end font-mono text-[10px] text-muted-foreground/70" data-testid="text-prompt-count">{prompt.length} / 4000</div>
      </div>

      <div className="mt-5">
        <label className="mb-2.5 block text-xs font-medium text-muted-foreground">Image model</label>
        <div className="relative">
          <button type="button" onClick={() => setModelOpen((open) => !open)} className="flex w-full items-center justify-between rounded-xl border border-input bg-background/70 px-3.5 py-3 text-left transition-colors hover:border-primary/60" data-testid="button-model-select" aria-expanded={modelOpen}>
            <span className="flex min-w-0 items-center gap-2.5">
              <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-accent/15 text-accent"><WandSparkles className="h-3.5 w-3.5" /></span>
              <span className="min-w-0"><span className="block truncate text-sm font-medium text-foreground">{selectedModel.name}</span><span className="block truncate text-[11px] text-muted-foreground">{selectedModel.description}</span></span>
            </span>
            <ChevronDown className={`h-4 w-4 shrink-0 text-muted-foreground transition-transform ${modelOpen ? 'rotate-180' : ''}`} />
          </button>
          {modelOpen && (
            <div className="absolute inset-x-0 top-[calc(100%+6px)] z-10 overflow-hidden rounded-xl border border-border bg-popover p-1.5 shadow-xl" data-testid="model-options">
              {MODELS.map((item) => (
                <button key={item.value} type="button" onClick={() => { setModel(item.value); setModelOpen(false); }} className="flex w-full items-center justify-between rounded-lg px-2.5 py-2.5 text-left transition-colors hover:bg-secondary" data-testid={`button-model-${item.value}`}>
                  <span><span className="block text-sm font-medium text-foreground">{item.name}</span><span className="mt-0.5 block text-[11px] text-muted-foreground">{item.description}</span></span>
                  {item.value === model ? <Check className="h-4 w-4 text-primary" /> : <span className="font-mono text-[9px] text-muted-foreground">{item.tag}</span>}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {error && (
        <div className="mt-5 rounded-xl border border-destructive/30 bg-destructive/10 p-3.5" data-testid="status-generation-error">
          <div className="flex items-start gap-2.5"><CircleAlert className="mt-0.5 h-4 w-4 shrink-0 text-destructive" /><div><p className="text-xs font-semibold text-foreground">Generation paused</p><p className="mt-1 text-xs leading-5 text-muted-foreground">{error.includes('key') || error.includes('401') ? 'The Gemini key is missing or not accepted. Check the server configuration and try again.' : error}</p></div></div>
        </div>
      )}

      <button type="button" onClick={onGenerate} disabled={!canGenerate} className="mt-7 flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-4 py-3.5 text-sm font-semibold text-primary-foreground shadow-[0_10px_24px_hsl(var(--primary)/.16)] transition-all duration-200 hover:-translate-y-0.5 hover:brightness-105 disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:translate-y-0" data-testid="button-generate">
        {isGenerating ? <><LoaderCircle className="h-4 w-4 animate-spin" /> Generating image</> : <><Sparkles className="h-4 w-4" /> Generate edit</>}
      </button>
      {!sourceBase64 && <button type="button" onClick={onSelectFile} className="mt-3 w-full text-center text-[11px] text-muted-foreground transition-colors hover:text-primary" data-testid="button-upload-reference-panel">Add a reference image to unlock generation.</button>}
      {result && !isGenerating && <p className="mt-3 flex items-center justify-center gap-1.5 text-[11px] text-accent" data-testid="status-generation-success"><CircleCheck className="h-3.5 w-3.5" /> New variation ready</p>}
    </aside>
  );
}

function RecentStrip({ edits, onSelect }: { edits: RecentEdit[]; onSelect: (edit: RecentEdit) => void }) {
  return (
    <section className="border-t border-border/70 px-5 py-5 sm:px-8" data-testid="recent-edits">
      <div className="mb-4 flex items-center justify-between">
        <div><p className="font-mono text-[10px] uppercase tracking-[.18em] text-muted-foreground">Session memory</p><h2 className="mt-1.5 text-base font-semibold tracking-[-.02em]">Recent edits</h2></div>
        {edits.length > 0 && <span className="font-mono text-[10px] text-muted-foreground" data-testid="text-recent-count">{String(edits.length).padStart(2, '0')} / THIS SESSION</span>}
      </div>
      {edits.length === 0 ? (
        <div className="flex items-center gap-3 rounded-xl border border-dashed border-border/80 bg-card/30 px-4 py-4" data-testid="empty-recent-edits">
          <Clock3 className="h-4 w-4 text-muted-foreground" /><p className="text-xs text-muted-foreground">Your generated variations will stay here while you experiment.</p>
        </div>
      ) : (
        <div className="flex gap-3 overflow-x-auto pb-1">
          {edits.map((edit, index) => (
            <button type="button" key={edit.id} onClick={() => onSelect(edit)} className="group relative h-[74px] w-[104px] shrink-0 overflow-hidden rounded-lg border border-border/70 bg-secondary transition-all duration-200 hover:-translate-y-0.5 hover:border-primary/60" data-testid={`button-recent-edit-${edit.id}`}>
              <img src={imageSource(edit.imageBase64, edit.mimeType)} alt={`Recent edit ${index + 1}`} className="h-full w-full object-cover opacity-80 transition-opacity group-hover:opacity-100" />
              <span className="absolute bottom-1.5 left-1.5 rounded bg-background/80 px-1.5 py-0.5 font-mono text-[8px] uppercase text-foreground backdrop-blur">{edit.model.includes('3') ? 'PRO' : 'FLASH'}</span>
            </button>
          ))}
        </div>
      )}
    </section>
  );
}

function Home() {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [sourceUrl, setSourceUrl] = useState('');
  const [sourceBase64, setSourceBase64] = useState('');
  const [mimeType, setMimeType] = useState<GeminiImageInput['mimeType'] | ''>('');
  const [prompt, setPrompt] = useState('');
  const [model, setModel] = useState<GeminiImageInput['model']>('gemini-2.5-flash-image');
  const [result, setResult] = useState<GeminiImageOutput | null>(null);
  const [compare, setCompare] = useState(false);
  const [recentEdits, setRecentEdits] = useState<RecentEdit[]>([]);
  const [uploadError, setUploadError] = useState('');
  const health = useHealthCheck({ query: { queryKey: getHealthCheckQueryKey(), staleTime: 30_000, retry: 1 } });
  const generation = useGenerateGeminiImage();

  const handleFile = (file?: File) => {
    if (!file) return;
    const validTypes = ['image/png', 'image/jpeg', 'image/webp', 'image/heic', 'image/heif'];
    if (!validTypes.includes(file.type)) {
      setUploadError('Please choose a PNG, JPG, WEBP, HEIC, or HEIF image.');
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      setUploadError('That image is over 10MB. Choose a smaller reference.');
      return;
    }
    setUploadError('');
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = String(reader.result || '');
      setSourceUrl(dataUrl);
      setSourceBase64(dataUrl.includes(',') ? dataUrl.split(',')[1] : dataUrl);
      setMimeType(file.type as GeminiImageInput['mimeType']);
      setResult(null);
      setCompare(false);
    };
    reader.readAsDataURL(file);
  };

  const generate = () => {
    if (!sourceBase64 || !prompt.trim() || !mimeType) return;
    setUploadError('');
    generation.mutate({ data: { model, prompt: prompt.trim(), imageBase64: sourceBase64, mimeType } }, {
      onSuccess: (output) => {
        setResult(output);
        setCompare(false);
        setRecentEdits((current) => [{ ...output, id: `${Date.now()}`, sourceUrl, prompt: prompt.trim(), createdAt: Date.now() }, ...current].slice(0, 8));
      },
    });
  };

  const clearReference = () => {
    setSourceUrl('');
    setSourceBase64('');
    setMimeType('');
    setResult(null);
    setPrompt('');
    setUploadError('');
    setCompare(false);
  };

  const download = () => {
    if (!result) return;
    const anchor = document.createElement('a');
    anchor.href = imageSource(result.imageBase64, result.mimeType);
    anchor.download = `gemini-edit-${new Date().toISOString().slice(0, 10)}.${result.mimeType.split('/')[1] || 'png'}`;
    anchor.click();
  };

  const selectRecent = (edit: RecentEdit) => {
    setSourceUrl(edit.sourceUrl);
    setSourceBase64(edit.sourceUrl.includes(',') ? edit.sourceUrl.split(',')[1] : edit.sourceUrl);
    setMimeType((edit.sourceUrl.match(/^data:(image\/[^;]+);/)?.[1] || edit.mimeType) as GeminiImageInput['mimeType']);
    setResult(edit);
    setPrompt(edit.prompt);
    setModel(edit.model as GeminiImageInput['model']);
    setCompare(true);
  };

  const errorText = uploadError || getErrorText(generation.error);
  const hasImage = Boolean(sourceUrl);
  const isOnline = health.data?.status === 'ok' || health.data?.status === 'healthy';

  return (
    <div className="grain min-h-[100dvh] bg-background text-foreground">
      <header className="flex h-[72px] items-center justify-between border-b border-border/70 bg-background/85 px-5 backdrop-blur-xl sm:px-8" data-testid="studio-header">
        <StudioLogo />
        <div className="flex items-center gap-3">
          <div className="hidden items-center gap-2 rounded-full border border-border/70 bg-card/60 px-3 py-1.5 sm:flex" data-testid="status-server">
            <span className={`h-1.5 w-1.5 rounded-full ${health.isLoading ? 'animate-pulse bg-muted-foreground' : isOnline ? 'bg-accent' : 'bg-destructive'}`} />
            <span className="font-mono text-[10px] uppercase tracking-[.13em] text-muted-foreground">{health.isLoading ? 'Checking' : isOnline ? 'Ready' : 'Offline'}</span>
          </div>
          <div className="flex h-8 w-8 items-center justify-center rounded-full border border-border/80 bg-card text-muted-foreground" data-testid="avatar-studio"><ScanLine className="h-3.5 w-3.5" /></div>
        </div>
      </header>

      <main className="mx-auto max-w-[1440px] px-4 py-7 sm:px-8 sm:py-10">
        <div className="mb-7 flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
          <div><p className="font-mono text-[10px] uppercase tracking-[.2em] text-primary">Visual sandbox / 001</p><h1 className="mt-2 font-serif text-[clamp(2.5rem,6vw,4.7rem)] leading-[.92] tracking-[-.045em] text-foreground">Make the <em>next</em> version.</h1></div>
          <p className="max-w-[245px] text-sm leading-6 text-muted-foreground sm:mb-1">A quick, focused space for testing visual directions with Gemini.</p>
        </div>

        <section className="overflow-hidden rounded-2xl border border-border/80 bg-card/45 shadow-[0_24px_70px_hsl(234_31%_5%/.22)]" data-testid="studio-workspace">
          <div className="flex items-center justify-between border-b border-border/70 px-5 py-3.5 sm:px-6">
            <div className="flex items-center gap-2.5"><span className="h-2 w-2 rounded-full bg-primary shadow-[0_0_0_4px_hsl(var(--primary)/.12)]" /><span className="font-mono text-[10px] uppercase tracking-[.16em] text-muted-foreground">Untitled experiment</span></div>
            <div className="flex items-center gap-2"><span className="hidden text-[11px] text-muted-foreground sm:inline">Auto-saved to session</span><button type="button" onClick={() => setPrompt('')} className="flex h-7 w-7 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground" data-testid="button-reset-prompt" aria-label="Reset prompt"><RefreshCw className="h-3.5 w-3.5" /></button></div>
          </div>
          <div className="studio-grid flex flex-col lg:flex-row">
            <div className="flex min-w-0 flex-1 flex-col">
              {!hasImage ? <UploadEmptyState onSelect={() => fileInputRef.current?.click()} /> : generation.isPending ? <LoadingCanvas /> : <ImageCanvas sourceUrl={sourceUrl} result={result} compare={compare} onToggleCompare={() => setCompare((value) => !value)} />}
              {hasImage && (
                <div className="flex items-center justify-between border-t border-border/60 px-5 py-3 sm:px-6">
                  <button type="button" onClick={() => fileInputRef.current?.click()} className="flex items-center gap-2 text-xs font-medium text-muted-foreground transition-colors hover:text-foreground" data-testid="button-replace-reference"><Upload className="h-3.5 w-3.5" /> Replace reference</button>
                  <div className="flex items-center gap-2">
                    {result && <button type="button" onClick={download} className="flex items-center gap-2 rounded-lg border border-border/80 bg-secondary/50 px-3 py-2 text-xs font-medium transition-colors hover:border-primary/60 hover:bg-secondary" data-testid="button-download-result"><ArrowDownToLine className="h-3.5 w-3.5 text-primary" /> Download</button>}
                    <span className="hidden font-mono text-[9px] uppercase tracking-[.12em] text-muted-foreground/70 sm:inline">{mimeType?.split('/')[1] || 'IMAGE'} / REFERENCE</span>
                  </div>
                </div>
              )}
            </div>
            <ControlPanel sourceUrl={sourceUrl} sourceBase64={sourceBase64} mimeType={mimeType} prompt={prompt} setPrompt={setPrompt} model={model} setModel={setModel} onSelectFile={() => fileInputRef.current?.click()} onGenerate={generate} onClear={clearReference} isGenerating={generation.isPending} error={errorText} result={result} />
          </div>
        </section>

        <RecentStrip edits={recentEdits} onSelect={selectRecent} />
        <p className="mt-2 flex items-center justify-center gap-2 text-center font-mono text-[9px] uppercase tracking-[.14em] text-muted-foreground/50"><Copy className="h-3 w-3" /> Prompts and images stay in this browser session</p>
      </main>

      <input ref={fileInputRef} type="file" accept="image/png,image/jpeg,image/webp,image/heic,image/heif" onChange={(event) => handleFile(event.target.files?.[0])} className="hidden" data-testid="input-reference-upload" />
    </div>
  );
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;