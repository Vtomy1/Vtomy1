import { Router, type IRouter } from "express";
import { GenerateGeminiImageBody, GenerateGeminiImageResponse } from "@workspace/api-zod";

const router: IRouter = Router();

type GeminiPart = {
  inlineData?: {
    data?: string;
    mimeType?: string;
  };
};

type GeminiResponse = {
  candidates?: Array<{
    content?: {
      parts?: GeminiPart[];
    };
  }>;
  error?: {
    message?: string;
    status?: string;
  };
};

function upstreamStatus(status: number) {
  if (status === 401 || status === 403) return 401;
  if (status === 429) return 429;
  return 502;
}

router.post("/gemini/generate-image", async (req, res) => {
  const parsed = GenerateGeminiImageBody.safeParse(req.body);

  if (!parsed.success) {
    res.status(400).json({ error: "Add an image, prompt, supported format, and model." });
    return;
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    res.status(401).json({
      error: "Gemini is not connected yet. Add GEMINI_API_KEY in Secrets to enable generation.",
    });
    return;
  }

  const { model, prompt, imageBase64, mimeType } = parsed.data;

  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(apiKey)}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [
            {
              role: "user",
              parts: [
                { inlineData: { mimeType, data: imageBase64 } },
                { text: prompt },
              ],
            },
          ],
          generationConfig: {
            responseModalities: ["TEXT", "IMAGE"],
          },
        }),
      },
    );

    const payload = (await response.json()) as GeminiResponse;
    if (!response.ok) {
      req.log.warn(
        { status: response.status, providerStatus: payload.error?.status },
        "Gemini image generation failed",
      );
      res.status(upstreamStatus(response.status)).json({
        error:
          response.status === 429
            ? "Gemini quota or rate limit reached. Try again later."
            : payload.error?.message ?? "Gemini could not generate an image.",
      });
      return;
    }

    const imagePart = payload.candidates
      ?.flatMap((candidate) => candidate.content?.parts ?? [])
      .find((part) => part.inlineData?.data);

    if (!imagePart?.inlineData?.data || !imagePart.inlineData.mimeType) {
      req.log.warn({ model }, "Gemini returned no image part");
      res.status(502).json({
        error: "Gemini returned a response without an image. Try a more specific edit prompt.",
      });
      return;
    }

    const result = GenerateGeminiImageResponse.parse({
      imageBase64: imagePart.inlineData.data,
      mimeType: imagePart.inlineData.mimeType,
      model,
    });
    res.json(result);
  } catch (error) {
    req.log.error({ err: error, model }, "Gemini image request crashed");
    res.status(502).json({ error: "Could not reach Gemini. Try again in a moment." });
  }
});

export default router;