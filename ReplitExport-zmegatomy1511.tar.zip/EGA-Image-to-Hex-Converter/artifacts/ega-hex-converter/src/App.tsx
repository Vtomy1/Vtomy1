import { useCallback, useEffect, useRef, useState, type ChangeEvent, type DragEvent } from 'react';
import {
  Check,
  Cpu,
  Download,
  Ruler,
  ScanLine,
  Upload,
} from 'lucide-react';

type RGB = [number, number, number];

type PaletteEntry = {
  index: number;
  name: string;
  hex: string;
  rgb: RGB;
};

type ConversionResult = {
  width: number;
  height: number;
  indices: Uint8Array;
};

const EGA_PALETTE: PaletteEntry[] = [
  { index: 0, name: 'Black', hex: '#000000', rgb: [0, 0, 0] },
  { index: 1, name: 'Blue', hex: '#0000AA', rgb: [0, 0, 170] },
  { index: 2, name: 'Green', hex: '#00AA00', rgb: [0, 170, 0] },
  { index: 3, name: 'Cyan', hex: '#00AAAA', rgb: [0, 170, 170] },
  { index: 4, name: 'Red', hex: '#AA0000', rgb: [170, 0, 0] },
  { index: 5, name: 'Magenta', hex: '#AA00AA', rgb: [170, 0, 170] },
  { index: 6, name: 'Brown', hex: '#AA5500', rgb: [170, 85, 0] },
  { index: 7, name: 'Light Gray', hex: '#AAAAAA', rgb: [170, 170, 170] },
  { index: 8, name: 'Dark Gray', hex: '#555555', rgb: [85, 85, 85] },
  { index: 9, name: 'Bright Blue', hex: '#5555FF', rgb: [85, 85, 255] },
  { index: 10, name: 'Bright Green', hex: '#55FF55', rgb: [85, 255, 85] },
  { index: 11, name: 'Bright Cyan', hex: '#55FFFF', rgb: [85, 255, 255] },
  { index: 12, name: 'Bright Red', hex: '#FF5555', rgb: [255, 85, 85] },
  { index: 13, name: 'Bright Magenta', hex: '#FF55FF', rgb: [255, 85, 255] },
  { index: 14, name: 'Yellow', hex: '#FFFF55', rgb: [255, 255, 85] },
  { index: 15, name: 'White', hex: '#FFFFFF', rgb: [255, 255, 255] },
];

function nearestPaletteIndex(red: number, green: number, blue: number) {
  let bestIndex = 0;
  let bestDistance = Number.POSITIVE_INFINITY;

  for (const color of EGA_PALETTE) {
    const redDistance = red - color.rgb[0];
    const greenDistance = green - color.rgb[1];
    const blueDistance = blue - color.rgb[2];
    const distance = redDistance * redDistance + greenDistance * greenDistance + blueDistance * blueDistance;

    if (distance < bestDistance) {
      bestDistance = distance;
      bestIndex = color.index;
    }
  }

  return bestIndex;
}

function makeExport(result: ConversionResult) {
  const rows: string[] = [
    'EGA-HEX 1',
    `WIDTH ${result.width}`,
    `HEIGHT ${result.height}`,
    'PALETTE',
    ...EGA_PALETTE.map((color) => `${color.index.toString(16)} ${color.hex}`),
    'PIXELS',
  ];

  for (let y = 0; y < result.height; y += 1) {
    const rowStart = y * result.width;
    let row = '';
    for (let x = 0; x < result.width; x += 1) {
      row += result.indices[rowStart + x].toString(16);
    }
    rows.push(row);
  }

  return `${rows.join('\n')}\n`;
}

function App() {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [sourceImage, setSourceImage] = useState<HTMLImageElement | null>(null);
  const [fileName, setFileName] = useState('');
  const [ditheringEnabled, setDitheringEnabled] = useState(true);
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<ConversionResult | null>(null);
  const [downloadMessage, setDownloadMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const processImage = useCallback((image: HTMLImageElement, shouldDither: boolean) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const width = image.naturalWidth;
    const height = image.naturalHeight;
    if (!width || !height) return;

    const workCanvas = document.createElement('canvas');
    workCanvas.width = width;
    workCanvas.height = height;
    const workContext = workCanvas.getContext('2d', { willReadFrequently: true });
    const previewContext = canvas.getContext('2d');
    if (!workContext || !previewContext) return;

    workContext.drawImage(image, 0, 0);
    const imageData = workContext.getImageData(0, 0, width, height);
    const workingPixels = new Float32Array(imageData.data.length);
    for (let index = 0; index < imageData.data.length; index += 1) {
      workingPixels[index] = imageData.data[index];
    }

    const indices = new Uint8Array(width * height);
    const diffuse = (x: number, y: number, redError: number, greenError: number, blueError: number, factor: number) => {
      if (x < 0 || x >= width || y < 0 || y >= height) return;
      const pixelOffset = (y * width + x) * 4;
      workingPixels[pixelOffset] += redError * factor;
      workingPixels[pixelOffset + 1] += greenError * factor;
      workingPixels[pixelOffset + 2] += blueError * factor;
    };

    for (let y = 0; y < height; y += 1) {
      for (let x = 0; x < width; x += 1) {
        const pixelOffset = (y * width + x) * 4;
        const red = Math.max(0, Math.min(255, workingPixels[pixelOffset]));
        const green = Math.max(0, Math.min(255, workingPixels[pixelOffset + 1]));
        const blue = Math.max(0, Math.min(255, workingPixels[pixelOffset + 2]));
        const paletteIndex = nearestPaletteIndex(red, green, blue);
        const paletteColor = EGA_PALETTE[paletteIndex];
        indices[y * width + x] = paletteIndex;
        imageData.data[pixelOffset] = paletteColor.rgb[0];
        imageData.data[pixelOffset + 1] = paletteColor.rgb[1];
        imageData.data[pixelOffset + 2] = paletteColor.rgb[2];
        imageData.data[pixelOffset + 3] = 255;

        if (shouldDither) {
          const redError = red - paletteColor.rgb[0];
          const greenError = green - paletteColor.rgb[1];
          const blueError = blue - paletteColor.rgb[2];
          diffuse(x + 1, y, redError, greenError, blueError, 7 / 16);
          diffuse(x - 1, y + 1, redError, greenError, blueError, 3 / 16);
          diffuse(x, y + 1, redError, greenError, blueError, 5 / 16);
          diffuse(x + 1, y + 1, redError, greenError, blueError, 1 / 16);
        }
      }
    }

    canvas.width = width;
    canvas.height = height;
    previewContext.putImageData(imageData, 0, 0);
    setResult({ width, height, indices });
    setIsProcessing(false);
  }, []);

  useEffect(() => {
    if (sourceImage) {
      setIsProcessing(true);
      processImage(sourceImage, ditheringEnabled);
    }
  }, [ditheringEnabled, processImage, sourceImage]);

  const acceptFile = useCallback((file: File) => {
    if (!file.type.startsWith('image/')) {
      setErrorMessage('That file is not an image. Choose a PNG, JPEG, GIF, or WebP.');
      setDownloadMessage('');
      return;
    }

    setErrorMessage('');
    setDownloadMessage('');
    setIsProcessing(true);
    const imageUrl = URL.createObjectURL(file);
    const image = new Image();
    image.onload = () => {
      URL.revokeObjectURL(imageUrl);
      setFileName(file.name);
      setSourceImage(image);
    };
    image.onerror = () => {
      URL.revokeObjectURL(imageUrl);
      setIsProcessing(false);
      setErrorMessage('The image could not be decoded. Try exporting it as PNG first.');
    };
    image.src = imageUrl;
  }, []);

  const handleFileInput = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) acceptFile(file);
    event.target.value = '';
  };

  const handleDrop = (event: DragEvent<HTMLLabelElement>) => {
    event.preventDefault();
    setIsDragging(false);
    const file = event.dataTransfer.files?.[0];
    if (file) acceptFile(file);
  };

  const handleDownload = () => {
    if (!result) return;
    const exportText = makeExport(result);
    const blob = new Blob([exportText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    const baseName = fileName.replace(/\.[^/.]+$/, '') || 'ega-image';
    anchor.href = url;
    anchor.download = `${baseName}.txt`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
    setDownloadMessage(`Saved ${baseName}.txt`);
  };

  const pixelCount = result ? result.width * result.height : 0;

  return (
    <main className="workbench-shell">
      <div className="app-frame">
        <aside className="side-rail" aria-label="Application information">
          <div>
            <div className="brand-mark" data-testid="text-brand">
              <div className="brand-pixel" aria-hidden="true">
                {Array.from({ length: 9 }, (_, index) => <span key={index} />)}
              </div>
              <div className="brand-name">
                EGA / HEX
                <span className="brand-subtitle">pixel workbench</span>
              </div>
            </div>
            <p className="rail-label">Pipeline</p>
            <div className="rail-status" data-testid="status-pipeline">
              <span className="status-dot" aria-hidden="true" />
              browser-local / ready
            </div>
          </div>
          <div className="rail-footer">
            V1.0.0<br />
            NO SERVER · NO TRACKING
          </div>
        </aside>

        <section className="main-stage">
          <header className="topbar">
            <div>
              <p className="eyebrow">Image to indexed text utility</p>
              <h1 className="page-title">Turn pixels into <em>portable data.</em></h1>
            </div>
            <div className="topbar-note">
              16 colors / EGA palette<br />
              Floyd–Steinberg ready
            </div>
          </header>

          <div className="content-grid">
            <section className="panel preview-panel" aria-label="Dithered image preview">
              <div className="panel-header">
                <p className="panel-kicker">01 / Preview monitor</p>
                <span className="panel-index">{result ? 'CONVERTED' : 'AWAITING INPUT'}</span>
              </div>
              <div className="preview-stage">
                {isProcessing ? (
                  <div className="empty-preview" data-testid="status-processing">
                    <div>
                      <div className="empty-glyph" aria-hidden="true">•••</div>
                      <h2>Quantizing pixels</h2>
                      <p>Mapping source colors to the 16-color EGA register.</p>
                    </div>
                  </div>
                ) : result ? (
                  <canvas
                    ref={canvasRef}
                    className="preview-canvas"
                    data-testid="canvas-preview"
                    aria-label="EGA dithered preview"
                  />
                ) : (
                  <div className="empty-preview" data-testid="status-empty-preview">
                    <div>
                      <div className="empty-glyph" aria-hidden="true"><ScanLine size={25} strokeWidth={1.5} /></div>
                      <h2>Your preview is waiting.</h2>
                      <p>Drop an image into the inspector to see its EGA-indexed version rendered here.</p>
                    </div>
                  </div>
                )}
              </div>
            </section>

            <div className="inspector-stack">
              <section className="panel control-panel" aria-label="Image input and conversion controls">
                <div className="panel-header">
                  <p className="panel-kicker">02 / Inspector</p>
                  <span className="panel-index">INPUT</span>
                </div>
                <label
                  className={`drop-zone${isDragging ? ' is-dragging' : ''}`}
                  data-testid="drop-zone-upload"
                  tabIndex={0}
                  onDragEnter={(event) => {
                    event.preventDefault();
                    setIsDragging(true);
                  }}
                  onDragOver={(event) => event.preventDefault()}
                  onDragLeave={() => setIsDragging(false)}
                  onDrop={handleDrop}
                  onKeyDown={(event) => {
                    if (event.key === 'Enter' || event.key === ' ') fileInputRef.current?.click();
                  }}
                >
                  <Upload className="upload-icon" strokeWidth={1.5} aria-hidden="true" />
                  <strong>Drop image or browse</strong>
                  <span>PNG · JPG · GIF · WEBP</span>
                  <input
                    ref={fileInputRef}
                    className="file-input"
                    data-testid="input-image-upload"
                    type="file"
                    accept="image/png,image/jpeg,image/gif,image/webp"
                    onChange={handleFileInput}
                  />
                </label>

                <div className="controls">
                  <div className="control-row">
                    <div>
                      <span className="control-label">Floyd–Steinberg dithering</span>
                      <span className="control-help">diffuse quantization error</span>
                    </div>
                    <button
                      className={`switch${ditheringEnabled ? ' is-on' : ''}`}
                      type="button"
                      role="switch"
                      aria-checked={ditheringEnabled}
                      aria-label="Toggle Floyd–Steinberg dithering"
                      data-testid="button-toggle-dithering"
                      onClick={() => setDitheringEnabled((enabled) => !enabled)}
                    />
                  </div>
                </div>

                <div className="dimensions">
                  <div className="dimension-cell" data-testid="text-image-width">
                    <span className="dimension-label"><Ruler size={11} /> Width</span>
                    <span className="dimension-value mono">{result?.width ?? '—'}<small> px</small></span>
                  </div>
                  <div className="dimension-cell" data-testid="text-image-height">
                    <span className="dimension-label"><Ruler size={11} /> Height</span>
                    <span className="dimension-value mono">{result?.height ?? '—'}<small> px</small></span>
                  </div>
                </div>
              </section>

              <section className="panel palette-panel" aria-label="EGA palette">
                <div className="panel-header">
                  <p className="panel-kicker">03 / Register</p>
                  <span className="panel-index">16 COLORS</span>
                </div>
                <div className="palette-grid" data-testid="grid-palette">
                  {EGA_PALETTE.map((color) => (
                    <div
                      key={color.index}
                      className="swatch"
                      data-index={color.index.toString(16)}
                      title={`${color.index.toString(16)} · ${color.name} · ${color.hex}`}
                      style={{ backgroundColor: color.hex }}
                      data-testid={`swatch-palette-${color.index.toString(16)}`}
                    />
                  ))}
                </div>
              </section>

              <section className="panel export-panel" aria-label="Text export">
                <div className="panel-header">
                  <p className="panel-kicker">04 / Export</p>
                  <span className="panel-index">.TXT</span>
                </div>
                <p className="export-copy">
                  Deterministic output: dimensions, palette register, then one lowercase hex index per pixel row.
                </p>
                <button
                  className="download-button"
                  type="button"
                  data-testid="button-download-export"
                  disabled={!result}
                  onClick={handleDownload}
                >
                  {downloadMessage ? <Check size={16} aria-hidden="true" /> : <Download size={16} aria-hidden="true" />}
                  {downloadMessage ? 'Export saved' : 'Download .txt export'}
                </button>
                <p className="download-feedback" data-testid="status-download">
                  {downloadMessage || (result ? 'Ready to write' : 'Convert an image to enable export')}
                </p>
              </section>
            </div>
          </div>

          <div className="pixel-readout" data-testid="status-conversion">
            <Cpu size={13} aria-hidden="true" />{' '}
            {errorMessage ? (
              <strong>{errorMessage}</strong>
            ) : result ? (
              <>
                <strong data-testid="text-file-name">{fileName}</strong> converted locally · <strong>{pixelCount.toLocaleString()} pixels</strong> ·{' '}
                {ditheringEnabled ? 'error diffusion active' : 'nearest-color mode'} · <span className="mono">index range 0–f</span>
              </>
            ) : (
              <>No source loaded · <span className="mono">canvas pipeline idle</span></>
            )}
          </div>

          {errorMessage && (
            <button
              className="sr-only"
              type="button"
              data-testid="button-clear-error"
              onClick={() => setErrorMessage('')}
            >
              Clear upload error
            </button>
          )}
        </section>
      </div>
    </main>
  );
}

export default App;