export async function processAudio(
  buffer: AudioBuffer,
  params: { bitDepth: number; sampleRate: number; drive: number; addNoise: boolean },
  onProgress: (p: number) => void
): Promise<AudioBuffer> {
  const numChannels = buffer.numberOfChannels;
  const originalSampleRate = buffer.sampleRate;
  const length = buffer.length;

  const offlineCtx = new OfflineAudioContext(numChannels, length, originalSampleRate);
  const newBuffer = offlineCtx.createBuffer(numChannels, length, originalSampleRate);

  const step = originalSampleRate / params.sampleRate;
  const maxVal = Math.pow(2, params.bitDepth - 1);

  // We do processing in chunks to allow UI to update progress
  const chunkSize = 44100; // 1 second chunks roughly
  
  return new Promise((resolve) => {
    let offset = 0;

    function processChunk() {
      const end = Math.min(offset + chunkSize, length);
      
      for (let c = 0; c < numChannels; c++) {
        const inputData = buffer.getChannelData(c);
        const outputData = newBuffer.getChannelData(c);

        let phase = (offset % step);
        let lastSample = offset > 0 ? outputData[offset - 1] : 0;

        for (let i = offset; i < end; i++) {
          phase += 1;
          if (phase >= step) {
            phase -= step;
            let sample = inputData[i];

            // Distortion
            if (params.drive > 0) {
              const k = params.drive * 10;
              sample = (3 + k) * sample * 20 * (Math.PI / 180) / (Math.PI + k * Math.abs(sample));
            }

            // Bit crush
            sample = Math.round(sample * maxVal) / maxVal;

            // Noise
            if (params.addNoise) {
              sample += (Math.random() - 0.5) * 0.05;
            }

            // Clamp
            sample = Math.max(-1, Math.min(1, sample));

            lastSample = sample;
          }
          outputData[i] = lastSample;
        }
      }

      offset = end;
      onProgress(offset / length);

      if (offset < length) {
        setTimeout(processChunk, 0);
      } else {
        resolve(newBuffer);
      }
    }

    processChunk();
  });
}

export function audioBufferToWav(buffer: AudioBuffer): Blob {
  const numChannels = buffer.numberOfChannels;
  const sampleRate = buffer.sampleRate;
  const format = 1; // PCM
  const bitDepth = 16;
  
  let result: Float32Array;
  if (numChannels === 2) {
    result = interleave(buffer.getChannelData(0), buffer.getChannelData(1));
  } else {
    result = buffer.getChannelData(0);
  }
  
  return encodeWAV(result, format, sampleRate, numChannels, bitDepth);
}

function interleave(inputL: Float32Array, inputR: Float32Array): Float32Array {
  const length = inputL.length + inputR.length;
  const result = new Float32Array(length);
  
  let index = 0;
  let inputIndex = 0;
  
  while (index < length) {
    result[index++] = inputL[inputIndex];
    result[index++] = inputR[inputIndex];
    inputIndex++;
  }
  return result;
}

function encodeWAV(samples: Float32Array, format: number, sampleRate: number, numChannels: number, bitDepth: number): Blob {
  const bytesPerSample = bitDepth / 8;
  const blockAlign = numChannels * bytesPerSample;
  
  const buffer = new ArrayBuffer(44 + samples.length * bytesPerSample);
  const view = new DataView(buffer);
  
  writeString(view, 0, 'RIFF');
  view.setUint32(4, 36 + samples.length * bytesPerSample, true);
  writeString(view, 8, 'WAVE');
  writeString(view, 12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, format, true);
  view.setUint16(22, numChannels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * blockAlign, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, bitDepth, true);
  writeString(view, 36, 'data');
  view.setUint32(40, samples.length * bytesPerSample, true);
  
  floatTo16BitPCM(view, 44, samples);
  
  return new Blob([view], { type: 'audio/wav' });
}

function writeString(view: DataView, offset: number, string: string) {
  for (let i = 0; i < string.length; i++) {
    view.setUint8(offset + i, string.charCodeAt(i));
  }
}

function floatTo16BitPCM(output: DataView, offset: number, input: Float32Array) {
  for (let i = 0; i < input.length; i++, offset += 2) {
    const s = Math.max(-1, Math.min(1, input[i]));
    output.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
  }
}

export function drawWaveform(canvas: HTMLCanvasElement, buffer: AudioBuffer) {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const width = canvas.width;
  const height = canvas.height;
  
  ctx.clearRect(0, 0, width, height);
  
  const data = buffer.getChannelData(0);
  const step = Math.ceil(data.length / width);
  const amp = height / 2;
  
  ctx.fillStyle = '#000000';
  ctx.fillRect(0, 0, width, height);
  
  ctx.strokeStyle = '#00ff41';
  ctx.beginPath();
  
  for (let i = 0; i < width; i++) {
    let min = 1.0;
    let max = -1.0;
    for (let j = 0; j < step; j++) {
      const datum = data[(i * step) + j];
      if (datum < min) min = datum;
      if (datum > max) max = datum;
    }
    
    ctx.moveTo(i, (1 + min) * amp);
    ctx.lineTo(i, (1 + max) * amp);
  }
  
  ctx.stroke();
}
