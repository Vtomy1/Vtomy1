import React, { useState, useRef, useEffect } from "react";
import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { processAudio, audioBufferToWav, drawWaveform } from "@/lib/audio";

const queryClient = new QueryClient();

function Home() {
  const [file, setFile] = useState<File | null>(null);
  const [audioBuffer, setAudioBuffer] = useState<AudioBuffer | null>(null);
  const [processedBuffer, setProcessedBuffer] = useState<AudioBuffer | null>(null);
  
  const [bitDepth, setBitDepth] = useState(8);
  const [sampleRate, setSampleRate] = useState(8000);
  const [drive, setDrive] = useState(0);
  const [addNoise, setAddNoise] = useState(false);
  
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [statusMsg, setStatusMsg] = useState("Awaiting input...");
  
  const [isPlayingOrig, setIsPlayingOrig] = useState(false);
  const [isPlayingProc, setIsPlayingProc] = useState(false);

  const origCanvasRef = useRef<HTMLCanvasElement>(null);
  const procCanvasRef = useRef<HTMLCanvasElement>(null);
  
  const audioCtxRef = useRef<AudioContext | null>(null);
  const sourceNodeRef = useRef<AudioBufferSourceNode | null>(null);

  useEffect(() => {
    audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    return () => {
      audioCtxRef.current?.close();
    };
  }, []);

  useEffect(() => {
    if (audioBuffer && origCanvasRef.current) {
      drawWaveform(origCanvasRef.current, audioBuffer);
    }
  }, [audioBuffer]);

  useEffect(() => {
    if (processedBuffer && procCanvasRef.current) {
      drawWaveform(procCanvasRef.current, processedBuffer);
    }
  }, [processedBuffer]);

  const handleFileDrop = async (e: React.DragEvent | React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    let selectedFile: File | null = null;
    
    if ('dataTransfer' in e) {
      if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
        selectedFile = e.dataTransfer.files[0];
      }
    } else {
      if (e.target.files && e.target.files.length > 0) {
        selectedFile = e.target.files[0];
      }
    }

    if (selectedFile) {
      setFile(selectedFile);
      setStatusMsg(`Loading ${selectedFile.name}...`);
      
      const arrayBuffer = await selectedFile.arrayBuffer();
      if (audioCtxRef.current) {
        const decoded = await audioCtxRef.current.decodeAudioData(arrayBuffer);
        setAudioBuffer(decoded);
        setProcessedBuffer(null);
        setStatusMsg("Audio buffer loaded. Ready to crush.");
      }
    }
  };

  const handleConvert = async () => {
    if (!audioBuffer) return;
    setIsProcessing(true);
    setProgress(0);
    setStatusMsg("Applying bit crush algorithm...");
    
    const result = await processAudio(
      audioBuffer,
      { bitDepth, sampleRate, drive, addNoise },
      (p) => {
        setProgress(p);
        if (p > 0.9) setStatusMsg("Finalizing...");
      }
    );
    
    setProcessedBuffer(result);
    setIsProcessing(false);
    setStatusMsg("Done. Output ready for playback or download.");
  };

  const stopPlayback = () => {
    if (sourceNodeRef.current) {
      sourceNodeRef.current.stop();
      sourceNodeRef.current.disconnect();
      sourceNodeRef.current = null;
    }
    setIsPlayingOrig(false);
    setIsPlayingProc(false);
  };

  const playBuffer = (buffer: AudioBuffer, isOrig: boolean) => {
    if (!audioCtxRef.current) return;
    
    stopPlayback();
    
    const source = audioCtxRef.current.createBufferSource();
    source.buffer = buffer;
    source.connect(audioCtxRef.current.destination);
    source.start();
    source.onended = () => {
      if (isOrig) setIsPlayingOrig(false);
      else setIsPlayingProc(false);
    };
    
    sourceNodeRef.current = source;
    if (isOrig) setIsPlayingOrig(true);
    else setIsPlayingProc(true);
  };

  const handleDownload = () => {
    if (!processedBuffer) return;
    setStatusMsg("Encoding PCM data...");
    setTimeout(() => {
      const blob = audioBufferToWav(processedBuffer);
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `CRUSHED_${file?.name || "audio.wav"}`;
      a.click();
      URL.revokeObjectURL(url);
      setStatusMsg("Download complete.");
    }, 100);
  };

  const progressBars = Math.floor(progress * 20);
  const emptyBars = 20 - progressBars;
  const progressStr = `[${'█'.repeat(progressBars)}${'░'.repeat(emptyBars)}] ${Math.floor(progress * 100)}%`;

  return (
    <div className="min-h-screen w-full flex flex-col p-4 md:p-8 bg-black text-[#00ff41] font-mono text-lg md:text-xl selection:bg-[#00ff41] selection:text-black">
      <div className="max-w-4xl mx-auto w-full flex flex-col gap-6">
        
        <header className="mb-4">
          <p>8-BIT AUDIO CRUSHER v1.0  Copyright (C) 2025</p>
          <p>SYSTEM INITIALIZED... OK</p>
          <p className="blinking-cursor">C:\&gt;CRUSH.EXE</p>
        </header>

        <div className="dos-panel">
          <div className="dos-title">┌─[ FILE INPUT ]─┐</div>
          
          <div 
            className="border border-dashed border-[#00ff41] p-8 text-center cursor-pointer hover:bg-[#00ff41]/10 transition-colors"
            onDragOver={(e) => e.preventDefault()}
            onDrop={handleFileDrop}
            onClick={() => document.getElementById('fileUpload')?.click()}
          >
            <input 
              id="fileUpload" 
              type="file" 
              accept="audio/*" 
              className="hidden" 
              onChange={handleFileDrop} 
            />
            {file ? (
              <p>FILE LOADED: {file.name}</p>
            ) : (
              <p>DRAG & DROP AUDIO FILE HERE OR CLICK TO BROWSE</p>
            )}
          </div>

          {audioBuffer && (
            <div className="mt-4">
              <p className="mb-2">ORIGINAL WAVEFORM:</p>
              <canvas ref={origCanvasRef} width={800} height={100} className="w-full h-24 border border-[#00ff41]/50 bg-black block" />
              <div className="mt-2 flex gap-4">
                <button 
                  className="dos-button" 
                  onClick={() => isPlayingOrig ? stopPlayback() : playBuffer(audioBuffer, true)}
                >
                  [{isPlayingOrig ? " STOP " : " PLAY "}]
                </button>
              </div>
            </div>
          )}
        </div>

        <div className="dos-panel">
          <div className="dos-title">┌─[ PARAMETERS ]─┐</div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            
            <div className="flex flex-col gap-2">
              <div className="flex justify-between">
                <label>BIT DEPTH:</label>
                <span>{bitDepth}-BIT</span>
              </div>
              <input 
                type="range" 
                min="1" max="16" step="1" 
                value={bitDepth} 
                onChange={(e) => setBitDepth(Number(e.target.value))} 
              />
              <p className="text-sm text-[#00ff41]/70">Lower bits = more quantization noise</p>
            </div>

            <div className="flex flex-col gap-2">
              <div className="flex justify-between">
                <label>SAMPLE RATE:</label>
                <span>{sampleRate} HZ</span>
              </div>
              <input 
                type="range" 
                min="1000" max="44100" step="500" 
                value={sampleRate} 
                onChange={(e) => setSampleRate(Number(e.target.value))} 
              />
              <p className="text-sm text-[#00ff41]/70">Lower rate = aliasing/aliasing artifacts</p>
            </div>

            <div className="flex flex-col gap-2">
              <div className="flex justify-between">
                <label>OVERDRIVE:</label>
                <span>{drive.toFixed(1)}</span>
              </div>
              <input 
                type="range" 
                min="0" max="10" step="0.1" 
                value={drive} 
                onChange={(e) => setDrive(Number(e.target.value))} 
              />
            </div>

            <div className="flex flex-col justify-center">
              <label className="flex items-center gap-4 cursor-pointer">
                <input 
                  type="checkbox" 
                  className="hidden" 
                  checked={addNoise} 
                  onChange={(e) => setAddNoise(e.target.checked)} 
                />
                <span>[{addNoise ? 'X' : ' '}] LO-FI VINYL NOISE</span>
              </label>
            </div>

          </div>

          <div className="mt-8 text-center border-t border-[#00ff41]/50 pt-4">
            <button 
              className="dos-button text-2xl font-bold px-8 py-2"
              onClick={handleConvert}
              disabled={!audioBuffer || isProcessing}
            >
              [ EXECUTE CRUSH ]
            </button>
          </div>
        </div>

        <div className="dos-panel min-h-[200px]">
          <div className="dos-title">┌─[ OUTPUT ]─┐</div>
          
          <div className="mb-4">
            <p>STATUS: {statusMsg}</p>
            {isProcessing && <p className="mt-2 text-accent">{progressStr}</p>}
          </div>

          {processedBuffer && !isProcessing && (
            <div className="mt-4">
              <p className="mb-2">PROCESSED WAVEFORM:</p>
              <canvas ref={procCanvasRef} width={800} height={100} className="w-full h-24 border border-accent/50 bg-black block" />
              <div className="mt-4 flex gap-4">
                <button 
                  className="dos-button text-accent border border-accent p-1" 
                  onClick={() => isPlayingProc ? stopPlayback() : playBuffer(processedBuffer, false)}
                >
                  [{isPlayingProc ? " STOP " : " PLAY RESULT "}]
                </button>
                <button className="dos-button text-accent border border-accent p-1" onClick={handleDownload}>
                  [ DOWNLOAD .WAV ]
                </button>
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
