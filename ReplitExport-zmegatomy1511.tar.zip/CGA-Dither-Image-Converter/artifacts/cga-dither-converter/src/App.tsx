import { useCallback, useEffect, useRef, useState } from 'react';
import { Download, Image as ImageIcon, Info, Upload } from 'lucide-react';

type Palette = {
  id: string;
  name: string;
  detail: string;
  colors: [string, string, string, string];
};

type Asset = {
  kind: 'demo' | 'upload';
  name: string;
  width: number;
  height: number;
  image?: HTMLImageElement;
};

const WIDTH = 320;
const HEIGHT = 200;

const palettes: Palette[] = [
  { id: 'cga-1', name: 'CGA 1 · cyan / magenta', detail: 'black · cyan · magenta · white', colors: ['#111718', '#55ffff', '#ff55ff', '#f3f0d1'] },
  { id: 'cga-2', name: 'CGA 2 · green / red', detail: 'black · green · red · white', colors: ['#111718', '#55ff55', '#ff5555', '#f3f0d1'] },
  { id: 'cga-3', name: 'CGA 3 · cyan / red', detail: 'black · cyan · red · white', colors: ['#111718', '#55ffff', '#ff5555', '#f3f0d1'] },
  { id: 'cga-hi', name: 'CGA high-intensity', detail: 'ink · steel · cream · paper', colors: ['#15191a', '#5d6874', '#b4bbbd', '#f3e9cf'] },
];

const demoAsset: Asset = { kind: 'demo', name: 'signal-study.cga', width: 640, height: 400 };

function clamp(value: number, min: number, max: number) {
  return Math.min(max, Math.max(min, value));
}

function luminance(red: number, green: number, blue: number) {
  return red * 0.299 + green * 0.587 + blue * 0.114;
}

function makeDemo(canvas: HTMLCanvasElement) {
  canvas.width = 640;
  canvas.height = 400;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  ctx.fillStyle = '#d6d0b7';
  ctx.fillRect(0, 0, 640, 400);
  ctx.fillStyle = '#182928';
  ctx.fillRect(0, 235, 640, 165);
  ctx.fillStyle = '#d2765f';
  ctx.beginPath();
  ctx.arc(470, 126, 66, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#3e6b5a';
  ctx.beginPath();
  ctx.moveTo(0, 280); ctx.lineTo(132, 142); ctx.lineTo(235, 280); ctx.lineTo(345, 164); ctx.lineTo(500, 280); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#7fa66b';
  ctx.beginPath();
  ctx.moveTo(205, 280); ctx.lineTo(345, 164); ctx.lineTo(500, 280); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#d5c99f';
  ctx.fillRect(58, 318, 326, 7);
  ctx.fillRect(92, 339, 254, 5);
  ctx.fillStyle = '#a24e3c';
  ctx.fillRect(510, 292, 68, 70);
  ctx.fillStyle = '#f0dcac';
  ctx.fillRect(524, 305, 40, 42);
  ctx.fillStyle = '#182928';
  ctx.font = '500 16px "DM Mono", monospace';
  ctx.fillText('CGA / 320 × 200', 28, 40);
  ctx.font = '400 11px "DM Mono", monospace';
  ctx.fillText('SIGNAL STUDY 004', 30, 61);
  for (let x = 0; x < 640; x += 16) {
    ctx.fillStyle = x % 32 === 0 ? 'rgba(243,240,209,.12)' : 'rgba(17,23,24,.08)';
    ctx.fillRect(x, 0, 1, 400);
  }
}

function drawAssetToCanvas(asset: Asset, canvas: HTMLCanvasElement) {
  if (asset.kind === 'demo') {
    makeDemo(canvas);
    return;
  }
  if (!asset.image) return;
  canvas.width = asset.width;
  canvas.height = asset.height;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  ctx.clearRect(0, 0, asset.width, asset.height);
  ctx.drawImage(asset.image, 0, 0);
}

function drawOutput(
  asset: Asset,
  sourceCanvas: HTMLCanvasElement,
  outputCanvas: HTMLCanvasElement,
  palette: Palette,
  method: string,
  fitMode: string,
  cropFocus: number,
) {
  outputCanvas.width = WIDTH;
  outputCanvas.height = HEIGHT;
  const outputContext = outputCanvas.getContext('2d');
  if (!outputContext) return [] as string[];

  outputContext.fillStyle = palette.colors[0];
  outputContext.fillRect(0, 0, WIDTH, HEIGHT);
  const sourceRatio = asset.width / asset.height;
  const targetRatio = WIDTH / HEIGHT;
  let drawWidth = WIDTH;
  let drawHeight = HEIGHT;
  let offsetX = 0;
  let offsetY = 0;

  if (fitMode === 'contain') {
    const scale = Math.min(WIDTH / asset.width, HEIGHT / asset.height);
    drawWidth = Math.round(asset.width * scale);
    drawHeight = Math.round(asset.height * scale);
    offsetX = Math.round((WIDTH - drawWidth) / 2);
    offsetY = Math.round((HEIGHT - drawHeight) / 2);
  } else if (fitMode === 'cover') {
    const scale = Math.max(WIDTH / asset.width, HEIGHT / asset.height);
    drawWidth = Math.round(asset.width * scale);
    drawHeight = Math.round(asset.height * scale);
    offsetX = Math.round((WIDTH - drawWidth) * cropFocus);
    offsetY = Math.round((HEIGHT - drawHeight) / 2);
  } else if (sourceRatio < targetRatio) {
    offsetY = Math.round((HEIGHT - drawHeight) / 2);
  }
  outputContext.imageSmoothingEnabled = false;
  outputContext.drawImage(sourceCanvas, offsetX, offsetY, drawWidth, drawHeight);

  const image = outputContext.getImageData(0, 0, WIDTH, HEIGHT);
  const pixels = image.data;
  const values = new Float32Array(WIDTH * HEIGHT);
  for (let i = 0; i < values.length; i += 1) {
    const p = i * 4;
    values[i] = luminance(pixels[p], pixels[p + 1], pixels[p + 2]);
  }

  const bayer2 = [[0, 2], [3, 1]];
  const bayer4 = [
    [0, 8, 2, 10],
    [12, 4, 14, 6],
    [3, 11, 1, 9],
    [15, 7, 13, 5],
  ];
  const grid: string[] = [];
  const result = new Uint8Array(WIDTH * HEIGHT);

  if (method === 'floyd') {
    for (let y = 0; y < HEIGHT; y += 1) {
      for (let x = 0; x < WIDTH; x += 1) {
        const index = y * WIDTH + x;
        const level = clamp(Math.round(values[index] / 255 * 3), 0, 3);
        result[index] = level;
        const error = values[index] - level / 3 * 255;
        if (x + 1 < WIDTH) values[index + 1] += error * 7 / 16;
        if (y + 1 < HEIGHT) {
          if (x > 0) values[index + WIDTH - 1] += error * 3 / 16;
          values[index + WIDTH] += error * 5 / 16;
          if (x + 1 < WIDTH) values[index + WIDTH + 1] += error / 16;
        }
      }
    }
  } else {
    for (let y = 0; y < HEIGHT; y += 1) {
      for (let x = 0; x < WIDTH; x += 1) {
        const index = y * WIDTH + x;
        let level = values[index] / 255 * 3;
        if (method === 'bayer2') level += (bayer2[y % 2][x % 2] - 1.5) / 3;
        if (method === 'bayer4') level += (bayer4[y % 4][x % 4] - 7.5) / 6;
        result[index] = clamp(Math.round(level), 0, 3);
      }
    }
  }

  for (let i = 0; i < result.length; i += 1) {
    const p = i * 4;
    const color = palette.colors[result[i]];
    const match = color.match(/^#([0-9a-f]{6})$/i);
    if (match) {
      pixels[p] = parseInt(match[1].slice(0, 2), 16);
      pixels[p + 1] = parseInt(match[1].slice(2, 4), 16);
      pixels[p + 2] = parseInt(match[1].slice(4, 6), 16);
    }
    pixels[p + 3] = 255;
  }
  outputContext.putImageData(image, 0, 0);
  for (let y = 0; y < HEIGHT; y += 1) {
    let row = '';
    for (let x = 0; x < WIDTH; x += 1) row += result[y * WIDTH + x].toString();
    grid.push(row);
  }
  return grid;
}

function App() {
  const sourceCanvasRef = useRef<HTMLCanvasElement>(null);
  const outputCanvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [asset, setAsset] = useState<Asset>(demoAsset);
  const [paletteId, setPaletteId] = useState('cga-hi');
  const [method, setMethod] = useState('bayer4');
  const [fitMode, setFitMode] = useState('cover');
  const [cropFocus, setCropFocus] = useState(0.5);
  const [grid, setGrid] = useState<string[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [notice, setNotice] = useState('');

  const render = useCallback(() => {
    const sourceCanvas = sourceCanvasRef.current;
    const outputCanvas = outputCanvasRef.current;
    if (!sourceCanvas || !outputCanvas) return;
    drawAssetToCanvas(asset, sourceCanvas);
    const palette = palettes.find((item) => item.id === paletteId) ?? palettes[3];
    const nextGrid = drawOutput(asset, sourceCanvas, outputCanvas, palette, method, fitMode, cropFocus);
    setGrid(nextGrid);
  }, [asset, cropFocus, fitMode, method, paletteId]);

  useEffect(() => {
    setIsProcessing(true);
    const timer = window.setTimeout(() => {
      render();
      setIsProcessing(false);
    }, asset.kind === 'demo' ? 90 : 180);
    return () => window.clearTimeout(timer);
  }, [asset, render]);

  const loadFile = useCallback((file?: File) => {
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setNotice('That file is not an image. Choose PNG, JPG, GIF, or WebP.');
      return;
    }
    setNotice('');
    const objectUrl = URL.createObjectURL(file);
    const image = new Image();
    image.onload = () => {
      setAsset({ kind: 'upload', name: file.name, width: image.naturalWidth, height: image.naturalHeight, image });
      URL.revokeObjectURL(objectUrl);
    };
    image.onerror = () => {
      setNotice('The image could not be decoded in this browser.');
      URL.revokeObjectURL(objectUrl);
    };
    image.src = objectUrl;
  }, []);

  const downloadGrid = () => {
    if (!grid.length) return;
    const palette = palettes.find((item) => item.id === paletteId) ?? palettes[3];
    const header = [
      '# CGA DITHER CONVERTER',
      `# SOURCE: ${asset.name}`,
      `# OUTPUT: ${WIDTH}x${HEIGHT}`,
      `# PALETTE: ${palette.name}`,
      `# DITHER: ${method === 'floyd' ? 'Floyd–Steinberg' : method === 'bayer2' ? 'Bayer 2×2' : method === 'bayer4' ? 'Bayer 4×4' : 'Threshold'}`,
      '# FORMAT: one digit per pixel, 0–3',
      '# --- BEGIN GRID ---',
    ].join('\n');
    const blob = new Blob([`${header}\n${grid.join('\n')}\n`], { type: 'text/plain;charset=utf-8' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `${asset.name.replace(/\.[^.]+$/, '') || 'cga-output'}-320x200.txt`;
    link.click();
    URL.revokeObjectURL(link.href);
  };

  const selectedPalette = palettes.find((item) => item.id === paletteId) ?? palettes[3];
  const methodName = method === 'floyd' ? 'Floyd–Steinberg' : method === 'bayer2' ? 'Bayer 2×2' : method === 'bayer4' ? 'Bayer 4×4' : 'Threshold';

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand">
          <div className="brand-mark" aria-hidden="true">CGA</div>
          <div>
            <div className="brand-name">CGA Dither Converter <span className="brand-sub">/ workshop 01</span></div>
          </div>
        </div>
        <div className="header-note">A browser-native artifact tool</div>
      </header>

      <main className="main">
        <section className="intro" aria-labelledby="page-title">
          <div>
            <p className="eyebrow">Raster reduction / 2-bit output</p>
            <h1 className="title" id="page-title">Make it <em>320 × 200.</em><br />Keep the character.</h1>
          </div>
          <p className="intro-copy">A precise little bench for turning modern images into four-color CGA artifacts. No upload leaves your browser.</p>
        </section>

        <section className="workbench" aria-label="CGA conversion workbench">
          <div className="stage">
            <div className="stage-head">
              <p className="section-label">Signal preview</p>
              <div className="status-pill" data-testid="status-processing">
                <span className={`status-dot${isProcessing ? ' busy' : ''}`} />
                {isProcessing ? 'Converting' : asset.kind === 'demo' ? 'Demo signal' : 'Ready'}
              </div>
            </div>
            <div className="canvas-row">
              <div className="canvas-card">
                <div className="canvas-frame">
                  {asset.kind === 'demo' && <span className="demo-stamp">DEMO INPUT</span>}
                  <canvas ref={sourceCanvasRef} data-testid="canvas-source" aria-label="Source image preview" />
                </div>
                <div className="canvas-meta"><span>Input / <strong>{asset.width} × {asset.height}</strong></span><span>full color</span></div>
              </div>
              <div className="canvas-card">
                <div className="canvas-frame output-frame">
                  <canvas ref={outputCanvasRef} data-testid="canvas-output" aria-label="320 by 200 CGA output preview" />
                  {isProcessing && <div className="processing-overlay"><span>Writing pixels</span></div>}
                </div>
                <div className="canvas-meta"><span>Output / <strong>320 × 200</strong></span><span>2-bit / 4 colors</span></div>
              </div>
            </div>
            <div className="stage-foot">
              <span className="file-label" data-testid="text-source-name">{asset.name}</span>
              <div style={{ display: 'flex', gap: 8, width: 'min(100%, 390px)' }}>
                <button className="replace-button" type="button" onClick={() => fileInputRef.current?.click()} data-testid="button-replace-image">Replace image</button>
                <button className="download-button" type="button" onClick={downloadGrid} disabled={isProcessing || !grid.length} data-testid="button-download-txt">
                  <Download size={14} strokeWidth={1.8} /> Download .TXT
                </button>
              </div>
            </div>
          </div>

          <aside className="sidebar">
            <div className="panel">
              <div className="panel-head"><h2 className="panel-title">Palette register</h2><span className="section-label">4 colors</span></div>
              <div className="panel-body">
                <div className="palette-grid" role="radiogroup" aria-label="CGA palette">
                  {palettes.map((palette) => (
                    <button
                      type="button"
                      key={palette.id}
                      className={`palette-option${palette.id === paletteId ? ' selected' : ''}`}
                      onClick={() => setPaletteId(palette.id)}
                      data-testid={`button-palette-${palette.id}`}
                      aria-pressed={palette.id === paletteId}
                    >
                      <span className="swatches">{palette.colors.map((color, index) => <span className="swatch" style={{ backgroundColor: color }} key={`${palette.id}-${index}`} />)}</span>
                      <span><span className="palette-name">{palette.name}</span><span className="palette-detail">{palette.detail}</span></span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="panel">
              <div className="panel-head"><h2 className="panel-title">Conversion controls</h2><span className="section-label">live</span></div>
              <div className="panel-body">
                <div className="control-group">
                  <label className="control-label" htmlFor="dither-method"><span>Dither method</span></label>
                  <div className="select-wrap">
                    <select id="dither-method" value={method} onChange={(event) => setMethod(event.target.value)} data-testid="select-dither-method">
                      <option value="bayer4">Bayer 4×4 · balanced</option>
                      <option value="bayer2">Bayer 2×2 · crisp</option>
                      <option value="floyd">Floyd–Steinberg · soft</option>
                      <option value="threshold">Threshold · hard</option>
                    </select>
                    <span className="select-arrow" />
                  </div>
                </div>
                <div className="control-group">
                  <label className="control-label" htmlFor="fit-mode"><span>Fit / crop</span></label>
                  <div className="select-wrap">
                    <select id="fit-mode" value={fitMode} onChange={(event) => setFitMode(event.target.value)} data-testid="select-fit-mode">
                      <option value="cover">Cover · crop to frame</option>
                      <option value="contain">Contain · letterbox</option>
                      <option value="stretch">Stretch · fill frame</option>
                    </select>
                    <span className="select-arrow" />
                  </div>
                </div>
                {fitMode === 'cover' && (
                  <div className="control-group">
                    <label className="control-label" htmlFor="crop-focus"><span>Crop focus</span><span className="control-value">{cropFocus < .34 ? 'left' : cropFocus > .66 ? 'right' : 'center'}</span></label>
                    <input id="crop-focus" type="range" min="0" max="1" step="0.01" value={cropFocus} onChange={(event) => setCropFocus(Number(event.target.value))} data-testid="input-crop-focus" />
                    <div className="range-notes"><span>left edge</span><span>right edge</span></div>
                  </div>
                )}
              </div>
            </div>

            <div className="panel">
              <div className="panel-head"><h2 className="panel-title">Image register</h2><Info size={14} color="var(--muted-ink)" /></div>
              <div className="panel-body">
                <dl className="meta-grid">
                  <div className="meta-item"><dt>Source size</dt><dd data-testid="text-source-dimensions">{asset.width} × {asset.height}</dd></div>
                  <div className="meta-item"><dt>Reduction</dt><dd data-testid="text-reduction">{Math.max(1, Math.round(asset.width / WIDTH))}× / {Math.max(1, Math.round(asset.height / HEIGHT))}×</dd></div>
                  <div className="meta-item"><dt>Palette</dt><dd data-testid="text-selected-palette">{selectedPalette.id.replace('cga-', 'CGA ')}</dd></div>
                  <div className="meta-item"><dt>Method</dt><dd data-testid="text-selected-method">{methodName}</dd></div>
                </dl>
              </div>
            </div>

            <div
              className={`drop-zone${isDragging ? ' dragging' : ''}`}
              onDragOver={(event) => { event.preventDefault(); setIsDragging(true); }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={(event) => { event.preventDefault(); setIsDragging(false); loadFile(event.dataTransfer.files[0]); }}
              data-testid="drop-zone"
            >
              <div className="drop-icon"><Upload size={18} strokeWidth={1.6} /></div>
              <h2 className="drop-title">Drop an image here</h2>
              <p className="drop-copy">Bring a PNG, JPG, GIF, or WebP into the bench. Your source stays local.</p>
              <button type="button" className="browse-button" onClick={() => fileInputRef.current?.click()} data-testid="button-browse-image">Browse files</button>
              <p className="fine-print"><ImageIcon size={11} style={{ verticalAlign: 'middle', marginRight: 4 }} /> Images only / max practical size 4096px</p>
            </div>
            {notice && <div className="notice" role="alert" data-testid="status-upload-error">{notice}</div>}
          </aside>
        </section>

        <footer className="footer">
          <span>CGA DITHER CONVERTER / 2024–25</span>
          <span>Export is plain text: 200 rows × 320 columns / digits 0–3</span>
        </footer>
      </main>

      <input
        ref={fileInputRef}
        className="sr-only"
        type="file"
        accept="image/png,image/jpeg,image/gif,image/webp"
        onChange={(event) => { loadFile(event.target.files?.[0]); event.currentTarget.value = ''; }}
        data-testid="input-image-file"
      />
    </div>
  );
}

export default App;