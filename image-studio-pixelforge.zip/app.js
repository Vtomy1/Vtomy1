const { useState, useEffect, useRef, useCallback } = React;
const h = React.createElement;

// ---------- Models ----------
const MODELS = [
  {
    id: "nanobanana",
    name: "Nanobanana 2",
    vibe: "Photoreal edits & composition. Gemini-powered heavyweight.",
    badges: ["HQ", "Free"],
    accent: "#ffcb47",
    emoji: "🍌"
  },
  {
    id: "flux",
    name: "Flux Dream",
    vibe: "Painterly, imaginative reinterpretations of your image.",
    badges: ["Free", "Artsy"],
    accent: "#ff5fa2",
    emoji: "🌊"
  },
  {
    id: "turbo",
    name: "Turbo",
    vibe: "Fast & loose. Speed over precision, chaos welcome.",
    badges: ["Fast", "Free"],
    accent: "#ff8a3d",
    emoji: "⚡"
  },
  {
    id: "retro",
    name: "RetroDiffusion",
    vibe: "8-bit pixel-art & sprite transforms. Game asset energy.",
    badges: ["Pixel", "Free"],
    accent: "#8b7bff",
    emoji: "👾"
  }
];

const ASPECTS = [
  { id: "1:1", w: 1024, h: 1024, label: "Square" },
  { id: "3:4", w: 768, h: 1024, label: "Portrait" },
  { id: "4:3", w: 1024, h: 768, label: "Landscape" },
  { id: "16:9", w: 1024, h: 576, label: "Wide" }
];

const SURPRISES = [
  "turn into a Renaissance oil painting with dramatic chiaroscuro",
  "make it cyberpunk neon with rain and glowing signage",
  "as a claymation stop-motion figure",
  "vaporwave dream, pastel gradients and glitch",
  "hand-drawn ink sketch with cross-hatching",
  "as a cozy Studio Ghibli scene, soft light",
  "low-poly 3D render, flat shading",
  "graffiti street-art mural on a brick wall",
  "underwater bioluminescent fantasy version",
  "steampunk brass and copper reimagining"
];

const LOADING_MSGS = [
  "Bribing the GPUs…",
  "Rearranging pixels…",
  "Consulting the color spirits…",
  "Teaching electrons to paint…",
  "Negotiating with the render gremlins…",
  "Warming up the pixel forge…",
  "Summoning tasteful chaos…",
  "Convincing the model it's an artist…"
];

// ---------- Helpers ----------
function loadLS(key, fallback) {
  try { const v = JSON.parse(localStorage.getItem(key)); return v == null ? fallback : v; }
  catch { return fallback; }
}
function saveLS(key, val) { try { localStorage.setItem(key, JSON.stringify(val)); } catch {} }

function makeThumb(dataUrl, cb, size = 120) {
  const img = new Image();
  img.onload = () => {
    const c = document.createElement("canvas");
    const scale = size / Math.max(img.width, img.height);
    c.width = img.width * scale; c.height = img.height * scale;
    c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
    try { cb(c.toDataURL("image/jpeg", 0.6)); } catch { cb(null); }
  };
  img.onerror = () => cb(null);
  img.src = dataUrl;
}

// Build a generation URL depending on model
function buildGenUrl({ model, prompt, aspect, seed }) {
  const a = ASPECTS.find(x => x.id === aspect) || ASPECTS[0];
  const p = encodeURIComponent(prompt.trim() || "surreal transformation");
  if (model === "nanobanana") {
    return `/api/nanobanana/image/${a.w}/${a.h}?prompt=${p}&aspect_ratio=${aspect}&seed=${seed}`;
  }
  if (model === "retro") {
    const size = Math.min(a.w, 512);
    const sq = 256;
    return `/api/retrodiffusion/image/${sq}/${sq}?prompt=${p}+pixel+art&seed=${seed}`;
  }
  // pollinations models: flux -> flux, turbo -> turbo
  const pmodel = model === "flux" ? "flux" : "turbo";
  return `https://image.pollinations.ai/prompt/${p}?model=${pmodel}&width=${a.w}&height=${a.h}&seed=${seed}&nologo=true`;
}

// ---------- Small UI pieces ----------
function Badge({ text, accent }) {
  return h("span", {
    className: "text-[10px] font-mono uppercase tracking-widest px-2 py-0.5 rounded-full",
    style: { background: accent + "22", color: accent, border: "1px solid " + accent + "55" }
  }, text);
}

function Confetti({ fire }) {
  const ref = useRef(null);
  useEffect(() => {
    if (!fire) return;
    const el = ref.current; if (!el) return;
    el.innerHTML = "";
    const colors = ["#ffcb47", "#ff5fa2", "#ff8a3d", "#8b7bff", "#4be3ac"];
    for (let i = 0; i < 40; i++) {
      const s = document.createElement("span");
      s.className = "pf-confetti";
      s.style.left = Math.random() * 100 + "%";
      s.style.background = colors[i % colors.length];
      s.style.animationDelay = (Math.random() * 0.3) + "s";
      s.style.transform = `rotate(${Math.random()*360}deg)`;
      el.appendChild(s);
    }
    const t = setTimeout(() => { if (el) el.innerHTML = ""; }, 1600);
    return () => clearTimeout(t);
  }, [fire]);
  return h("div", { ref, className: "pf-confetti-layer" });
}

// ---------- Main App ----------
const App = () => {
  const saved = loadLS("pixelforge-settings", {});
  const [source, setSource] = useState(null);       // data url of source image
  const [sourceThumb, setSourceThumb] = useState(null);
  const [prompt, setPrompt] = useState("");
  const [negative, setNegative] = useState("");
  const [showAdv, setShowAdv] = useState(false);
  const [model, setModel] = useState(saved.model || "nanobanana");
  const [aspect, setAspect] = useState(saved.aspect || "1:1");
  const [strength, setStrength] = useState(saved.strength != null ? saved.strength : 0.65);
  const [loading, setLoading] = useState(false);
  const [loadMsg, setLoadMsg] = useState(LOADING_MSGS[0]);
  const [result, setResult] = useState(null);        // {url, model, prompt}
  const [history, setHistory] = useState(loadLS("pixelforge-history", []));
  const [error, setError] = useState("");
  const [compare, setCompare] = useState(false);
  const [comparePos, setComparePos] = useState(50);
  const [genCount, setGenCount] = useState(loadLS("pixelforge-count", 0));
  const [confettiKey, setConfettiKey] = useState(0);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const fileRef = useRef(null);
  const loadTimer = useRef(null);

  useEffect(() => saveLS("pixelforge-settings", { model, aspect, strength }), [model, aspect, strength]);
  useEffect(() => saveLS("pixelforge-history", history), [history]);
  useEffect(() => saveLS("pixelforge-count", genCount), [genCount]);

  // paste-to-load
  useEffect(() => {
    const onPaste = (e) => {
      for (const item of e.clipboardData.items) {
        if (item.type.startsWith("image/")) {
          const blob = item.getAsFile();
          const r = new FileReader();
          r.onload = () => setSourceImg(r.result);
          r.readAsDataURL(blob);
        }
      }
    };
    document.addEventListener("paste", onPaste);
    return () => document.removeEventListener("paste", onPaste);
  }, []);

  function setSourceImg(dataUrl) {
    setSource(dataUrl);
    makeThumb(dataUrl, (t) => setSourceThumb(t || dataUrl));
  }

  function onFile(file) {
    if (!file || !file.type.startsWith("image/")) return;
    const r = new FileReader();
    r.onload = () => setSourceImg(r.result);
    r.readAsDataURL(file);
  }

  function handleDrop(e) {
    e.preventDefault();
    const f = e.dataTransfer.files[0];
    onFile(f);
  }

  const activeModel = MODELS.find(m => m.id === model) || MODELS[0];

  function surprise() {
    const s = SURPRISES[Math.floor(Math.random() * SURPRISES.length)];
    setPrompt(s);
  }

  function generate() {
    if (loading) return;
    setError("");
    if (!prompt.trim()) { setError("Type what you want the image to become first."); return; }
    setLoading(true);
    setCompare(false);
    let i = 0;
    setLoadMsg(LOADING_MSGS[Math.floor(Math.random() * LOADING_MSGS.length)]);
    loadTimer.current = setInterval(() => {
      i++; setLoadMsg(LOADING_MSGS[(i) % LOADING_MSGS.length]);
    }, 1500);

    const seed = Math.floor(Math.random() * 99999);
    let fullPrompt = prompt.trim();
    if (source && model === "nanobanana") {
      // nanobanana handles source via base_image_url normally; here we describe edit intent
      fullPrompt = fullPrompt + ", high detail transformation";
    }
    if (negative.trim()) fullPrompt += " (avoid: " + negative.trim() + ")";

    const url = buildGenUrl({ model, prompt: fullPrompt, aspect, seed });

    const img = new Image();
    const done = (ok) => {
      clearInterval(loadTimer.current);
      setLoading(false);
      if (!ok) { setError("The forge sputtered. Try again or switch models."); return; }
      const res = { url, model, prompt: prompt.trim(), createdAt: new Date().toISOString() };
      setResult(res);
      setConfettiKey(k => k + 1);
      setGenCount(c => c + 1);
      setHistory(prev => {
        const entry = { id: seed + "-" + Date.now(), ...res, sourceThumb };
        return [entry, ...prev].slice(0, 24);
      });
    };
    img.onload = () => done(true);
    img.onerror = () => done(false);
    img.src = url;
  }

  function useAsSource(url) {
    // cross-origin images can't always be re-read; use url directly as source display
    setSourceImg(url);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function download(url) {
    const a = document.createElement("a");
    a.href = url; a.download = "pixelforge.png"; a.target = "_blank";
    a.rel = "noopener";
    a.click();
  }

  function regen() { generate(); }

  // ---------- Render sub-sections ----------
  const uploadZone = h("div", {
    onDrop: handleDrop,
    onDragOver: (e) => e.preventDefault(),
    onClick: () => fileRef.current && fileRef.current.click(),
    className: "pf-drop rounded-2xl p-4 cursor-pointer text-center transition"
  },
    h("input", {
      ref: fileRef, type: "file", accept: "image/*", className: "hidden",
      onChange: (e) => onFile(e.target.files[0])
    }),
    source
      ? h("div", { className: "relative" },
          h("img", { src: source, className: "w-full rounded-xl object-contain max-h-52 mx-auto" }),
          h("button", {
            onClick: (e) => { e.stopPropagation(); setSource(null); setSourceThumb(null); },
            className: "absolute top-1 right-1 bg-black/70 text-white text-xs px-2 py-1 rounded-full hover:bg-black"
          }, "✕ clear")
        )
      : h("div", { className: "py-6" },
          h("div", { className: "text-3xl mb-2" }, "🖼️"),
          h("div", { className: "font-semibold text-neutral-200" }, "Drop an image"),
          h("div", { className: "text-xs text-neutral-500 mt-1" }, "or click / paste from clipboard"),
          h("div", { className: "text-[10px] text-neutral-600 mt-2 font-mono" }, "optional — text-only works too")
        )
  );

  const modelPicker = h("div", { className: "grid grid-cols-2 gap-2" },
    MODELS.map(m => h("button", {
      key: m.id,
      onClick: () => setModel(m.id),
      className: "text-left rounded-xl p-3 border transition " +
        (model === m.id ? "pf-model-active" : "border-white/10 hover:border-white/25 bg-white/[0.03]"),
      style: model === m.id ? { borderColor: m.accent, boxShadow: "0 0 0 1px " + m.accent + ", 0 8px 30px " + m.accent + "33" } : {}
    },
      h("div", { className: "flex items-center gap-2 mb-1" },
        h("span", { className: "text-lg" }, m.emoji),
        h("span", { className: "font-bold text-sm text-neutral-100" }, m.name)
      ),
      h("div", { className: "text-[11px] text-neutral-400 leading-snug mb-2" }, m.vibe),
      h("div", { className: "flex gap-1 flex-wrap" }, m.badges.map(b => h(Badge, { key: b, text: b, accent: m.accent })))
    ))
  );

  const controls = h("div", { className: "space-y-4" },
    h("div", null,
      h("div", { className: "flex items-center justify-between mb-1" },
        h("label", { className: "text-xs font-mono uppercase tracking-widest text-neutral-400" }, "Transform into…"),
        h("button", { onClick: surprise, className: "text-[11px] font-semibold pf-link" }, "🎲 surprise me")
      ),
      h("textarea", {
        value: prompt,
        onChange: (e) => setPrompt(e.target.value),
        placeholder: "make it a neon cyberpunk city at night…",
        rows: 3,
        className: "w-full rounded-xl bg-black/40 border border-white/10 focus:border-pink-400/60 outline-none p-3 text-sm text-neutral-100 resize-none placeholder-neutral-600"
      })
    ),
    h("button", {
      onClick: () => setShowAdv(v => !v),
      className: "text-xs font-mono text-neutral-500 hover:text-neutral-300"
    }, (showAdv ? "▾ " : "▸ ") + "advanced options"),
    showAdv && h("div", { className: "space-y-3 pt-1" },
      h("div", null,
        h("label", { className: "text-xs font-mono uppercase tracking-widest text-neutral-400 block mb-1" }, "Negative prompt"),
        h("input", {
          value: negative, onChange: (e) => setNegative(e.target.value),
          placeholder: "blurry, low quality, extra fingers…",
          className: "w-full rounded-xl bg-black/40 border border-white/10 outline-none p-2.5 text-sm text-neutral-100 placeholder-neutral-600"
        })
      ),
      h("div", null,
        h("label", { className: "text-xs font-mono uppercase tracking-widest text-neutral-400 flex justify-between mb-1" },
          h("span", null, "Strength"), h("span", { className: "text-pink-300" }, strength.toFixed(2))),
        h("input", {
          type: "range", min: 0, max: 1, step: 0.05, value: strength,
          onChange: (e) => setStrength(parseFloat(e.target.value)),
          className: "w-full pf-range"
        })
      ),
      h("div", null,
        h("label", { className: "text-xs font-mono uppercase tracking-widest text-neutral-400 block mb-1" }, "Aspect ratio"),
        h("div", { className: "flex gap-2 flex-wrap" },
          ASPECTS.map(a => h("button", {
            key: a.id, onClick: () => setAspect(a.id),
            className: "px-3 py-1.5 rounded-lg text-xs font-mono border transition " +
              (aspect === a.id ? "bg-pink-500/20 border-pink-400/60 text-pink-200" : "border-white/10 text-neutral-400 hover:border-white/30")
          }, a.id))
        )
      )
    ),
    h("button", {
      onClick: generate, disabled: loading,
      className: "w-full py-3.5 rounded-xl font-extrabold text-black text-base pf-generate transition disabled:opacity-70",
    }, loading ? loadMsg : "⚡ Forge Image"),
    error && h("div", { className: "text-xs text-red-300 bg-red-500/10 border border-red-500/30 rounded-lg p-2" }, error)
  );

  // Result panel
  const resultPanel = h("div", { className: "relative" },
    loading
      ? h("div", { className: "pf-shimmer rounded-2xl aspect-square w-full flex items-center justify-center" },
          h("div", { className: "text-center" },
            h("div", { className: "pf-spinner mx-auto mb-3" }),
            h("div", { className: "text-sm text-neutral-300 font-mono" }, loadMsg)
          )
        )
      : result
        ? h("div", null,
            compare && source
              ? h("div", { className: "pf-compare rounded-2xl overflow-hidden relative select-none" },
                  h("img", { src: result.url, className: "w-full block" }),
                  h("div", { className: "pf-compare-overlay", style: { width: comparePos + "%" } },
                    h("img", { src: source, className: "pf-compare-img" })
                  ),
                  h("div", { className: "pf-compare-line", style: { left: comparePos + "%" } }),
                  h("input", {
                    type: "range", min: 0, max: 100, value: comparePos,
                    onChange: (e) => setComparePos(parseInt(e.target.value)),
                    className: "pf-compare-range"
                  })
                )
              : h("img", { src: result.url, className: "w-full rounded-2xl block pf-result-pop" }),
            h(Confetti, { fire: confettiKey }),
            h("div", { className: "flex flex-wrap gap-2 mt-3" },
              h("button", { onClick: () => download(result.url), className: "pf-btn" }, "⬇ Download"),
              h("button", { onClick: regen, className: "pf-btn" }, "🔄 Regenerate"),
              h("button", { onClick: () => useAsSource(result.url), className: "pf-btn" }, "↩ Use as source"),
              source && h("button", {
                onClick: () => setCompare(v => !v),
                className: "pf-btn " + (compare ? "pf-btn-on" : "")
              }, compare ? "✓ Comparing" : "⇆ Compare")
            ),
            h("div", { className: "mt-2 text-[11px] text-neutral-500 font-mono" },
              (MODELS.find(m => m.id === result.model) || {}).name + " · \"" + result.prompt + "\"")
          )
        : h("div", { className: "rounded-2xl aspect-square w-full flex items-center justify-center border border-dashed border-white/10 bg-white/[0.02]" },
            h("div", { className: "text-center px-6" },
              h("div", { className: "text-5xl mb-3 pf-float" }, activeModel.emoji),
              h("div", { className: "text-neutral-300 font-semibold" }, "Your forged image lands here"),
              h("div", { className: "text-xs text-neutral-600 mt-1" }, "Pick a model, describe the vibe, hit Forge.")
            )
          )
  );

  const gallery = history.length > 0 && h("div", { className: "mt-8" },
    h("div", { className: "flex items-center justify-between mb-3" },
      h("h2", { className: "text-sm font-mono uppercase tracking-widest text-neutral-400" }, "Forge History"),
      h("button", {
        onClick: () => { if (confirm("Clear all history?")) setHistory([]); },
        className: "text-[11px] text-neutral-600 hover:text-red-300"
      }, "clear all")
    ),
    h("div", { className: "grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2" },
      history.map(item => h("div", { key: item.id, className: "group relative rounded-lg overflow-hidden bg-black/40 aspect-square" },
        h("img", { src: item.url, className: "w-full h-full object-cover", loading: "lazy" }),
        h("div", { className: "absolute inset-0 bg-black/70 opacity-0 group-hover:opacity-100 transition flex flex-col items-center justify-center gap-1 p-1" },
          h("button", { onClick: () => download(item.url), className: "text-[10px] text-white bg-white/15 rounded px-2 py-0.5 hover:bg-white/30" }, "⬇"),
          h("button", { onClick: () => { setResult({ url: item.url, model: item.model, prompt: item.prompt }); window.scrollTo({top:0,behavior:'smooth'}); }, className: "text-[10px] text-white bg-white/15 rounded px-2 py-0.5 hover:bg-white/30" }, "view"),
          h("button", { onClick: () => useAsSource(item.url), className: "text-[10px] text-white bg-white/15 rounded px-2 py-0.5 hover:bg-white/30" }, "reuse")
        )
      ))
    )
  );

  // Sidebar content (reused for desktop + mobile drawer)
  const sidebar = h("div", { className: "space-y-5" },
    h("div", null,
      h("h3", { className: "text-xs font-mono uppercase tracking-widest text-neutral-500 mb-2" }, "Source"),
      uploadZone
    ),
    h("div", null,
      h("h3", { className: "text-xs font-mono uppercase tracking-widest text-neutral-500 mb-2" }, "Model"),
      modelPicker
    ),
    h("div", null, controls)
  );

  return h("div", { className: "min-h-screen text-neutral-100 pf-bg" },
    // Header
    h("header", { className: "relative px-4 sm:px-8 pt-6 pb-4 border-b border-white/5" },
      h("div", { className: "flex items-center justify-between max-w-6xl mx-auto" },
        h("div", null,
          h("h1", { className: "pf-title text-2xl sm:text-4xl" },
            "Pixel", h("span", { className: "pf-title-accent" }, "Forge")),
          h("p", { className: "text-xs sm:text-sm text-neutral-400 mt-0.5" },
            "Image-to-image with every model. Free. Unlimited",
            h("span", { className: "pf-star", title: "Unlimited* — *until the servers cry" }, "*"))
        ),
        h("div", { className: "text-right" },
          h("div", { className: "font-mono text-xs text-neutral-500" }, "generations left"),
          h("div", { className: "font-mono text-lg pf-infinity" }, "∞ / ∞"),
          h("div", { className: "text-[10px] text-neutral-600" }, "(you've made " + genCount + ")")
        )
      )
    ),

    // Mobile toggle
    h("div", { className: "lg:hidden px-4 pt-3" },
      h("button", {
        onClick: () => setDrawerOpen(v => !v),
        className: "w-full py-2.5 rounded-xl bg-white/5 border border-white/10 text-sm font-semibold"
      }, drawerOpen ? "▲ Hide controls" : "▼ Show controls & upload")
    ),

    // Main layout
    h("main", { className: "max-w-6xl mx-auto px-4 sm:px-8 py-5 grid lg:grid-cols-[minmax(320px,380px)_1fr] gap-6" },
      // Sidebar
      h("div", { className: (drawerOpen ? "block" : "hidden") + " lg:block" },
        h("div", { className: "pf-panel rounded-2xl p-4 sm:p-5" }, sidebar)
      ),
      // Result + gallery
      h("div", null,
        h("div", { className: "pf-panel rounded-2xl p-4 sm:p-5" }, resultPanel),
        gallery
      )
    ),

    // Footer
    h("footer", { className: "text-center text-xs text-neutral-600 py-8 px-4" },
      h("p", null, "PixelForge · Unlimited* forever *(terms: the forge occasionally naps)"),
      h("p", { className: "mt-2" },
        h("a", { href: "/remix", className: "pf-link font-semibold" }, "Remix on Berrry"))
    )
  );
};

ReactDOM.createRoot(document.getElementById("root")).render(h(App));