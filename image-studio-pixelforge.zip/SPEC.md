# AI Image Studio — "PixelForge Free"

Create a sleek, modern **image-to-image AI generation studio** where users can upload a reference image, choose from multiple AI models, tweak settings, and generate transformed images — all free and (playfully) "unlimited." This is a **React Web App** because it needs form controls, model selection, state management, image previews, and a gallery of results.

The tone should be fun and self-aware — the app knows "unlimited free forever" is a bold claim, so it leans into the joke with cheeky microcopy (e.g., "Unlimited* — *until the servers cry").

## App Type

**React Web App** — best fit for the interactive controls, dropdowns, sliders, image uploads, and a results gallery with persistent history.

## Core Functionality

- **Image-to-Image Transformation**: User uploads a source image (drag-and-drop or file picker, up to 10MB via file upload backend), enters a text prompt describing the desired transformation, picks a model, and generates a new image.
- **Multiple AI Models**: Present a model picker with several selectable "models" mapped to the available generation APIs:
  - **Nanobanana 2** (labeled "Photoreal / Editing" — Gemini-powered, great for realistic edits and composition)
  - **Pollinations** models (label variants like "GPT-Image", "Flux", "Turbo" — different aesthetic presets)
  - **RetroDiffusion** (labeled "Pixel Art / Sprite" — for 8-bit and game-asset style transforms)
  - Each model shown as a selectable card with a name, a short vibe description, and a tiny badge ("Free", "Fast", "HQ").
- **Prompt Input**: A large multi-line textarea for the transformation prompt, plus a smaller "negative prompt" field (optional, collapsible).
- **Controls Panel**: Sliders/toggles for common settings — Strength/Denoise (how much the AI deviates from source), aspect ratio selector, and a "surprise me" random prompt button.
- **Generate Button**: Big, satisfying primary button with a loading state showing a fun rotating status message ("Bribing the GPUs...", "Rearranging pixels...", "Consulting the color spirits...").
- **Results Gallery**: Generated images appear in a responsive grid. Each result shows the image, the model used, the prompt, and buttons to Download, Regenerate, and "Use as new source."
- **History / Persistence**: Save generation history to localStorage (and optionally to the backend data store with private visibility) so users see past creations when they return.
- **Comparison View**: Toggle to show source vs. result side-by-side with a slider divider for before/after comparison.

## UI Elements

### Header
A bold, gradient header with the app name **"PixelForge"** and a small strawberry (🍓) or spark icon. Tagline beneath: *"Image-to-image with every model. Free. Unlimited*."* — with the asterisk linking to a tooltip joke. Include a live counter badge like "∞ generations left" that never decreases.

### Left Sidebar / Control Panel
- **Upload Zone**: Large dashed-border drop area with an upload icon. Shows a thumbnail preview once an image is loaded, with a clear/remove button.
- **Model Selector**: Vertical stack (or horizontal scroll on mobile) of model cards, one highlighted as selected with an accent ring.
- **Prompt Section**: Textarea for prompt + collapsible advanced options (negative prompt, strength slider, aspect ratio).
- **Generate Button**: Full-width, glowing accent button.

### Main Content Area
- **Result Display**: Central area showing the latest generated image large, with action buttons (Download, Regenerate, Use as Source, Compare).
- **Before/After Comparison**: Optional slider overlay.
- **Gallery Grid**: Below the main result, a responsive grid (3–4 columns desktop, 1–2 mobile) of previous generations with hover actions.

### Footer
A minimal footer with the playful "unlimited" disclaimer, credits, and a `<a href="/remix">Remix on Berrry</a>` link.

## Styling Preferences

- **Dark mode aesthetic**: Deep charcoal/near-black background (`#0f0f14`) with vibrant gradient accents (purple → pink → orange, like a strawberry sunset).
- **Glassmorphism cards**: Semi-transparent panels with subtle blur and soft borders.
- **Rounded corners** (rounded-2xl), soft shadows, and smooth transitions/hover animations.
- **Tailwind CSS** utility classes throughout.
- **Fully responsive**: Sidebar collapses into a top drawer/accordion on mobile; gallery reflows to fewer columns.
- Clean sans-serif typography, generous spacing, and delightful micro-interactions (button press animations, loading shimmer on image placeholders).

## API Usage

- Route generation requests to **Nanobanana 2**, **Pollinations**, and **RetroDiffusion** APIs depending on the selected model, passing the source image and prompt for image-to-image transformation.
- Use **file upload** backend for source images; save results and history to the **data store** (private per user).
- Optional: a **public gallery** toggle where users can share generations to a community feed (using public data sharing).

## Additional Playful Features

- **"Surprise Me" button** that fills the prompt with a random creative transformation ("turn into a Renaissance oil painting", "make it cyberpunk neon", "as a claymation figure").
- **Fake usage meter** that always reads "∞ / ∞" as a running gag.
- **Rotating loading messages** for personality during generation.
- **Confetti or sparkle burst** animation when a generation completes.

Keep it a single-page, immediately interactive experience — upload, pick a model, type, generate, admire, repeat.