/* Z-Image Studio — free unlimited img2img via Stable Horde anonymous (no keys) */
(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const HORDE = "https://stablehorde.net/api/v2";
  const ANON_KEY = "0000000000";
  const CLIENT_AGENT = "z-image-studio:1.0:perchance";
  const LS_HIST = "zimage-studio-history-v1";

  const els = {};
  ["dropZone","dropInner","fileInput","urlBtn","sampleBtn","clearImgBtn",
   "promptInput","negInput","presetChips","modelSearch","modelSelect","pinZBtn","modelInfo",
   "strengthRange","strengthVal","strengthRow","widthSelect","heightSelect",
   "stepsRange","stepsVal","cfgRange","cfgVal","samplerSelect","schedulerSelect",
   "seedInput","countSelect","upscaleCheck","genBtn","cancelBtn","retryBtn",
   "progBar","log","resultWrap","resultPh","resultImg","dlBtn","openBtn",
   "useAsInputBtn","compareBtn","resultMeta","compareWrap","histGrid","clearHistBtn","workerPill"
  ].forEach((id) => (els[id] = $(id)));

  const state = {
    models: [],
    sourceDataUrl: null, // full res preview
    sourceWebpB64: null, // resized webp base64 (no prefix) for horde
    lastJobId: null,
    cancelled: false,
    polling: false,
    lastResult: null, // {url, seed, model, prompt}
    lastSeedUsed: null,
  };

  const PRESETS = [
    ["Cinematic", "cinematic photo, ultra detailed, soft studio light, 85mm"],
    ["Anime", "anime style, vibrant, clean lineart, detailed face"],
    ["Ghibli", "ghibli style background, painterly, soft light"],
    ["Cyberpunk", "cyberpunk city, neon rain, cinematic"],
    ["Portrait", "close-up portrait, sharp focus, bokeh, natural skin"],
    ["Product", "studio product shot, softbox, minimal background"],
    ["Fantasy", "epic fantasy art, intricate details, dramatic light"],
    ["Pixel", "pixel art, 16-bit, crisp"],
  ];

  const SAMPLES = [
    "https://picsum.photos/seed/zimage-mountain/768/768",
    "https://picsum.photos/seed/zimage-portrait/768/768",
  ];

  function log(msg, cls) {
    els.log.innerHTML = "";
    const s = document.createElement("span");
    if (cls) s.className = cls;
    s.textContent = msg;
    els.log.appendChild(s);
  }
  function logAppend(msg) {
    els.log.textContent += "\n" + msg;
    els.log.scrollTop = els.log.scrollHeight;
  }
  function setProgress(frac) {
    els.progBar.style.width = Math.max(0, Math.min(100, frac * 100)) + "%";
  }

  // ---------- presets ----------
  PRESETS.forEach(([name, text]) => {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "chip";
    b.textContent = name;
    b.onclick = () => {
      els.promptInput.value = text;
    };
    els.presetChips.appendChild(b);
  });

  // ---------- source image handling ----------
  function showSourcePreview(dataUrl) {
    els.dropInner.innerHTML = "";
    const img = document.createElement("img");
    img.src = dataUrl;
    img.alt = "source";
    els.dropInner.appendChild(img);
    const cap = document.createElement("div");
    cap.className = "hint";
    cap.innerHTML = "✓ photo loaded — <b style='color:#fff'>image→image mode</b><br><span style='font-size:12px'>lower strength = keep photo · higher = more AI</span>";
    els.dropInner.appendChild(cap);
  }
  function clearSource() {
    state.sourceDataUrl = null;
    state.sourceWebpB64 = null;
    els.dropInner.innerHTML = '<div style="font-size:34px">🖼️</div><div class="hint"><b style="color:#fff">Drop / paste / click</b> to add a photo<br>no image = pure text→image<br>with image = image→image edit</div>';
    els.compareBtn.disabled = true;
    els.compareWrap.classList.add("hidden");
    els.compareWrap.innerHTML = "";
  }

  function fileToDataUrl(file) {
    return new Promise((res, rej) => {
      const r = new FileReader();
      r.onload = () => res(r.result);
      r.onerror = rej;
      r.readAsDataURL(file);
    });
  }

  async function imageToWebpB64(dataUrl, maxSide) {
    maxSide = maxSide || 896;
    const img = new Image();
    img.src = dataUrl;
    await new Promise((res, rej) => {
      if (img.complete && img.naturalWidth) res();
      else {
        img.onload = () => res();
        img.onerror = () => rej(new Error("could not decode image"));
        setTimeout(() => rej(new Error("image decode timeout")), 20000);
      }
    });
    let w = img.naturalWidth, h = img.naturalHeight;
    const s = Math.min(1, maxSide / Math.max(w, h));
    w = Math.max(64, Math.round((w * s) / 64) * 64);
    h = Math.max(64, Math.round((h * s) / 64) * 64);
    const c = document.createElement("canvas");
    c.width = w; c.height = h;
    const ctx = c.getContext("2d");
    ctx.drawImage(img, 0, 0, w, h);
    const webp = c.toDataURL("image/webp", 0.9);
    // horde wants raw base64 (no data: prefix)
    return { b64: webp.split(",")[1], w, h };
  }

  async function setSourceFromDataUrl(dataUrl) {
    state.sourceDataUrl = dataUrl;
    showSourcePreview(dataUrl);
    try {
      const { b64 } = await imageToWebpB64(dataUrl, 896);
      state.sourceWebpB64 = b64;
    } catch (e) {
      log("Could not read that image. Try another file.", "err");
      clearSource();
    }
    els.compareBtn.disabled = !state.lastResult;
  }

  els.dropZone.addEventListener("click", () => els.fileInput.click());
  els.fileInput.addEventListener("change", async (e) => {
    const f = e.target.files && e.target.files[0];
    if (!f) return;
    setProgress(0.05);
    log("Reading photo…");
    try {
      const du = await fileToDataUrl(f);
      await setSourceFromDataUrl(du);
      log("Photo ready — image→image mode. Write what to change, hit Generate.");
      setProgress(0);
    } catch (err) {
      log("Could not read file: " + err.message, "err");
    }
    els.fileInput.value = "";
  });
  ["dragover", "dragenter"].forEach((ev) =>
    els.dropZone.addEventListener(ev, (e) => {
      e.preventDefault();
      els.dropZone.classList.add("dragover");
    })
  );
  ["dragleave", "drop"].forEach((ev) =>
    els.dropZone.addEventListener(ev, (e) => {
      e.preventDefault();
      els.dropZone.classList.remove("dragover");
    })
  );
  els.dropZone.addEventListener("drop", async (e) => {
    const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
    if (!f) return;
    try {
      const du = await fileToDataUrl(f);
      await setSourceFromDataUrl(du);
      log("Photo ready — image→image mode.");
    } catch (err) {
      log("Drop failed: " + err.message, "err");
    }
  });
  document.addEventListener("paste", async (e) => {
    const items = (e.clipboardData && e.clipboardData.items) || [];
    for (const it of items) {
      if (it.type && it.type.indexOf("image") === 0) {
        const f = it.getAsFile();
        if (f) {
          e.preventDefault();
          const du = await fileToDataUrl(f);
          await setSourceFromDataUrl(du);
          log("Pasted photo ready — image→image mode.");
          return;
        }
      }
    }
  });
  els.urlBtn.addEventListener("click", async () => {
    const u = prompt("Paste an image URL (https://…):", "https://");
    if (!u) return;
    log("Fetching URL… (page fetches it directly; hotlink-blocked hosts may fail)");
    try {
      const r = await fetch(u);
      if (!r.ok) throw new Error("HTTP " + r.status);
      const blob = await r.blob();
      if (!blob.type.startsWith("image/")) throw new Error("not an image (" + blob.type + ")");
      const du = await new Promise((res, rej) => {
        const fr = new FileReader();
        fr.onload = () => res(fr.result);
        fr.onerror = rej;
        fr.readAsDataURL(blob);
      });
      await setSourceFromDataUrl(du);
      log("URL photo ready.");
    } catch (err) {
      log("URL load failed (CORS/hotlink). Download the file and drop it instead: " + err.message, "err");
    }
  });
  let sampleIdx = 0;
  els.sampleBtn.addEventListener("click", async () => {
    log("Loading sample…");
    try {
      const url = SAMPLES[sampleIdx % SAMPLES.length] + ((SAMPLES[sampleIdx % SAMPLES.length].includes("?") ? "&" : "?") + "t=" + Date.now());
      sampleIdx++;
      const r = await fetch(url);
      const blob = await r.blob();
      const du = await new Promise((res, rej) => {
        const fr = new FileReader();
        fr.onload = () => res(fr.result);
        fr.onerror = rej;
        fr.readAsDataURL(blob);
      });
      await setSourceFromDataUrl(du);
      els.promptInput.value = "same mountain landscape at sunset, dramatic clouds, cinematic";
      log("Sample loaded. Hit Generate.");
    } catch (err) {
      log("Sample failed: " + err.message, "err");
    }
  });
  els.clearImgBtn.addEventListener("click", () => {
    clearSource();
    log("Cleared — back to text→image mode.");
  });

  // ---------- models ----------
  function modelPasses(m, q) {
    q = (q || "").toLowerCase().trim();
    if (!q) return true;
    return m.name.toLowerCase().includes(q);
  }

  function fillModels(filter) {
    const sel = els.modelSelect;
    const cur = sel.value;
    sel.innerHTML = "";
    const list = state.models
      .filter((m) => modelPasses(m, filter))
      .sort((a, b) => {
        // Z-Image-Turbo always first
        if (a.name === "Z-Image-Turbo") return -1;
        if (b.name === "Z-Image-Turbo") return 1;
        return a.eta - b.eta;
      })
      .slice(0, 200);
    if (!list.length) {
      const o = document.createElement("option");
      o.textContent = "no match";
      sel.appendChild(o);
      return;
    }
    list.forEach((m) => {
      const o = document.createElement("option");
      o.value = m.name;
      const fast = m.eta <= 5 ? ", fast" : "";
      o.textContent = (m.name === "Z-Image-Turbo" ? ">>> " : "") + m.name + " — " + m.count + " workers, ~" + m.eta + "s" + fast;
      sel.appendChild(o);
    });
    if (cur && [...sel.options].some((o) => o.value === cur)) sel.value = cur;
    else if ([...sel.options].some((o) => o.value === "Z-Image-Turbo")) sel.value = "Z-Image-Turbo";
    updateModelInfo();
  }

  function updateModelInfo() {
    const name = els.modelSelect.value;
    const m = state.models.find((x) => x.name === name);
    if (!m) {
      els.modelInfo.textContent = "";
      return;
    }
    els.modelInfo.innerHTML = "";
    const eta = m.eta == null ? "?" : m.eta + "s";
    els.modelInfo.textContent = name + " — " + m.count + " workers · queue ~" + eta + (m.eta <= 5 ? " · fast" : "") + (name === "Z-Image-Turbo" ? " · bilingual text, photoreal" : "");
    // auto-tune Z-Image-Turbo defaults
    if (name === "Z-Image-Turbo") {
      els.stepsRange.value = 9; els.stepsVal.textContent = "9";
      els.cfgRange.value = 1; els.cfgVal.textContent = "1.0";
      els.samplerSelect.value = "k_euler";
      els.schedulerSelect.value = "simple";
    }
  }

  async function loadModels() {
    try {
      const r = await fetch(HORDE + "/status/models", { headers: { "Client-Agent": CLIENT_AGENT } });
      if (!r.ok) throw new Error("HTTP " + r.status);
      const arr = await r.json();
      state.models = arr.map((m) => ({ name: m.name, count: m.count || 0, eta: m.eta || 0, queued: m.queued || 0 })).sort((a, b) => a.name.localeCompare(b.name));
      const totalWorkers = arr.reduce((s, m) => s + (m.count || 0), 0);
      els.workerPill.innerHTML = "<b>" + totalWorkers + "</b>&nbsp;workers online";
      fillModels("");
      log("Models loaded (" + state.models.length + "). Z-Image-Turbo selected. Free, no keys — volunteers' GPUs.");
    } catch (e) {
      // fallback minimal list so the app still works offline-ish
      state.models = [
        { name: "Z-Image-Turbo", count: 6, eta: 90, queued: 0 },
        { name: "Stable Diffusion XL Lightning", count: 1, eta: 5, queued: 0 },
      ];
      els.workerPill.textContent = "workers ?";
      fillModels("");
      log("Model list fetch failed (" + e.message + ") — using fallback. Check connection and reload.", "err");
    }
  }

  els.modelSearch.addEventListener("input", () => fillModels(els.modelSearch.value));
  els.modelSelect.addEventListener("change", updateModelInfo);
  els.pinZBtn.addEventListener("click", () => {
    els.modelSearch.value = "";
    fillModels("");
    els.modelSelect.value = "Z-Image-Turbo";
    updateModelInfo();
    els.modelSelect.focus();
  });

  // ---------- sliders ----------
  els.strengthRange.addEventListener("input", () => (els.strengthVal.textContent = Number(els.strengthRange.value).toFixed(2)));
  els.stepsRange.addEventListener("input", () => (els.stepsVal.textContent = els.stepsRange.value));
  els.cfgRange.addEventListener("input", () => (els.cfgVal.textContent = Number(els.cfgRange.value).toFixed(1)));

  // ---------- horde client ----------
  async function hordePost(path, body) {
    const r = await fetch(HORDE + path, {
      method: "POST",
      headers: { "Content-Type": "application/json", apikey: ANON_KEY, "Client-Agent": CLIENT_AGENT },
      body: JSON.stringify(body),
    });
    const txt = await r.text();
    if (!r.ok) throw new Error("Horde " + r.status + ": " + txt.slice(0, 300));
    return JSON.parse(txt);
  }
  async function hordeGet(path) {
    const r = await fetch(HORDE + path, { headers: { "Client-Agent": CLIENT_AGENT, apikey: ANON_KEY } });
    if (!r.ok) throw new Error("Horde " + r.status);
    return r.json();
  }

  const sleep = (ms) => new Promise((res) => setTimeout(res, ms));

  async function generate(isRetry) {
    const promptRaw = els.promptInput.value.trim();
    if (!promptRaw) {
      log("Write a prompt first.", "err");
      els.promptInput.focus();
      return;
    }
    const model = els.modelSelect.value;
    if (!model || model === "no match") {
      log("Pick a model first.", "err");
      return;
    }
    const neg = els.negInput.value.trim();
    const prompt = neg ? promptRaw + " ### " + neg : promptRaw;
    const hasImg = !!state.sourceWebpB64;
    const w = parseInt(els.widthSelect.value, 10);
    const h = parseInt(els.heightSelect.value, 10);
    const steps = parseInt(els.stepsRange.value, 10);
    const cfg = parseFloat(els.cfgRange.value);
    const n = parseInt(els.countSelect.value, 10) || 1;
    let seed = els.seedInput.value.trim();
    if (isRetry && state.lastSeedUsed) seed = String(state.lastSeedUsed);
    if (seed === "-1" || seed === "") seed = undefined;

    const params = {
      sampler_name: els.samplerSelect.value,
      scheduler: els.schedulerSelect.value,
      steps, cfg_scale: cfg, width: w, height: h, n,
    };
    if (seed !== undefined) params.seed = String(seed);
    if (hasImg) params.denoising_strength = parseFloat(els.strengthRange.value);
    if (els.upscaleCheck.checked) {
      params.post_processing = ["RealESRGAN_x4plus"];
      params.hires_fix = false;
    }

    const body = {
      prompt, params,
      nsfw: false, trusted_workers: false, slow_workers: true,
      censor_nsfw: true, models: [model], r2: true, shared: true,
    };
    if (hasImg) {
      body.source_image = state.sourceWebpB64;
      body.source_processing = "img2img";
    }

    state.cancelled = false;
    state.polling = true;
    els.genBtn.disabled = true;
    els.cancelBtn.disabled = false;
    els.dlBtn.disabled = true;
    els.openBtn.disabled = true;
    els.useAsInputBtn.disabled = true;
    setProgress(0.03);
    log((hasImg ? "Image→image" : "Text→image") + " → " + model + " …\nQueueing on volunteer GPUs (free, no key)…");

    let id;
    try {
      const sub = await hordePost("/generate/async", body);
      id = sub.id;
      state.lastJobId = id;
      if (!id) throw new Error("no job id: " + JSON.stringify(sub).slice(0, 300));
    } catch (e) {
      log("Submit failed: " + e.message + "\nTip: try a smaller size or another model.", "err");
      resetButtons();
      return;
    }

    const t0 = Date.now();
    try {
      for (;;) {
        if (state.cancelled) {
          log("Cancelled.");
          break;
        }
        await sleep(2600);
        let chk;
        try {
          chk = await hordeGet("/generate/check/" + id);
        } catch (e) {
          logAppend("(status retry…)");
          continue;
        }
        if (chk.finished) break;
        const qp = chk.queue_position != null ? "#" + chk.queue_position : "?";
        const wt = chk.wait_time != null ? " ~" + chk.wait_time + "s" : "";
        const proc = chk.processing || 0, wait = chk.waiting || 0;
        const elapsed = Math.round((Date.now() - t0) / 1000);
        // progress heuristic
        const frac = chk.queue_position != null ? Math.min(0.9, 0.08 + elapsed / Math.max(20, (chk.wait_time || 60) + 15)) : 0.15;
        setProgress(frac);
        els.log.textContent = (hasImg ? "Image→image" : "Text→image") + " → " + model + "\nQueued " + qp + wt + " · processing " + proc + " · waiting " + wait + " · " + elapsed + "s elapsed…\n(free queue — keep this tab open; try a low-ETA model if slow)";
      }
      if (state.cancelled) {
        resetButtons();
        return;
      }
      setProgress(0.95);
      logAppend("Finished — downloading…");
      const st = await hordeGet("/generate/status/" + id);
      const gens = (st && st.generations) || [];
      if (!gens.length) {
        log("Worker returned nothing (it may have been censored or failed). Try again or switch model.", "err");
        resetButtons();
        return;
      }
      setProgress(1);
      // show first, stash rest in history
      for (const g of gens) {
        addHistory({ url: g.img, seed: g.seed, model: g.model || model, prompt: promptRaw });
      }
      showResult(gens[0], model, promptRaw, hasImg);
      log("Done ✓ " + gens.length + " image(s) from " + model + ". Free via Stable Horde — no keys used.", "ok");
    } catch (e) {
      log("Generation failed: " + e.message, "err");
    }
    resetButtons();
  }

  function resetButtons() {
    state.polling = false;
    els.genBtn.disabled = false;
    els.cancelBtn.disabled = true;
  }

  function showResult(g, model, promptRaw, hadSource) {
    const url = g.img;
    const seed = g.seed;
    state.lastResult = { url, seed, model: g.model || model, prompt: promptRaw };
    state.lastSeedUsed = seed;
    els.resultPh.classList.add("hidden");
    els.resultImg.classList.remove("hidden");
    els.resultImg.src = url;
    els.dlBtn.disabled = false;
    els.openBtn.disabled = false;
    els.useAsInputBtn.disabled = false;
    els.compareBtn.disabled = !state.sourceDataUrl;
    els.resultMeta.innerHTML = "";
    els.resultMeta.textContent = "model " + (g.model || model) + " · seed " + seed + " · " + (hadSource ? "img2img" : "txt2img") + " · worker " + (g.worker_name || g.worker_id || "?");
    els.compareWrap.classList.add("hidden");
    els.compareWrap.innerHTML = "";
  }

  // ---------- buttons ----------
  els.genBtn.addEventListener("click", () => generate(false));
  els.retryBtn.addEventListener("click", () => generate(true));
  els.cancelBtn.addEventListener("click", () => {
    state.cancelled = true;
    els.cancelBtn.disabled = true;
    logAppend("Cancelling…");
  });

  els.dlBtn.addEventListener("click", async () => {
    if (!state.lastResult) return;
    try {
      logAppend("Downloading…");
      const r = await fetch(state.lastResult.url);
      const b = await r.blob();
      const u = URL.createObjectURL(b);
      const a = document.createElement("a");
      a.href = u;
      a.download = "zimage-" + (state.lastResult.seed || Date.now()) + ".webp";
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(u), 8000);
    } catch (e) {
      window.open(state.lastResult.url, "_blank");
    }
  });
  els.openBtn.addEventListener("click", () => {
    if (state.lastResult) window.open(state.lastResult.url, "_blank");
  });
  els.useAsInputBtn.addEventListener("click", async () => {
    if (!state.lastResult) return;
    log("Loading result as new input…");
    try {
      const r = await fetch(state.lastResult.url);
      const blob = await r.blob();
      const du = await new Promise((res, rej) => {
        const fr = new FileReader();
        fr.onload = () => res(fr.result);
        fr.onerror = rej;
        fr.readAsDataURL(blob);
      });
      await setSourceFromDataUrl(du);
      log("Result is now the input — lower strength to iterate gently.");
    } catch (e) {
      log("Reuse failed: " + e.message, "err");
    }
  });
  els.compareBtn.addEventListener("click", () => {
    if (!state.lastResult || !state.sourceDataUrl) return;
    const w = els.compareWrap;
    if (!w.classList.contains("hidden")) {
      w.classList.add("hidden");
      w.innerHTML = "";
      return;
    }
    w.classList.remove("hidden");
    w.innerHTML = "";
    const box = document.createElement("div");
    box.className = "compare";
    box.style.cssText = "border:1px solid var(--line);border-radius:12px";
    const before = document.createElement("img");
    before.src = state.sourceDataUrl;
    before.style.cssText = "width:100%;display:block";
    const afterWrap = document.createElement("div");
    afterWrap.className = "after";
    afterWrap.style.width = "50%";
    const after = document.createElement("img");
    after.src = state.lastResult.url;
    after.style.cssText = "width:100%;height:100%;object-fit:contain;display:block";
    // match heights: use fixed aspect from result
    afterWrap.appendChild(after);
    const bar = document.createElement("div");
    bar.className = "bar";
    bar.style.left = "50%";
    const slider = document.createElement("input");
    slider.type = "range";
    slider.min = "0"; slider.max = "100"; slider.value = "50";
    slider.addEventListener("input", () => {
      afterWrap.style.width = slider.value + "%";
      bar.style.left = slider.value + "%";
    });
    const cap = document.createElement("div");
    cap.style.cssText = "font-size:12px;color:var(--mut);margin-top:6px";
    cap.textContent = "← source  ·  result →  (drag to compare)";
    box.appendChild(before);
    box.appendChild(afterWrap);
    box.appendChild(bar);
    box.appendChild(slider);
    w.appendChild(box);
    w.appendChild(cap);
  });

  // ---------- history ----------
  function getHist() {
    try {
      return JSON.parse(localStorage.getItem(LS_HIST) || "[]");
    } catch {
      return [];
    }
  }
  function saveHist(h) {
    try {
      localStorage.setItem(LS_HIST, JSON.stringify(h.slice(0, 40)));
    } catch {}
  }
  function renderHist() {
    const h = getHist();
    els.histGrid.innerHTML = "";
    h.forEach((it) => {
      const im = document.createElement("img");
      im.src = it.url;
      im.loading = "lazy";
      im.title = (it.model || "") + " · " + (it.prompt || "").slice(0, 80);
      im.addEventListener("click", () => {
        state.lastResult = it;
        state.lastSeedUsed = it.seed;
        els.resultPh.classList.add("hidden");
        els.resultImg.classList.remove("hidden");
        els.resultImg.src = it.url;
        els.dlBtn.disabled = false;
        els.openBtn.disabled = false;
        els.useAsInputBtn.disabled = false;
        els.compareBtn.disabled = !state.sourceDataUrl;
        els.resultMeta.textContent = "model " + it.model + " · seed " + it.seed + " · " + (it.prompt || "");
        log("Loaded from history.");
      });
      els.histGrid.appendChild(im);
    });
  }
  function addHistory(it) {
    const h = getHist();
    h.unshift(it);
    saveHist(h);
    renderHist();
  }
  els.clearHistBtn.addEventListener("click", () => {
    saveHist([]);
    renderHist();
  });

  // ---------- init ----------
  renderHist();
  loadModels();
})();
