# Z-Image Studio

Image → Z-Image (and text → image). All models free, unlimited, no API keys.

## What it is
A single-page studio: upload a photo (or not), write a prompt, pick from ~179 free
AI image models (default **Z-Image-Turbo**), hit Generate. No signup, no keys.

## How "free, no keys" works
All generation goes to **Stable Horde** (`stablehorde.net`) with the public anonymous
key `0000000000` — volunteers share GPUs, you wait in a fair queue (typically 10–120s).
That means: free, unlimited, no API keys. Text→image needs no photo; image→image sends
your photo as a small WebP starter plus a denoise-strength slider.

- Z-Image-Turbo auto-defaults: `steps 9 · cfg 1 · sampler k_euler · scheduler simple`
- Prompt format: `positive ### negative` (negative joined automatically)
- `r2:true` download links, history in `localStorage`, compare slider, reuse-as-input

## Files
- `main.pjs` — generator meta only (no plugins, so no ads/key prompts)
- `index.html` — UI
- `src/app.js` — Horde client + UI logic (vanilla JS, no deps)

## Tested
- 179 models load, Z-Image-Turbo default ✓
- txt2img (fast model) ~55s ✓ · img2img ~15s ✓ · Z-Image-Turbo 512px ~155s ✓
- Photo upload via drop/paste/click/URL/sample ✓ · mobile + desktop layouts ✓
