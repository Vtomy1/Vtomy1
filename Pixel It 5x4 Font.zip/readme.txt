The font file in this archive and its variations were created by Maria Beatrice Barberis (Beatrice Barberis) using Fontstruct the free, online font-building tool found at https://fontstruct.com; Fontstruct is copyright ©2026 Rob Meek.

The font file in this archive and its variations are a copyright of Domus Vestae LLC, doing business as Now In Time; find all our creations at http://nowintime.net. Find the original download page at https://nowintime.net/product/smallboy-font/

The FontStructions “Pixel It! 5x4” (https://fontstruct.com/fontstructions/show/2667618), “Pixel It! 5x5” (https://fontstruct.com/fontstructions/show/2977253) and “Pixel It! 7x5” (https://fontstruct.com/fontstructions/show/2919656) by Maria Beatrice Barberis for Now In Time are licensed under a Creative Commons Attribution Non-commercial No Derivatives license (http://creativecommons.org/licenses/by-nc-nd/3.0/).
In using this font you must comply with the licensing terms described here.
If you redistribute the font file in this archive, it must be accompanied by all
the other files from this archive, including this one.