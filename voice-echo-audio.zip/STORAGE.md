# Storage Design - Voice Echo

## Data Requirements
- **Local Storage only**: Recent "echoes" history (transcript snippet, voice used, timestamp)
- No backend required — everything is client-side and ephemeral audio

## Storage Strategy
### Local-only
- `voiceEcho.history` — array of last 10 echoes
- `voiceEcho.settings` — { voice, model, sttModel }

### Data Structures
```json
// localStorage: voiceEcho.history
[
  { "id": "1690000000", "text": "hello world", "voiceId": "nova", "voiceName": "😎 Smooth Sam", "createdAt": "2026-09-21T12:00:00Z" }
]

// localStorage: voiceEcho.settings
{ "voice": "nova", "model": "openai-audio", "sttModel": "openai-audio" }
```

## Implementation Notes
- Transcription: POST base64 audio to Pollinations `openai-audio` model
- TTS: GET `text.pollinations.ai/{text}?model=openai-audio&voice={voice}`
- Fallback: browser SpeechSynthesis if TTS fetch fails
- History persists across reloads; generated audio blobs are not persisted (only text + voice)