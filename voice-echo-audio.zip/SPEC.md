# Voice Echo — Audio → Text → Custom Speech

Create a playful, single-page web app that takes an audio recording (or uploaded audio file), transcribes it into editable text, and then reads that text back in a **custom AI-generated voice** the user picks. Think of it as a tiny "voice remix studio" — record yourself rambling, watch the words appear, tweak them, and hear a completely different voice speak your thoughts.

This is best built as a **React Web App** because it involves multi-step state management (recording → transcription → editing → speech synthesis), form controls, audio playback, and a clean interactive UI.

## Core Concept & Flow

The app has three clear stages, presented as a vertical pipeline the user moves through:

1. **🎙️ Capture** — Record from the microphone (using the browser MediaRecorder API) OR drag-and-drop / upload an audio file (mp3, wav, m4a, up to 10MB).
2. **📝 Transcribe** — Send the captured audio to the **Pollinations API** for speech-to-text transcription. Display the result in a large, editable text area so users can fix mistakes or rewrite entirely.
3. **🔊 Speak** — Send the (possibly edited) text back to the **Pollinations audio generation API** using a user-selected voice, then play the resulting synthesized audio with a nice waveform-style player.

## UI Elements

### Header
A bold, fun header with the app name **"Voice Echo 🎙️→📝→🔊"** centered at the top. Include a short one-line tagline underneath like *"Speak it. Read it. Hear it in someone else's voice."* Use a gradient background (deep purple → indigo → pink) with white text and a subtle glow.

### Stage 1 — Capture Card
- A prominent **microphone record button** — a large circular button that pulses red and shows a live timer while recording.
- An **animated audio-level meter** (simple bars reacting to input volume) so users get visual feedback that the mic is working.
- A separate **drag-and-drop upload zone** with a dashed border ("or drop an audio file here").
- After capture, show a small inline **playback preview** of the recorded/uploaded audio with a play/pause button and duration.
- A "Re-record" / "Clear" link to start over.

### Stage 2 — Transcribe Card
- A **"Transcribe Audio" button** that triggers the Pollinations speech-to-text call. Show a friendly loading state ("Listening carefully... 👂") with an animated spinner.
- A large, resizable **editable textarea** displaying the transcript, with a live character/word count below it.
- Small utility buttons: **Copy text**, **Clear**, and **Undo edits**.
- If transcription fails, show a gentle error toast with a retry option.

### Stage 3 — Speak Card
- A **voice selector** — a grid of selectable voice "chips/cards", each showing an emoji avatar and a fun name (e.g. "😎 Smooth Sam", "🤖 Robo-Rita", "🎩 Fancy Fred", "🌊 Calm Cara", "🔥 Hype Hank"). Each maps to one of the Pollinations voice options. The selected voice highlights with a glowing border.
- A **"Generate Speech" button** (big, gradient, satisfying to press) that sends the edited text + chosen voice to the Pollinations audio API.
- A custom **audio player** for the result: play/pause, a scrubber/progress bar, a stylized waveform or bouncing-bars animation while playing, and a **Download** button to save the generated audio.
- A subtle **speed / pitch** control slider if supported (otherwise omit gracefully).

### Progress Indicator
A horizontal stepper at the top of the main content showing the three stages (Capture → Transcribe → Speak) with checkmarks as each is completed, so the user always knows where they are.

### History Panel (optional persistence)
Using **localStorage** (and optionally the backend data storage for logged-in users), keep a short list of recent "echoes" — each entry shows a snippet of the transcript, the voice used, and a replay button. Include a "Clear history" option.

### Footer
A minimal footer with a fun line ("Made with mumbles and math 🍓") and the required link: `<a href="/remix">Remix on Berrry</a>`.

## Styling Preferences
- Modern, playful, slightly "studio/synth" aesthetic — dark mode by default with neon accent gradients (purple/pink/cyan).
- Use **Tailwind CSS** utility classes for all styling.
- Rounded cards with soft shadows and subtle glassmorphism (semi-transparent panels with backdrop blur).
- Smooth transitions and micro-animations on buttons, the record pulse, loading states, and stage transitions.
- Fully **responsive**: three stacked cards on mobile, comfortable single-column flow on desktop with generous spacing. Font sizes and the voice-chip grid should adapt (2 columns on mobile, 5 on desktop).

## Functionality
- **Recording**: Use MediaRecorder + Web Audio API for the live level meter. Handle permission-denied gracefully with a friendly message.
- **File upload**: Accept common audio formats, validate size/type, show preview.
- **Transcription**: POST audio to the Pollinations API, parse and display returned text.
- **Editable transcript**: Fully editable before synthesis; word count updates live.
- **Custom voice TTS**: Map each fun voice card to a Pollinations voice parameter and generate speech from the edited text.
- **Playback & download**: Custom player with waveform animation; allow downloading the generated audio file.
- **Persistence**: Save recent echoes to localStorage; optionally sync to backend storage when the user is logged in, and allow sharing a generated clip publicly.
- **Error handling**: Toast notifications for mic errors, transcription failures, and TTS failures, each with a retry path.
- **Delightful touches**: Confetti or a little sound cue when speech generation completes; the app title emoji animates through the pipeline stages.

## Additional Notes
- Keep everything client-side and self-contained in a single page — no multi-page navigation.
- Prioritize a fast, satisfying "record → hear a new voice" loop that works end-to-end in under a minute.
- If any API step is unavailable, degrade gracefully (e.g., fall back to the browser's built-in `SpeechSynthesis` voices for the "custom voice" step so the app always produces audible output).