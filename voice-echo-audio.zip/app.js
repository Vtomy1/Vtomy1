const { useState, useEffect, useRef, useCallback } = React;
const h = React.createElement;

// ---- Voice roster: fun names mapped to Pollinations openai-audio voices ----
const VOICES = [
  { id: 'nova',    emoji: '😎', name: 'Smooth Sam',   desc: 'chill & confident' },
  { id: 'shimmer', emoji: '🌊', name: 'Calm Cara',    desc: 'soft & soothing' },
  { id: 'echo',    emoji: '🎩', name: 'Fancy Fred',   desc: 'polished narrator' },
  { id: 'fable',   emoji: '📖', name: 'Story Stella', desc: 'warm storyteller' },
  { id: 'onyx',    emoji: '🔥', name: 'Hype Hank',    desc: 'deep & bold' },
  { id: 'alloy',   emoji: '🤖', name: 'Robo-Rita',    desc: 'neutral & crisp' },
];

const LS_HISTORY = 'voiceEcho.history';
const LS_SETTINGS = 'voiceEcho.settings';

function load(key, fallback) {
  try { return JSON.parse(localStorage.getItem(key)) || fallback; }
  catch { return fallback; }
}
function save(key, data) { localStorage.setItem(key, JSON.stringify(data)); }

// Convert a Blob to base64 (without data: prefix)
function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result.split(',')[1]);
    r.onerror = reject;
    r.readAsDataURL(blob);
  });
}

// ---------------- Toast ----------------
function Toast({ toast, onClose }) {
  if (!toast) return null;
  const colors = {
    error: 'bg-red-500/90 border-red-300',
    info: 'bg-indigo-500/90 border-indigo-300',
    success: 'bg-emerald-500/90 border-emerald-300',
  };
  return h('div', {
    className: `fixed top-4 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-xl border text-white shadow-2xl backdrop-blur ve-pop ${colors[toast.type] || colors.info}`
  },
    h('div', { className: 'flex items-center gap-3' },
      h('span', { className: 'text-sm font-semibold' }, toast.msg),
      h('button', { onClick: onClose, className: 'opacity-70 hover:opacity-100' }, '✕')
    )
  );
}

// ---------------- Stepper ----------------
function Stepper({ stage }) {
  const steps = [
    { key: 'capture', label: 'Capture', icon: '🎙️' },
    { key: 'transcribe', label: 'Transcribe', icon: '📝' },
    { key: 'speak', label: 'Speak', icon: '🔊' },
  ];
  const order = { capture: 0, transcribe: 1, speak: 2 };
  const cur = order[stage] ?? 0;
  return h('div', { className: 'flex items-center justify-center gap-2 sm:gap-4 my-6' },
    steps.map((s, i) => h(React.Fragment, { key: s.key },
      h('div', { className: 'flex flex-col items-center' },
        h('div', {
          className: `w-11 h-11 rounded-full flex items-center justify-center text-lg border-2 transition-all duration-300 ${i <= cur ? 've-step-active border-fuchsia-400' : 'border-white/15 bg-white/5'}`
        }, i < cur ? '✓' : s.icon),
        h('span', { className: `mt-1 text-[11px] tracking-wide uppercase ${i <= cur ? 'text-fuchsia-200' : 'text-white/40'}` }, s.label)
      ),
      i < steps.length - 1 && h('div', {
        className: `h-0.5 w-8 sm:w-16 rounded ${i < cur ? 'bg-fuchsia-400' : 'bg-white/15'}`
      })
    ))
  );
}

// ---------------- Level meter bars ----------------
function LevelMeter({ level }) {
  const bars = 20;
  return h('div', { className: 'flex items-end gap-1 h-10' },
    Array.from({ length: bars }).map((_, i) => {
      const active = level * bars > i;
      const height = 8 + (i / bars) * 28;
      return h('div', {
        key: i,
        style: { height: active ? height + 'px' : '6px' },
        className: `w-1.5 rounded-full transition-all duration-75 ${active ? 'bg-gradient-to-t from-fuchsia-500 to-cyan-300' : 'bg-white/10'}`
      });
    })
  );
}

// ---------------- Audio player ----------------
function AudioPlayer({ src, label, onDownload }) {
  const audioRef = useRef(null);
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [dur, setDur] = useState(0);

  useEffect(() => { setPlaying(false); setProgress(0); }, [src]);

  const toggle = () => {
    const a = audioRef.current;
    if (!a) return;
    if (a.paused) { a.play(); setPlaying(true); }
    else { a.pause(); setPlaying(false); }
  };

  return h('div', { className: 'bg-black/30 rounded-xl p-3 border border-white/10' },
    h('audio', {
      ref: audioRef, src,
      onTimeUpdate: (e) => setProgress(e.target.currentTime / (e.target.duration || 1)),
      onLoadedMetadata: (e) => setDur(e.target.duration),
      onEnded: () => setPlaying(false),
    }),
    h('div', { className: 'flex items-center gap-3' },
      h('button', {
        onClick: toggle,
        className: 'w-10 h-10 shrink-0 rounded-full bg-cyan-400 text-slate-900 text-lg flex items-center justify-center hover:scale-105 transition'
      }, playing ? '❚❚' : '▶'),
      h('div', { className: 'flex-1' },
        label && h('div', { className: 'text-[11px] text-white/50 mb-1' }, label),
        h('div', { className: 'flex items-end gap-0.5 h-8' },
          Array.from({ length: 40 }).map((_, i) => {
            const on = playing && (i / 40) <= progress;
            const barh = playing ? 4 + Math.abs(Math.sin(i * 0.6 + Date.now() / 200)) * 20 : 4 + (Math.sin(i) + 1) * 8;
            return h('div', {
              key: i,
              style: { height: barh + 'px' },
              className: `w-1 rounded ${on ? 'bg-cyan-300' : 'bg-white/15'}`
            });
          })
        )
      ),
      onDownload && h('button', {
        onClick: onDownload,
        className: 'shrink-0 text-xs px-3 py-2 rounded-lg bg-white/10 hover:bg-white/20 transition'
      }, '⬇ Save')
    )
  );
}

// ---------------- Main App ----------------
const App = () => {
  const settings = load(LS_SETTINGS, { voice: 'nova' });
  const [stage, setStage] = useState('capture');
  const [toast, setToast] = useState(null);

  // capture
  const [recording, setRecording] = useState(false);
  const [recTime, setRecTime] = useState(0);
  const [level, setLevel] = useState(0);
  const [audioBlob, setAudioBlob] = useState(null);
  const [audioURL, setAudioURL] = useState(null);

  // transcribe
  const [transcript, setTranscript] = useState('');
  const [transcribing, setTranscribing] = useState(false);

  // speak
  const [voice, setVoice] = useState(settings.voice || 'nova');
  const [generating, setGenerating] = useState(false);
  const [resultURL, setResultURL] = useState(null);

  const [history, setHistory] = useState(load(LS_HISTORY, []));

  const mediaRec = useRef(null);
  const chunks = useRef([]);
  const audioCtx = useRef(null);
  const analyser = useRef(null);
  const rafRef = useRef(null);
  const timerRef = useRef(null);

  const showToast = (msg, type = 'info') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3500);
  };

  useEffect(() => { save(LS_SETTINGS, { voice }); }, [voice]);
  useEffect(() => { save(LS_HISTORY, history); }, [history]);

  // ---- Recording ----
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      chunks.current = [];
      const mr = new MediaRecorder(stream);
      mediaRec.current = mr;
      mr.ondataavailable = (e) => { if (e.data.size) chunks.current.push(e.data); };
      mr.onstop = () => {
        const blob = new Blob(chunks.current, { type: 'audio/webm' });
        setAudioBlob(blob);
        setAudioURL(URL.createObjectURL(blob));
        stream.getTracks().forEach(t => t.stop());
        cancelAnimationFrame(rafRef.current);
        if (audioCtx.current) { audioCtx.current.close(); audioCtx.current = null; }
        setLevel(0);
      };
      mr.start();

      // level meter
      audioCtx.current = new (window.AudioContext || window.webkitAudioContext)();
      const source = audioCtx.current.createMediaStreamSource(stream);
      analyser.current = audioCtx.current.createAnalyser();
      analyser.current.fftSize = 256;
      source.connect(analyser.current);
      const data = new Uint8Array(analyser.current.frequencyBinCount);
      const tick = () => {
        analyser.current.getByteFrequencyData(data);
        const avg = data.reduce((a, b) => a + b, 0) / data.length;
        setLevel(Math.min(1, avg / 90));
        rafRef.current = requestAnimationFrame(tick);
      };
      tick();

      setRecording(true);
      setRecTime(0);
      timerRef.current = setInterval(() => setRecTime(t => t + 1), 1000);
    } catch (err) {
      showToast('🎤 Mic access denied — try uploading a file instead', 'error');
    }
  };

  const stopRecording = () => {
    if (mediaRec.current && mediaRec.current.state !== 'inactive') mediaRec.current.stop();
    clearInterval(timerRef.current);
    setRecording(false);
  };

  const handleFile = (file) => {
    if (!file) return;
    if (!file.type.startsWith('audio/')) { showToast('That is not an audio file 🙈', 'error'); return; }
    if (file.size > 10 * 1024 * 1024) { showToast('File too big (max 10MB)', 'error'); return; }
    setAudioBlob(file);
    setAudioURL(URL.createObjectURL(file));
    showToast('Audio loaded 🎧', 'success');
  };

  const clearCapture = () => {
    setAudioBlob(null); setAudioURL(null); setTranscript(''); setResultURL(null); setStage('capture');
  };

  // ---- Transcribe ----
  const transcribe = async () => {
    if (!audioBlob) return;
    setTranscribing(true);
    setStage('transcribe');
    try {
      const b64 = await blobToBase64(audioBlob);
      const format = (audioBlob.type.includes('mp3') || audioBlob.type.includes('mpeg')) ? 'mp3'
                   : (audioBlob.type.includes('wav')) ? 'wav' : 'webm';
      const res = await fetch('https://text.pollinations.ai/openai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'openai-audio',
          messages: [{
            role: 'user',
            content: [
              { type: 'text', text: 'Transcribe this audio exactly.' },
              { type: 'input_audio', input_audio: { data: b64, format } }
            ]
          }]
        })
      });
      if (!res.ok) throw new Error('bad status');
      const json = await res.json();
      const text = json.choices?.[0]?.message?.content || '';
      if (!text.trim()) throw new Error('empty');
      setTranscript(text.trim());
      showToast('Transcribed! Edit away ✍️', 'success');
    } catch (err) {
      showToast('Transcription hiccup — type your text below instead 👂', 'error');
      setTranscript(prev => prev || '');
    } finally {
      setTranscribing(false);
    }
  };

  // ---- Speak (TTS) ----
  const generateSpeech = async () => {
    if (!transcript.trim()) { showToast('Nothing to say yet — add some text!', 'error'); return; }
    setGenerating(true);
    setStage('speak');
    setResultURL(null);
    try {
      const url = `https://text.pollinations.ai/${encodeURIComponent(transcript.slice(0, 800))}?model=openai-audio&voice=${voice}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error('bad status');
      const blob = await res.blob();
      if (!blob.type.startsWith('audio')) throw new Error('not audio');
      setResultURL(URL.createObjectURL(blob));
      addHistory();
      showToast('Speech ready! 🎉', 'success');
    } catch (err) {
      // Fallback to browser speech synthesis
      fallbackSpeak();
    } finally {
      setGenerating(false);
    }
  };

  const fallbackSpeak = () => {
    if (!('speechSynthesis' in window)) { showToast('Speech generation failed 😢', 'error'); return; }
    const u = new SpeechSynthesisUtterance(transcript);
    const voices = window.speechSynthesis.getVoices();
    const idx = VOICES.findIndex(v => v.id === voice);
    if (voices.length) u.voice = voices[idx % voices.length];
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
    addHistory();
    showToast('Used your browser voice as a backup 🗣️', 'info');
  };

  const addHistory = () => {
    const vObj = VOICES.find(v => v.id === voice);
    const entry = {
      id: String(Date.now()),
      text: transcript.slice(0, 120),
      voiceId: voice,
      voiceName: `${vObj.emoji} ${vObj.name}`,
      createdAt: new Date().toISOString(),
    };
    setHistory(prev => [entry, ...prev].slice(0, 10));
  };

  const downloadResult = () => {
    if (!resultURL) return;
    const a = document.createElement('a');
    a.href = resultURL; a.download = 'voice-echo.mp3'; a.click();
  };

  const wordCount = transcript.trim() ? transcript.trim().split(/\s+/).length : 0;

  // ------------- render -------------
  return h('div', { className: 'min-h-screen text-white ve-bg' },
    h(Toast, { toast, onClose: () => setToast(null) }),

    // Header
    h('header', { className: 'text-center pt-10 pb-2 px-4' },
      h('h1', { className: 've-title text-4xl sm:text-6xl font-extrabold tracking-tight' },
        h('span', { className: 've-grad' }, 'Voice Echo')
      ),
      h('div', { className: 'text-2xl sm:text-3xl mt-1 ve-flow' }, '🎙️ → 📝 → 🔊'),
      h('p', { className: 'text-white/50 mt-3 text-sm sm:text-base' },
        'Speak it. Read it. Hear it in someone else’s voice.')
    ),

    h('main', { className: 'max-w-2xl mx-auto px-4 pb-16' },
      h(Stepper, { stage }),

      // ---- Stage 1: Capture ----
      h(Card, { title: '🎙️ 1. Capture', active: stage === 'capture' },
        h('div', { className: 'flex flex-col items-center gap-4' },
          h('button', {
            onClick: recording ? stopRecording : startRecording,
            className: `relative w-24 h-24 rounded-full text-3xl flex items-center justify-center transition-all ${recording ? 've-rec-active' : 'bg-fuchsia-600 hover:bg-fuchsia-500'}`
          },
            recording ? '■' : '●',
            recording && h('span', { className: 've-ring' })
          ),
          recording && h('div', { className: 'font-mono text-cyan-300 text-lg' },
            `${String(Math.floor(recTime/60)).padStart(2,'0')}:${String(recTime%60).padStart(2,'0')}`),
          recording && h(LevelMeter, { level }),
          !recording && h('p', { className: 'text-white/40 text-xs' }, 'Tap the mic to record')
        ),

        h('div', { className: 'flex items-center gap-3 my-5 text-white/30 text-xs' },
          h('div', { className: 'flex-1 h-px bg-white/10' }), 'OR', h('div', { className: 'flex-1 h-px bg-white/10' })),

        h(DropZone, { onFile: handleFile }),

        audioURL && h('div', { className: 'mt-4' },
          h(AudioPlayer, { src: audioURL, label: 'Your captured audio' }),
          h('div', { className: 'flex gap-3 mt-3' },
            h('button', {
              onClick: transcribe,
              className: 've-btn-primary flex-1'
            }, transcribing ? 'Listening… 👂' : 'Transcribe Audio →'),
            h('button', { onClick: clearCapture, className: 'text-xs text-white/50 hover:text-white px-3' }, 'Clear')
          )
        )
      ),

      // ---- Stage 2: Transcribe ----
      h(Card, { title: '📝 2. Transcribe & Edit', active: stage === 'transcribe' },
        transcribing
          ? h('div', { className: 'flex flex-col items-center py-8 gap-3' },
              h('div', { className: 've-spinner' }),
              h('p', { className: 'text-white/50 text-sm' }, 'Listening carefully…'))
          : h('div', null,
              h('textarea', {
                value: transcript,
                onChange: (e) => setTranscript(e.target.value),
                placeholder: 'Your transcript appears here — or just type something to speak…',
                className: 'w-full h-36 bg-black/30 border border-white/10 rounded-xl p-3 text-sm focus:outline-none focus:border-fuchsia-400 resize-y font-mono'
              }),
              h('div', { className: 'flex items-center justify-between mt-2 text-xs text-white/40' },
                h('span', null, `${wordCount} words · ${transcript.length} chars`),
                h('div', { className: 'flex gap-3' },
                  h('button', {
                    onClick: () => { navigator.clipboard.writeText(transcript); showToast('Copied 📋', 'success'); },
                    className: 'hover:text-white'
                  }, 'Copy'),
                  h('button', { onClick: () => setTranscript(''), className: 'hover:text-white' }, 'Clear')
                )
              )
            )
      ),

      // ---- Stage 3: Speak ----
      h(Card, { title: '🔊 3. Pick a Voice & Speak', active: stage === 'speak' },
        h('div', { className: 'grid grid-cols-2 sm:grid-cols-3 gap-2' },
          VOICES.map(v => h('button', {
            key: v.id,
            onClick: () => setVoice(v.id),
            className: `p-3 rounded-xl border text-left transition-all ${voice === v.id ? 've-voice-active border-cyan-400' : 'border-white/10 bg-white/5 hover:bg-white/10'}`
          },
            h('div', { className: 'text-2xl' }, v.emoji),
            h('div', { className: 'text-sm font-semibold' }, v.name),
            h('div', { className: 'text-[10px] text-white/40' }, v.desc)
          ))
        ),
        h('button', {
          onClick: generateSpeech,
          disabled: generating,
          className: 've-btn-primary w-full mt-4'
        }, generating ? 'Conjuring voice… 🎙️' : 'Generate Speech 🔊'),

        resultURL && h('div', { className: 'mt-4 ve-pop' },
          h(AudioPlayer, { src: resultURL, label: 'Generated speech', onDownload: downloadResult })
        )
      ),

      // ---- History ----
      history.length > 0 && h(Card, { title: '🕒 Recent Echoes', active: false },
        h('div', { className: 'flex flex-col gap-2' },
          history.map(e => h('div', {
            key: e.id,
            className: 'flex items-center justify-between gap-3 bg-black/20 rounded-lg px-3 py-2 text-sm'
          },
            h('div', { className: 'min-w-0' },
              h('div', { className: 'truncate text-white/80' }, e.text || '(empty)'),
              h('div', { className: 'text-[10px] text-white/40' }, e.voiceName)
            ),
            h('button', {
              onClick: () => { setTranscript(e.text); setVoice(e.voiceId); setStage('speak'); showToast('Loaded into editor ↻', 'info'); },
              className: 'shrink-0 text-cyan-300 text-xs hover:underline'
            }, 'Reload')
          ))
        ),
        h('button', {
          onClick: () => { setHistory([]); showToast('History cleared', 'info'); },
          className: 'mt-3 text-xs text-white/40 hover:text-red-300'
        }, 'Clear history')
      ),

      h('footer', { className: 'text-center text-white/30 text-xs mt-10' },
        h('p', null, 'Made with mumbles and math 🍓'),
        h('a', { href: '/remix', className: 'text-fuchsia-300 hover:text-fuchsia-200 underline mt-1 inline-block' }, 'Remix on Berrry')
      )
    )
  );
};

// ---- Reusable Card ----
function Card({ title, active, children }) {
  return h('section', {
    className: `ve-card mb-5 p-5 rounded-2xl border transition-all duration-300 ${active ? 'border-fuchsia-400/60 ve-card-active' : 'border-white/10'}`
  },
    h('h2', { className: 'text-lg font-bold mb-4 tracking-tight' }, title),
    children
  );
}

// ---- Drop zone ----
function DropZone({ onFile }) {
  const [drag, setDrag] = useState(false);
  const inputRef = useRef(null);
  return h('div', {
    onDragOver: (e) => { e.preventDefault(); setDrag(true); },
    onDragLeave: () => setDrag(false),
    onDrop: (e) => { e.preventDefault(); setDrag(false); onFile(e.dataTransfer.files[0]); },
    onClick: () => inputRef.current.click(),
    className: `cursor-pointer border-2 border-dashed rounded-xl p-6 text-center transition ${drag ? 'border-cyan-400 bg-cyan-400/10' : 'border-white/15 hover:border-white/30'}`
  },
    h('div', { className: 'text-2xl mb-1' }, '🎧'),
    h('p', { className: 'text-sm text-white/60' }, 'Drop an audio file here'),
    h('p', { className: 'text-[11px] text-white/30' }, 'or click to upload · mp3, wav, m4a · max 10MB'),
    h('input', {
      ref: inputRef, type: 'file', accept: 'audio/*', className: 'hidden',
      onChange: (e) => onFile(e.target.files[0])
    })
  );
}

// Preload speech synthesis voices
if ('speechSynthesis' in window) window.speechSynthesis.getVoices();

ReactDOM.createRoot(document.getElementById('root')).render(h(App));