'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { Download, ImagePlus, Upload, Zap } from 'lucide-react'

const PALETTE = ['#0b1020', '#24304a', '#3b536d', '#4f7890', '#7e9e9c', '#b8c4a4', '#e1d8ad', '#fff4c7']
const PALETTE_LABELS = ['000', '001', '010', '011', '100', '101', '110', '111']
const MATRIX = [[0, 0, 7 / 16], [3 / 16, 5 / 16, 1 / 16]]

type DitherMode = 'floyd' | 'threshold'

export default function Page() {
  const [source, setSource] = useState<string | null>(null)
  const [filename, setFilename] = useState('untitled')
  const [width, setWidth] = useState(64)
  const [dither, setDither] = useState<DitherMode>('floyd')
  const [threshold, setThreshold] = useState(128)
  const [result, setResult] = useState<string[][]>([])
  const fileInput = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (!source) return
    const image = new Image()
    image.onload = () => {
      const scale = Math.min(1, width / image.width)
      const canvas = document.createElement('canvas')
      canvas.width = Math.max(1, Math.round(image.width * scale))
      canvas.height = Math.max(1, Math.round(image.height * scale))
      const context = canvas.getContext('2d', { willReadFrequently: true })
      if (!context) return
      context.drawImage(image, 0, 0, canvas.width, canvas.height)
      const pixels = context.getImageData(0, 0, canvas.width, canvas.height)
      const values = Array.from({ length: canvas.height }, (_, y) =>
        Array.from({ length: canvas.width }, (_, x) => {
          const i = (y * canvas.width + x) * 4
          return (pixels.data[i] * 0.299 + pixels.data[i + 1] * 0.587 + pixels.data[i + 2] * 0.114)
        }),
      )
      const output = values.map((row) => row.map(() => PALETTE[0]))
      for (let y = 0; y < values.length; y++) {
        for (let x = 0; x < values[y].length; x++) {
          const current = values[y][x]
          const index = dither === 'threshold' ? (current > threshold ? 7 : 0) : Math.max(0, Math.min(7, Math.round((current / 255) * 7)))
          const next = Math.round((index / 7) * 255)
          output[y][x] = PALETTE[index]
          if (dither === 'floyd') {
            const error = current - next
            if (x + 1 < values[y].length) values[y][x + 1] += error * MATRIX[0][2]
            if (y + 1 < values.length) {
              if (x > 0) values[y + 1][x - 1] += error * MATRIX[1][0]
              values[y + 1][x] += error * MATRIX[1][1]
              if (x + 1 < values[y + 1].length) values[y + 1][x + 1] += error * MATRIX[1][2]
            }
          }
        }
      }
      setResult(output)
    }
    image.src = source
  }, [source, width, dither, threshold])

  const digits = useMemo(() => result.map((row) => row.map((color) => PALETTE.indexOf(color).toString(2).padStart(3, '0')).join(' ')).join('\n'), [result])
  const dimensions = result.length ? `${result[0].length} × ${result.length}` : '—'

  function handleFile(file?: File) {
    if (!file || !file.type.startsWith('image/')) return
    setFilename(file.name.replace(/\.[^/.]+$/, ''))
    const reader = new FileReader()
    reader.onload = () => setSource(String(reader.result))
    reader.readAsDataURL(file)
  }

  function download() {
    const blob = new Blob([digits], { type: 'text/plain;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const anchor = document.createElement('a')
    anchor.href = url
    anchor.download = `${filename || 'untitled'}-3bit.txt`
    anchor.click()
    URL.revokeObjectURL(url)
  }

  return (
    <main className="min-h-screen bg-[#090d16] text-[#f5f0dc] selection:bg-[#d6c48c] selection:text-[#111]">
      <header className="border-b border-white/10 bg-[#0c111d]">
        <div className="mx-auto flex max-w-[1500px] items-center justify-between px-5 py-4 lg:px-8">
          <div className="flex items-center gap-3"><div className="grid size-8 place-items-center bg-[#d6c48c] text-[#111]"><Zap data-icon="inline-start" /></div><div><p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-[#d6c48c]">Pixel Foundry</p><h1 className="text-lg font-semibold tracking-tight">Image → Digits</h1></div></div>
          <span className="hidden font-mono text-xs text-white/40 sm:block">3-BIT PALETTE / DITHERING LAB</span>
        </div>
      </header>

      <div className="mx-auto grid max-w-[1500px] gap-6 px-5 py-7 lg:grid-cols-[310px_1fr] lg:px-8">
        <aside className="flex flex-col gap-5">
          <section className="border border-white/10 bg-[#101724] p-5">
            <p className="mb-4 text-[10px] font-bold uppercase tracking-[0.2em] text-[#d6c48c]">01 / Source image</p>
            <button className="flex min-h-40 w-full flex-col items-center justify-center gap-3 border border-dashed border-white/20 bg-[#0c111d] px-4 text-center transition hover:border-[#d6c48c]" onClick={() => fileInput.current?.click()}>
              {source ? <img src={source} alt="Uploaded source preview" className="max-h-36 max-w-full object-contain" /> : <><ImagePlus className="text-[#d6c48c]" /><span className="text-sm font-medium">Drop an image here</span><span className="text-xs text-white/40">PNG, JPG, or WEBP</span></>}
            </button>
            <input ref={fileInput} className="sr-only" type="file" accept="image/*" onChange={(event) => handleFile(event.target.files?.[0])} />
            <button className="mt-3 flex w-full items-center justify-center gap-2 border border-white/15 px-3 py-2 text-xs font-semibold uppercase tracking-wider text-white/70 hover:border-white/40 hover:text-white" onClick={() => fileInput.current?.click()}><Upload /> Choose file</button>
          </section>

          <section className="border border-white/10 bg-[#101724] p-5">
            <p className="mb-5 text-[10px] font-bold uppercase tracking-[0.2em] text-[#d6c48c]">02 / Parameters</p>
            <label className="mb-2 flex items-center justify-between text-xs text-white/70"><span>Output width</span><output className="font-mono text-[#f5f0dc]">{width}px</output></label>
            <input type="range" min="16" max="128" step="8" value={width} onChange={(e) => setWidth(Number(e.target.value))} className="mb-5 w-full accent-[#d6c48c]" />
            <label className="mb-2 block text-xs text-white/70">Dither algorithm</label>
            <div className="grid grid-cols-2 gap-2">
              {(['floyd', 'threshold'] as DitherMode[]).map((mode) => <button key={mode} onClick={() => setDither(mode)} className={`border px-2 py-2 text-xs font-semibold uppercase tracking-wider ${dither === mode ? 'border-[#d6c48c] bg-[#d6c48c] text-[#111]' : 'border-white/15 text-white/60 hover:border-white/40'}`}>{mode === 'floyd' ? 'Floyd–Steinberg' : 'Threshold'}</button>)}
            </div>
            {dither === 'threshold' && <><label className="mb-2 mt-5 flex justify-between text-xs text-white/70"><span>Threshold</span><output className="font-mono text-[#f5f0dc]">{threshold}</output></label><input type="range" min="0" max="255" value={threshold} onChange={(e) => setThreshold(Number(e.target.value))} className="w-full accent-[#d6c48c]" /></>}
          </section>

          <section className="border border-white/10 bg-[#101724] p-5"><p className="mb-4 text-[10px] font-bold uppercase tracking-[0.2em] text-[#d6c48c]">03 / Palette</p><div className="grid grid-cols-4 gap-2">{PALETTE.map((color, index) => <div key={color} className="flex flex-col gap-1"><div className="h-8 border border-white/10" style={{ backgroundColor: color }} /><span className="font-mono text-[10px] text-white/40">{PALETTE_LABELS[index]}</span></div>)}</div></section>
        </aside>

        <section className="min-w-0 border border-white/10 bg-[#101724]">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 px-5 py-4"><div><p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[#d6c48c]">Output matrix</p><p className="mt-1 font-mono text-xs text-white/40">{dimensions} / {dither === 'floyd' ? 'FLOYD–STEINBERG' : 'HARD THRESHOLD'}</p></div><button onClick={download} disabled={!result.length} className="flex items-center gap-2 bg-[#d6c48c] px-4 py-2.5 text-xs font-bold uppercase tracking-wider text-[#111] transition hover:bg-[#eee1aa] disabled:cursor-not-allowed disabled:opacity-30"><Download /> Download .txt</button></div>
          <div className="grid min-h-[540px] grid-cols-1 gap-px bg-white/10 lg:grid-cols-2"><div className="flex flex-col bg-[#0c111d] p-5"><span className="mb-3 text-[10px] font-bold uppercase tracking-[0.2em] text-white/35">Source</span><div className="grid flex-1 place-items-center border border-white/5 bg-[#080b12] p-5">{source ? <img src={source} alt="Original uploaded image" className="max-h-[470px] max-w-full object-contain" /> : <div className="text-center text-white/25"><ImagePlus className="mx-auto mb-3" /><p className="text-sm">Upload an image to begin</p></div>}</div></div><div className="flex flex-col bg-[#0c111d] p-5"><span className="mb-3 text-[10px] font-bold uppercase tracking-[0.2em] text-white/35">Dithered output</span><div className="flex flex-1 items-center justify-center overflow-auto border border-white/5 bg-[#080b12] p-5">{result.length ? <div className="grid gap-0" style={{ gridTemplateColumns: `repeat(${result[0].length}, minmax(2px, 1fr))`, width: 'min(100%, 500px)', aspectRatio: `${result[0].length} / ${result.length}` }}>{result.flatMap((row, y) => row.map((color, x) => <span key={`${y}-${x}`} style={{ backgroundColor: color }} />))}</div> : <div className="text-center text-white/25"><p className="font-mono text-3xl">000 001 010</p><p className="mt-3 text-sm">Your matrix appears here</p></div>}</div></div></div>
          <div className="border-t border-white/10 bg-[#0c111d] p-5"><div className="mb-3 flex items-center justify-between"><span className="text-[10px] font-bold uppercase tracking-[0.2em] text-white/35">Text preview</span><span className="font-mono text-[10px] text-white/25">{result.length ? `${result.length * result[0].length} values` : 'waiting'}</span></div><pre className="max-h-28 overflow-auto whitespace-pre-wrap break-all border border-white/5 bg-[#080b12] p-3 font-mono text-[10px] leading-relaxed text-[#d6c48c]">{digits || '000 000 000 000\n000 000 000 000\n…'}</pre></div>
        </section>
      </div>
      <footer className="mx-auto flex max-w-[1500px] justify-between px-5 pb-6 text-[10px] uppercase tracking-widest text-white/25 lg:px-8"><span>Local processing · no uploads</span><span>8 shades / 3 bits</span></footer>
    </main>
  )
}
