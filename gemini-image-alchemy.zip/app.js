const { useState, useEffect, useRef, useCallback } = React;
const h = React.createElement;

const STORAGE_KEY = "alchemy-state";

const MODELS = [
  { id: "flash", name: "Gemini Flash", emoji: "⚡", desc: "Zippy transmutations", modifier: "clean, sharp detail" },
  { id: "pro", name: "Gemini Pro Vision", emoji: "🔮", desc: "Deep artistic sight", modifier: "richly detailed, cinematic lighting" },
  { id: "ultra", name: "Gemini Ultra Dream", emoji: "🌌", desc: "Maximum dream fuel", modifier: "hyper-detailed, dramatic, surreal atmosphere" },
  { id: "nano", name: "Nano Banana", emoji: "🍌", desc: "The honest one", modifier: "vivid, expressive" },
];

const QUICK_PROMPTS = [
  { label: "Cyberpunk", p: "reimagine as a neon-soaked cyberpunk scene with glowing city lights" },
  { label: "Oil Painting", p: "transform into a thick impasto oil painting, visible brushstrokes" },
  { label: "Anime", p: "convert into vibrant anime illustration style" },
  { label: "Watercolor", p: "render as a soft flowing watercolor painting" },
  { label: "Ghibli-ish", p: "reimagine in a whimsical hand-painted studio animation style, lush and warm" },
  { label: "Vaporwave", p: "turn into a pastel vaporwave aesthetic with pink and cyan gradients" },
  { label: "Pencil Sketch", p: "convert into a detailed graphite pencil sketch" },
  { label: "Statue", p: "transform the subject into a polished white marble statue" },
];

const SURPRISES = [
  "turn everything into stained glass with golden lead lines",
  "reimagine underwater with bioluminescent coral and fish",
  "make it a cozy autumn scene with falling leaves and warm light",
  "transform into a retro 80s synthwave poster",
  "render as an intricate Art Nouveau illustration with gold filigree",
  "make it look like a scene inside a snow globe",
  "reimagine as a lego brick diorama",
  "turn into a glowing paper lantern festival at night",
];

const LOADING_MSGS = [
  "Consulting the pixel oracle...",
  "Bribing the GPUs with bananas...",
  "Rearranging photons...",
  "Whispering to the latent space...",
  "Stirring the cauldron of pixels...",
  "Negotiating with the color spirits...",
];

function load() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || {}; }
  catch { return {}; }
}
function save(state) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch (e) {}
}

// Downscale an image dataURL to keep payload reasonable
function downscale(dataUrl, max, cb) {
  const img = new Image();
  img.onload = () => {
    let { width, height } = img;
    const scale = Math.min(1, max / Math.max(width, height));
    width = Math.round(width * scale);
    height = Math.round(height * scale);
    const c = document.createElement("canvas");
    c.width = width; c.height = height;
    c.getContext("2d").drawImage(img, 0, 0, width, height);
    cb(c.toDataURL("image/jpeg", 0.9));
  };
  img.onerror = () => cb(dataUrl);
  img.src = dataUrl;
}

function App() {
  const persisted = load();
  const [source, setSource] = useState(null); // dataURL
  const [prompt, setPrompt] = useState(persisted.lastPrompt || "");
  const [model, setModel] = useState(persisted.lastModel || "flash");
  const [creativity, setCreativity] = useState(persisted.creativity ?? 50);
  const [result, setResult] = useState(null); // url
  const [loading, setLoading] = useState(false);
  const [loadMsg, setLoadMsg] = useState(LOADING_MSGS[0]);
  const [toast, setToast] = useState(null);
  const [history, setHistory] = useState(persisted.history || []);
  const [compare, setCompare] = useState(50);
  const [dragOver, setDragOver] = useState(false);
  const fileRef = useRef(null);
  const msgTimer = useRef(null);

  useEffect(() => {
    save({ lastPrompt: prompt, lastModel: model, creativity, history });
  }, [prompt, model, creativity, history]);

  useEffect(() => {
    const onPaste = (e) => {
      for (const item of e.clipboardData.items) {
        if (item.type.startsWith("image/")) {
          const blob = item.getAsFile();
          const r = new FileReader();
          r.onload = () => loadImage(r.result);
          r.readAsDataURL(blob);
        }
      }
    };
    document.addEventListener("paste", onPaste);
    return () => document.removeEventListener("paste", onPaste);
  }, []);

  const showToast = (msg, kind = "info") => {
    setToast({ msg, kind });
    setTimeout(() => setToast(null), 3500);
  };

  const loadImage = (dataUrl) => {
    downscale(dataUrl, 1024, (scaled) => setSource(scaled));
  };

  const handleFile = (file) => {
    if (!file || !file.type.startsWith("image/")) {
      showToast("That doesn't look like an image 🤔", "error");
      return;
    }
    const r = new FileReader();
    r.onload = () => loadImage(r.result);
    r.readAsDataURL(file);
  };

  const onDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    if (e.dataTransfer.files[0]) handleFile(e.dataTransfer.files[0]);
  };

  const cycleLoadMsg = () => {
    let i = 0;
    msgTimer.current = setInterval(() => {
      i = (i + 1) % LOADING_MSGS.length;
      setLoadMsg(LOADING_MSGS[i]);
    }, 2200);
  };

  const stopLoadMsg = () => { if (msgTimer.current) clearInterval(msgTimer.current); };

  const buildPrompt = () => {
    const m = MODELS.find((x) => x.id === model);
    const wildness =
      creativity < 33 ? "keep the transformation subtle and faithful to the original" :
      creativity > 66 ? "go wild and dramatic with the reinterpretation" :
      "balance faithfulness with creative flair";
    let base = prompt.trim() || "reimagine this image in a beautiful artistic style";
    return `${base}, ${m.modifier}, ${wildness}`;
  };

  const transmute = async () => {
    if (!prompt.trim() && !source) {
      showToast("Type a prompt or drop an image first ✍️", "error");
      return;
    }
    setLoading(true);
    setResult(null);
    setLoadMsg(LOADING_MSGS[0]);
    cycleLoadMsg();
    const fullPrompt = buildPrompt();
    try {
      let resUrl;
      if (source) {
        const body = {
          prompt: fullPrompt,
          base_image_base64: source,
          strength: 0.35 + (creativity / 100) * 0.5,
          width: 1024,
          height: 1024,
        };
        const resp = await fetch("/api/nanobanana/image", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        });
        if (!resp.ok) throw new Error("gen failed " + resp.status);
        // endpoint redirects to cached image url; use final URL
        resUrl = resp.url || URL.createObjectURL(await resp.blob());
        if (!resp.redirected) {
          const blob = await resp.blob();
          resUrl = URL.createObjectURL(blob);
        }
      } else {
        // text-to-image
        resUrl = "/api/nanobanana/image/1024/1024?prompt=" + encodeURIComponent(fullPrompt) + "&seed=" + Math.floor(Math.random() * 99999);
      }
      // preload to ensure it renders
      await new Promise((resolve, reject) => {
        const img = new Image();
        img.onload = resolve;
        img.onerror = reject;
        img.src = resUrl;
      });
      setResult(resUrl);
      setCompare(50);
      const m = MODELS.find((x) => x.id === model);
      const entry = {
        id: String(Date.now()),
        prompt: prompt.trim() || "(auto style)",
        model: m.name,
        resultUrl: resUrl,
        sourceThumb: source,
        createdAt: new Date().toISOString(),
      };
      setHistory((prev) => [entry, ...prev].slice(0, 12));
      showToast("Transmutation complete! ✨", "success");
    } catch (err) {
      showToast("The alchemy fizzled — try again! 🧪", "error");
    } finally {
      stopLoadMsg();
      setLoading(false);
    }
  };

  const surprise = () => {
    const s = SURPRISES[Math.floor(Math.random() * SURPRISES.length)];
    setPrompt(s);
  };

  const useAsSource = () => {
    if (!result) return;
    // fetch result into dataURL so it can be edited
    fetch(result).then(r => r.blob()).then(b => {
      const rd = new FileReader();
      rd.onload = () => { loadImage(rd.result); setResult(null); showToast("Result loaded as new source 🔁", "success"); };
      rd.readAsDataURL(b);
    }).catch(() => showToast("Couldn't reuse that image 😕", "error"));
  };

  const download = () => {
    if (!result) return;
    fetch(result).then(r => r.blob()).then(b => {
      const a = document.createElement("a");
      a.href = URL.createObjectURL(b);
      a.download = "alchemy-" + Date.now() + ".png";
      a.click();
      URL.revokeObjectURL(a.href);
    }).catch(() => showToast("Download failed 😕", "error"));
  };

  const copyPrompt = () => {
    navigator.clipboard.writeText(prompt).then(() => showToast("Prompt copied 📋", "success"));
  };

  // ---------- RENDER ----------

  const dropzone = h("div", {
    className: "glass rounded-2xl border-2 border-dashed transition-all cursor-pointer p-6 flex flex-col items-center justify-center text-center min-h-[220px] " +
      (dragOver ? "border-teal-300 bg-teal-400/10 scale-[1.01]" : "border-white/20 hover:border-white/40"),
    onClick: () => fileRef.current.click(),
    onDragOver: (e) => { e.preventDefault(); setDragOver(true); },
    onDragLeave: () => setDragOver(false),
    onDrop: onDrop,
  },
    source
      ? h("div", { className: "relative w-full" },
          h("img", { src: source, className: "rounded-xl max-h-64 mx-auto object-contain" }),
          h("button", {
            className: "absolute top-1 right-1 bg-black/60 hover:bg-black/80 text-white text-xs rounded-full px-3 py-1",
            onClick: (e) => { e.stopPropagation(); setSource(null); }
          }, "Clear ✕")
        )
      : h("div", null,
          h("div", { className: "text-5xl mb-3" }, "🖼️"),
          h("p", { className: "text-white/80 font-medium" }, "Drag an image here"),
          h("p", { className: "text-white/40 text-sm mt-1" }, "or click · or paste from clipboard"),
        )
  );

  const quickChips = h("div", { className: "flex flex-wrap gap-2 mt-3" },
    QUICK_PROMPTS.map((q) =>
      h("button", {
        key: q.label,
        className: "text-xs px-3 py-1.5 rounded-full bg-white/5 border border-white/10 hover:bg-white/15 text-white/80 transition",
        onClick: () => setPrompt(q.p),
      }, q.label)
    ),
    h("button", {
      className: "text-xs px-3 py-1.5 rounded-full bg-gradient-to-r from-amber-400/30 to-pink-400/30 border border-amber-300/40 hover:from-amber-400/50 hover:to-pink-400/50 text-white transition",
      onClick: surprise,
    }, "Surprise Me 🎲")
  );

  const modelCarousel = h("div", { className: "flex gap-3 overflow-x-auto pb-2 -mx-1 px-1 carousel" },
    MODELS.map((m) =>
      h("button", {
        key: m.id,
        onClick: () => setModel(m.id),
        className: "flex-shrink-0 w-40 text-left rounded-xl p-3 border transition-all " +
          (model === m.id
            ? "border-teal-300 bg-teal-400/15 ring-2 ring-teal-300/40 shadow-lg shadow-teal-500/10"
            : "border-white/10 bg-white/5 hover:bg-white/10"),
      },
        h("div", { className: "text-2xl" }, m.emoji),
        h("div", { className: "font-bold text-white mt-1 text-sm" }, m.name),
        h("div", { className: "text-white/50 text-xs mt-0.5" }, m.desc)
      )
    )
  );

  const outputPanel = h("div", { className: "glass rounded-2xl p-4 sm:p-6 flex flex-col min-h-[400px]" },
    loading
      ? h("div", { className: "flex-1 flex flex-col items-center justify-center gap-4" },
          h("div", { className: "cauldron text-6xl animate-bounce" }, "🧪"),
          h("p", { className: "text-teal-200 font-mono text-sm animate-pulse" }, loadMsg),
          h("div", { className: "w-40 h-1 bg-white/10 rounded-full overflow-hidden" },
            h("div", { className: "h-full bg-gradient-to-r from-teal-400 to-fuchsia-400 shimmer w-full" })
          )
        )
      : result
      ? h("div", { className: "flex-1 flex flex-col gap-4" },
          source
            ? h("div", { className: "relative rounded-xl overflow-hidden select-none", style: { touchAction: "none" } },
                h("img", { src: source, className: "w-full object-contain max-h-[420px]", draggable: false }),
                h("div", { className: "absolute inset-0 overflow-hidden", style: { width: compare + "%" } },
                  h("img", { src: result, className: "h-full object-contain max-h-[420px]", style: { width: (10000 / compare) + "%", maxWidth: "none" }, draggable: false })
                ),
                h("div", { className: "absolute top-0 bottom-0 w-0.5 bg-white shadow", style: { left: compare + "%" } }),
                h("input", {
                  type: "range", min: 0, max: 100, value: compare,
                  onChange: (e) => setCompare(+e.target.value),
                  className: "absolute inset-x-0 bottom-3 mx-4 accent-teal-300",
                }),
                h("span", { className: "absolute top-2 left-2 text-[10px] bg-black/60 text-white px-2 py-0.5 rounded-full" }, "BEFORE"),
                h("span", { className: "absolute top-2 right-2 text-[10px] bg-teal-500/80 text-white px-2 py-0.5 rounded-full" }, "AFTER")
              )
            : h("img", { src: result, className: "rounded-xl w-full object-contain max-h-[420px] fade-in" }),
          h("div", { className: "flex flex-wrap gap-2 mt-auto" },
            h("button", { className: "btn-secondary", onClick: download }, "⬇ Download"),
            h("button", { className: "btn-secondary", onClick: transmute }, "🔄 Regenerate"),
            h("button", { className: "btn-secondary", onClick: useAsSource }, "🔁 Use as source"),
            h("button", { className: "btn-secondary", onClick: copyPrompt }, "📋 Copy prompt")
          )
        )
      : h("div", { className: "flex-1 flex flex-col items-center justify-center text-center text-white/40 gap-3" },
          h("div", { className: "text-6xl opacity-60" }, "✨"),
          h("p", { className: "font-medium text-white/60" }, "Your transmutation appears here"),
          h("p", { className: "text-sm max-w-xs" }, "Drop an image, describe your dream, and press Transmute. No image? A prompt alone conjures one from scratch."),
        )
  );

  const historyStrip = history.length > 0 && h("div", { className: "mt-6" },
    h("h3", { className: "text-white/50 text-xs uppercase tracking-widest mb-2 font-mono" }, "Recent transmutations"),
    h("div", { className: "flex gap-2 overflow-x-auto pb-2 carousel" },
      history.map((entry) =>
        h("button", {
          key: entry.id,
          onClick: () => { setResult(entry.resultUrl); setSource(entry.sourceThumb || null); setPrompt(entry.prompt === "(auto style)" ? "" : entry.prompt); },
          className: "flex-shrink-0 group relative rounded-lg overflow-hidden border border-white/10 hover:border-teal-300/60 transition",
          title: entry.prompt,
        },
          h("img", { src: entry.resultUrl, className: "w-20 h-20 object-cover" }),
          h("span", { className: "absolute bottom-0 inset-x-0 bg-black/70 text-[9px] text-white/80 px-1 py-0.5 truncate" }, entry.model)
        )
      )
    )
  );

  return h("div", { className: "min-h-screen text-white relative" },
    // toast
    toast && h("div", {
      className: "fixed top-4 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-full text-sm font-medium shadow-lg toast-in " +
        (toast.kind === "error" ? "bg-red-500/90" : toast.kind === "success" ? "bg-teal-500/90" : "bg-slate-700/90"),
    }, toast.msg),

    h("div", { className: "max-w-5xl mx-auto px-4 py-8" },
      // header
      h("header", { className: "text-center mb-8 header-in" },
        h("div", { className: "inline-flex items-center gap-2 text-xs font-mono px-3 py-1 rounded-full bg-white/5 border border-white/10 mb-4 pulse-badge" },
          h("span", { className: "text-amber-300" }, "∞"), "FREE UNLIMITED"),
        h("h1", { className: "text-4xl sm:text-5xl font-extrabold gradient-text tracking-tight" }, "Gemini Image Alchemy"),
        h("p", { className: "text-white/50 mt-2 text-sm sm:text-base" }, "All the models. All the pixels. Zero the price. 🍌")
      ),

      // main grid
      h("div", { className: "grid lg:grid-cols-2 gap-6" },
        // LEFT
        h("div", { className: "glass rounded-2xl p-4 sm:p-6 space-y-5" },
          h("h2", { className: "text-white/40 text-xs uppercase tracking-widest font-mono" }, "The Cauldron"),
          h("input", { type: "file", accept: "image/*", ref: fileRef, className: "hidden", onChange: (e) => handleFile(e.target.files[0]) }),
          dropzone,
          h("div", null,
            h("textarea", {
              value: prompt,
              onChange: (e) => setPrompt(e.target.value),
              onKeyDown: (e) => { if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) transmute(); },
              placeholder: "Describe your transformation...  (⌘/Ctrl + Enter to cast)",
              rows: 3,
              className: "w-full rounded-xl bg-black/30 border border-white/10 focus:border-teal-300/60 focus:ring-1 focus:ring-teal-300/40 outline-none p-3 text-white placeholder-white/30 resize-none",
            }),
            quickChips
          ),
          h("div", null,
            h("label", { className: "text-white/40 text-xs uppercase tracking-widest font-mono block mb-2" }, "Model Flavor"),
            modelCarousel,
            h("p", { className: "text-[10px] text-white/30 mt-1 italic" }, "Powered by Gemini 3.1 Flash Image — the model names are just vibes. 😉")
          ),
          h("div", null,
            h("label", { className: "text-white/40 text-xs uppercase tracking-widest font-mono flex justify-between mb-2" },
              h("span", null, "Creativity"),
              h("span", { className: "text-teal-300" }, creativity < 33 ? "Subtle" : creativity > 66 ? "Wild" : "Balanced")),
            h("input", {
              type: "range", min: 0, max: 100, value: creativity,
              onChange: (e) => setCreativity(+e.target.value),
              className: "w-full accent-fuchsia-400",
            })
          ),
          h("button", {
            onClick: transmute,
            disabled: loading,
            className: "w-full py-3.5 rounded-xl font-bold text-lg transition-all transmute-btn " + (loading ? "opacity-60 cursor-wait" : "hover:scale-[1.02] active:scale-[0.98]"),
          }, loading ? "Transmuting…" : "✨ Transmute Image")
        ),
        // RIGHT
        h("div", null, outputPanel, historyStrip)
      ),

      // footer
      h("footer", { className: "text-center mt-12 text-white/30 text-xs space-y-2" },
        h("p", null, "A whimsical demo powered by Nanobanana 2. Not affiliated with Google. All alchemy, no lawyers."),
        h("p", null,
          h("a", { href: "/remix", className: "text-teal-300/70 hover:text-teal-300 underline underline-offset-2" }, "Remix on Berrry")
        ),
        h("p", { className: "text-white/20" }, "© 2026 Gemini Image Alchemy 🍓")
      )
    )
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(h(App));