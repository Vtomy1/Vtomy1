# Gemini Image Alchemy 🎨✨

Create a playful, powerful **image-to-image transformation studio** that lets users upload a photo and reimagine it using AI. The app leans into the "Google Gemini, all models, free, unlimited" fantasy by presenting a fun "model selector" carousel (branded whimsically) and using the **Nanobanana 2 API (Gemini 3.1 Flash Image Preview)** under the hood for real image editing and generation. This is a **React Web App** because it needs image upload handling, form state, a prompt editor, model selection, and a gallery of results.

## Core Concept

Users drop in a source image, type what they want changed ("make it cyberpunk", "turn into oil painting", "add a dragon in the sky"), pick a "model flavor," and hit **Transmute**. The app sends the source image + prompt to Nanobanana 2 for image-to-image editing and displays before/after results. Everything is saved locally and optionally to the backend gallery.

## UI Elements

### Header
- App title "**Gemini Image Alchemy**" with a 🍌✨ emoji lockup, centered, using a bold gradient text effect (purple → blue → teal, echoing Google's palette but playful).
- Tagline underneath: *"All the models. All the pixels. Zero the price."* in small muted text.
- A whimsical "∞ FREE UNLIMITED" badge that gently pulses (it's a joke — it really is free to try).

### Main Content Area (two-column on desktop, stacked on mobile)

#### Left Panel — The Cauldron (Input)
1. **Image Dropzone**
   - Large dashed-border drop area with a friendly 🖼️ icon and "Drag an image here or click to upload."
   - Accepts image files up to 10MB; shows a thumbnail preview once loaded.
   - Small "Clear" button to reset.
2. **Prompt Textarea**
   - Rounded, shadowed textarea: "Describe your transformation..."
   - A row of **quick-prompt chips** below it: `Cyberpunk`, `Oil Painting`, `Anime`, `Watercolor`, `Studio Ghibli-ish`, `Vaporwave`, `Pencil Sketch`, `Surprise Me 🎲`. Clicking appends/sets the prompt.
3. **Model Selector Carousel**
   - Horizontal scrollable row of playful "model" cards: **Gemini Flash**, **Gemini Pro Vision**, **Gemini Ultra Dream**, **Nano Banana**. Each has an emoji, a fun one-line description, and a selected highlight ring.
   - A tiny honest footnote: *"Powered by Gemini 3.1 Flash Image — the model names are just vibes. 😉"*
4. **Strength/Creativity Slider**
   - "Subtle ← → Wild" slider that gets appended to the prompt as a stylistic modifier.
5. **Transmute Button**
   - Big gradient CTA "✨ Transmute Image" with a loading state showing a bubbling cauldron / spinner and rotating fun status messages ("Consulting the pixel oracle...", "Bribing the GPUs...").

#### Right Panel — The Gallery (Output)
- **Before/After viewer**: side-by-side (or a draggable comparison slider) showing source vs. result.
- **Download** button for the generated image.
- **Regenerate** and **Use as new source** buttons (feed the output back in for iterative editing).
- **History strip**: thumbnails of previous generations this session; click to re-view. Persisted via localStorage.

### Footer
- Light footer with a copyright note and the link: `<a href="/remix">Remix on Berrry</a>`.
- Small disclaimer clarifying it's a fun demo powered by Nanobanana 2, not affiliated with Google.

## Styling Preferences
- Clean, modern, slightly magical aesthetic. Dark mode default with glassmorphism cards (frosted, subtle borders, soft glows).
- Gradient accents (purple/blue/teal). Rounded corners, soft shadows, generous spacing.
- Use **Tailwind CSS** utility classes throughout.
- Smooth micro-animations: button hover glows, pulsing badge, fade-in for generated images, animated loading state.
- Fully responsive: two columns on desktop collapse to a single stacked flow on mobile with comfortable tap targets and readable font sizes.

## Functionality
- **Image-to-image**: Upload source image → convert to base64/blob → send with the user's prompt (plus model-flavor and creativity modifiers baked in) to the **Nanobanana 2 API** for editing/transformation.
- **Text-to-image fallback**: If no image is uploaded but a prompt exists, generate a fresh image from text.
- **Iterative editing**: "Use as new source" lets users chain transformations.
- **Local persistence**: Save recent generations and last-used prompt/model in localStorage.
- **Optional cloud gallery**: With backend storage + auth, let users save favorites publicly to a shared community gallery and browse others' creations (leaderboard-style "Top Transmutations").
- **Graceful errors**: If generation fails or rate-limits, show a friendly toast ("The alchemy fizzled — try again!") and keep the source image intact.
- **Download & share**: One-click download of results; copy-prompt button so users can share what they typed.

## Additional Features
- **"Surprise Me 🎲"** button that fills in a random creative prompt.
- **Comparison slider** overlay so users can drag between original and result.
- **Keyboard shortcut** (Enter to transmute when the prompt field is focused, Ctrl+Enter from textarea).
- Empty-state illustration with a couple of inspiring example transformations to demonstrate what's possible.

The overall feel should be fast, delightful, and honest-but-whimsical — a tiny image lab that makes AI image editing feel like casting a spell.